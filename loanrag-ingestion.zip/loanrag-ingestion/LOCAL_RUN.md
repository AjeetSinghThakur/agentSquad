# LOCAL_RUN — running the LoanRAG ingestion pipeline on your machine

This runs the whole ingestion pipeline locally, uploading documents to a **local
Azure Blob emulator (Azurite)** running in Docker. The exact same code and the
exact same blob containers are what the loan RAG will consume later — locally
first, then against real Azure by changing only configuration.

There are two ways to run it. **Docker is the intended path** (matches your
"upload to local docker before real Azure" goal). A no-Docker path is included
for quick experiments.

---

## What you need

- Docker Desktop (for the Docker path), **or**
- Python 3.12 + Tesseract + poppler (for the no-Docker path).

The sample documents for applicant **Ajeet Singh** (application
`LOAN-2026-000123`) are already in `./inbox/`, so you can run immediately.

---

## Option A — Docker (recommended)

All commands are run from the project root (the folder containing
`docker-compose.yml`).

### 1. Start the local blob storage (Azurite)
```bash
docker compose up -d azurite
```
Azurite is now your local "Azure Blob Storage", listening on `localhost:10000`.

### 2. Build the ingestion image (first time only)
```bash
docker compose build ingestion
```

### 3. Ingest every document in the inbox
```bash
docker compose run --rm ingestion ingest
```
You will see each file's result. The deliberately-degraded
`bank_statement_scanned.pdf` is **parked for human review** (its OCR confidence
is below the 0.70 threshold) instead of being silently ingested or dropped.

### 4. Look at the human-review (HITL) queue
```bash
docker compose run --rm ingestion review
```
This prints what is waiting, *why* (the quarantine reasons), a text preview, and
the exact command to resolve it.

### 5. Resolve the parked document (the human decision)
Pick one:
```bash
# Accept: you inspected the original and it is fine -> ingest the extracted text
docker compose run --rm ingestion resolve \
  --document-id LOAN-2026-000123__bank_statement_scanned.pdf \
  --decision accept --note "Legible on manual inspection."

# Reject: unusable -> ask for a re-upload (nothing is ingested)
docker compose run --rm ingestion resolve \
  --document-id LOAN-2026-000123__bank_statement_scanned.pdf \
  --decision reject --note "Unreadable, request a clean scan."

# Override: type the correct content yourself -> that text is ingested
docker compose run --rm ingestion resolve \
  --document-id LOAN-2026-000123__bank_statement_scanned.pdf \
  --decision override --corrected-text "Closing balance 1,57,058 ..."
```
After resolving, the pipeline **resumes** for that document automatically.

### 6. Verify what landed in blob storage
```bash
docker compose run --rm ingestion verify
```
Shows the `loan-docs` container (raw originals), the `loan-chunks` container
(clean, quality-passed chunk JSON), the per-document ledger, and how many chunks
were quarantined (dropped, never written).

### 7. Score the KPIs against ground truth
```bash
docker compose run --rm ingestion evaluate
```
Reports the **exact-match** field-extraction rate (strictly exact, no fuzzy
matching), document completeness, and confirms the authoritative DB facts were
intentionally **not** ingested. (Retrieval recall / false-positive belong to the
later retrieval step — see `RAG_GUIDE.md`.)

### Add your own documents
Drop any `.pdf / .xlsx / .html / .sqlite` into `./inbox/` and re-run step 3.
Already-ingested files are skipped (idempotent); only new/changed files run.

### Stop everything
```bash
docker compose down            # keep blobs
docker compose down -v         # also wipe the local blob volume
```

---

## Option B — No Docker (bare Python)

Useful for a fast loop without containers. Uses a local folder as the blob
store instead of Azurite.

```bash
# 1. system tools (Debian/Ubuntu example)
sudo apt-get install -y tesseract-ocr poppler-utils

# 2. python deps
pip install -r requirements.txt

# 3. tell it to use a local folder as "blob storage"
export LOANRAG__BLOB__BACKEND=localfs
export LOANRAG__BLOB__LOCALFS_ROOT=./_localblob
export LOANRAG__PATHS__INBOX=./inbox
export LOANRAG__PATHS__STATE_DIR=./_state

# 4. same subcommands as above
python -m loanrag.presentation.cli ingest
python -m loanrag.presentation.cli review
python -m loanrag.presentation.cli resolve --document-id LOAN-2026-000123__bank_statement_scanned.pdf --decision accept
python -m loanrag.presentation.cli verify
python -m loanrag.presentation.cli evaluate
```

---

## Regenerating the sample documents
The synthetic documents (all for **Ajeet Singh**) are produced by:
```bash
cd samples && python generate_sample_documents.py
```
Output goes to `samples/output/`. Copy them into `./inbox/` to ingest.

---

## Tuning knobs (environment variables)
| Variable | Default | Meaning |
|---|---|---|
| `LOANRAG__GUARD__MIN_CONFIDENCE` | `0.70` | OCR confidence below this → chunk quarantined |
| `LOANRAG__GUARD__MIN_CHARS` | `3` | shorter text → quarantined (`too_short`) |
| `LOANRAG__GUARD__MAX_GARBAGE_RATIO` | `0.30` | more noise than this → quarantined (`garbage`) |
| `LOANRAG__HITL__MIN_PASS_RATE` | `0.50` | if fewer chunks than this pass → whole doc → human review |
| `LOANRAG__BLOB__BACKEND` | `azure_blob` | `azure_blob` (Azure Blob SDK: emulator or real cloud) or `localfs` |

Lowering `MIN_CONFIDENCE` lets more borderline OCR through; raising it sends more
documents to a human. Start at 0.70 and adjust from your review outcomes.
