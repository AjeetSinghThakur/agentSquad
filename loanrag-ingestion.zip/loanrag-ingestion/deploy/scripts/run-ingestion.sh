#!/usr/bin/env bash
# Run ingestion against local | azure | gcp. The SAME code writes chunks to the
# chosen store; only env vars differ. Usage: ./run-ingestion.sh local|azure|gcp
set -euo pipefail
TARGET="${1:-local}"
case "$TARGET" in
  local) export LOANRAG__BLOB__BACKEND=localfs
         export LOANRAG__BLOB__LOCALFS_ROOT="${LOANRAG__BLOB__LOCALFS_ROOT:-./_localblob}";;
  azure) export LOANRAG__BLOB__BACKEND=azure_blob
         : "${LOANRAG__BLOB__CONNECTION_STRING:?set LOANRAG__BLOB__CONNECTION_STRING to your Azure Storage connection string}";;
  gcp)   export LOANRAG__BLOB__BACKEND=gcs
         : "${LOANRAG__BLOB__GCS_BUCKET:?set LOANRAG__BLOB__GCS_BUCKET to your GCS bucket}";;
  *) echo "usage: $0 local|azure|gcp"; exit 1;;
esac
export LOANRAG__PATHS__INBOX="${LOANRAG__PATHS__INBOX:-./inbox}"
echo ">> Ingesting to backend=$LOANRAG__BLOB__BACKEND"
python -m loanrag.presentation.cli ingest
python -m loanrag.presentation.cli verify || true
