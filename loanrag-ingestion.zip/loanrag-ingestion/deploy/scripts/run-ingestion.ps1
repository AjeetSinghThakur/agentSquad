# Run ingestion against local | azure | gcp.  Usage: ./run-ingestion.ps1 -Target gcp
param([ValidateSet("local","azure","gcp")][string]$Target="local")
switch ($Target) {
  "local" { $env:LOANRAG__BLOB__BACKEND="localfs"
            if (-not $env:LOANRAG__BLOB__LOCALFS_ROOT) { $env:LOANRAG__BLOB__LOCALFS_ROOT="./_localblob" } }
  "azure" { $env:LOANRAG__BLOB__BACKEND="azure_blob"
            if (-not $env:LOANRAG__BLOB__CONNECTION_STRING) { throw "Set LOANRAG__BLOB__CONNECTION_STRING (Azure Storage connection string)" } }
  "gcp"   { $env:LOANRAG__BLOB__BACKEND="gcs"
            if (-not $env:LOANRAG__BLOB__GCS_BUCKET) { throw "Set LOANRAG__BLOB__GCS_BUCKET (your GCS bucket)" } }
}
if (-not $env:LOANRAG__PATHS__INBOX) { $env:LOANRAG__PATHS__INBOX="./inbox" }
Write-Host ">> Ingesting to backend=$($env:LOANRAG__BLOB__BACKEND)"
python -m loanrag.presentation.cli ingest
python -m loanrag.presentation.cli verify
