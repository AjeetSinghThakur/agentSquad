"""
=============================================================================
 generate_sample_documents.py   (production-representative specimen set)
=============================================================================
WHAT THIS SCRIPT DOES
---------------------
Generates a set of realistic, multi-page, SPECIMEN loan-application documents
in the style of real Indian retail-lending paperwork, used to stress-test the
LoanRAG ingestion pipeline. They are intentionally dense and laid out like
genuine bank / payroll / tax / bureau output so the parser is exercised the way
production documents would exercise it.

All documents describe ONE fictional applicant and the numbers agree across
every file, so you can test cross-document retrieval and DTI / eligibility math.

SAFETY: every value is synthetic; issuer names are fictional; PAN / Aadhaar /
account numbers are masked or sample-format; and every PDF carries a light
diagonal "SPECIMEN" watermark + footer. These are test fixtures, not valid
documents, and the watermark keeps them from ever being mistaken for a real
customer's file inside your pipeline or logs. (The watermark does not impede
Document Intelligence extraction.)

FILES PRODUCED (into ./output/)
  salary_slip.pdf            Indian payslip: PF/UAN/ESI/TDS, earnings+deductions,
                             monthly+YTD columns                  -> key-value + dense table
  bank_statement.pdf         Multi-page statement: summary box, ~30 realistic
                             txns (UPI/NEFT/IMPS/ECS/POS/ATM), credits chart
                                                                  -> multi-page table + FIGURE
  loan_application_form.pdf  Multi-section form with checkboxes, obligations
                             table, references, declaration, office-use box
                                                                  -> headings, selection marks, tables
  form16_partb.pdf           Form 16 Part B: salary breakup + tax computation
                                                                  -> nested financial tables
  credit_report.pdf          Bureau report: score gauge, account summary,
                             tradelines, enquiries                -> mixed tables + a drawn gauge
  bank_statement_scanned.pdf Image-only, degraded (lighting/noise/skew/JPEG)
                                                                  -> OCR + confidence + null guard
  financials.xlsx            Transactions + Obligations + Summary (formulas)
                                                                  -> spreadsheet path (openpyxl)
  employment_verification.html  Styled HR letter with details table
                                                                  -> HTML extractor
  authoritative_facts.sqlite + seed_authoritative_facts.sql
                             System-of-record facts queried live (ADR-003)
  manifest.json              Machine-readable index for the eval harness

HOW TO RUN
    pip install reportlab openpyxl pillow matplotlib fonttools
    python generate_sample_documents.py
=============================================================================
"""

from __future__ import annotations

import io
import json
import re
import sqlite3
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont, ImageOps
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont as RLTTFont
from reportlab.pdfgen import canvas
from reportlab.platypus import (
    Image as RLImage,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

# --------------------------------------------------------------------------- #
# Fonts: DejaVu supports the rupee sign; register it so '₹' renders correctly.
# --------------------------------------------------------------------------- #
_DV = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
_DVB = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
pdfmetrics.registerFont(RLTTFont("DV", _DV))
pdfmetrics.registerFont(RLTTFont("DV-Bold", _DVB))
pdfmetrics.registerFontFamily("DV", normal="DV", bold="DV-Bold")

OUT = Path(__file__).parent / "output"
OUT.mkdir(exist_ok=True)
CONTENT_W = 178 * mm  # A4 width (210mm) minus 16mm margins each side

# Brand colours (reused so the whole set looks like one issuing ecosystem)
NAVY = colors.HexColor("#0C447C")
GREEN = colors.HexColor("#16A34A")
INK = colors.HexColor("#1f2937")
LIGHT = colors.HexColor("#EEF2F7")

# Per-document header text, read by SpecimenCanvas while drawing each page.
CTX = {"header": "", "sub": ""}

# --------------------------------------------------------------------------- #
# Single source of truth for the synthetic applicant.
# --------------------------------------------------------------------------- #
APPLICANT = {
    "application_id": "LOAN-2026-000123",
    "name": "Ajeet Singh",
    "pan": "ABCDE1234F",
    "aadhaar_masked": "XXXX XXXX 1234",
    "dob": "15-04-1990",
    "gender": "Male",
    "marital": "Married",
    "mobile": "+91 98XXX XX210",
    "email": "ajeet.singh@example.com",
    "address": "12 Mall Road, Shimla, Himachal Pradesh 171001",
    "residence": "Owned",
    "employer": "Acme Tech Solutions Pvt Ltd",
    "employer_cin": "U72200HP2012PTC0XXXXX",
    "designation": "Senior Engineer",
    "department": "Engineering",
    "doj": "01-06-2018",
    "emp_id": "ACME-4471",
    "uan": "1009XXXX5566",
    "pf_no": "HP/SML/00XXXX/000/000XXXX",
    "esi_no": "31-00-XXXXXX-000-0001",
    "account_number": "5012XXXXXX7788",
    "ifsc": "DMNB0001234",
    "micr": "171002XXX",
    "branch": "The Mall, Shimla",
    "bank": "Demo National Bank",
    "monthly_gross": 95000,
    "monthly_net": 78500,
    "monthly_emi_existing": 18000,
    "existing_loan_outstanding": 1200000,
    "credit_score": 762,
    "loan_amount": 2500000,
    "loan_tenure_months": 240,
    "loan_purpose": "Home purchase",
    "collateral_value": 4000000,
}


def ind(n: float) -> str:
    """Format a number with Indian digit grouping, e.g. 2500000 -> '25,00,000'."""
    n = int(round(n))
    s = str(abs(n))
    if len(s) > 3:
        last3, rest = s[-3:], s[:-3]
        rest = re.sub(r"(\d)(?=(\d\d)+$)", r"\1,", rest)
        s = rest + "," + last3
    return ("-" if n < 0 else "") + s


def rupee(n: float, paise: bool = False) -> str:
    """Render an amount as Indian rupees, optionally with '.00' paise."""
    return "₹" + ind(n) + (".00" if paise else "")


# --------------------------------------------------------------------------- #
# SpecimenCanvas: a custom canvas that, on every page, draws a faint diagonal
# 'SPECIMEN' watermark, a coloured header band (title + subtitle from CTX), and
# a footer with a synthetic-data notice and 'Page x of y'. The two-pass design
# (states saved, redrawn at save()) is what lets us print the true total pages.
# --------------------------------------------------------------------------- #
class SpecimenCanvas(canvas.Canvas):
    """Canvas that stamps watermark, header band and 'Page x of y' footer."""

    def __init__(self, *args, **kwargs):
        """Initialise and prepare per-page state capture."""
        super().__init__(*args, **kwargs)
        self._saved_states: list[dict] = []

    def showPage(self):
        """Capture the page state instead of finalising, so we can add totals."""
        self._saved_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        """Replay every captured page, decorate it, then write the PDF."""
        total = len(self._saved_states)
        for state in self._saved_states:
            self.__dict__.update(state)
            self._decorate(total)
            super().showPage()
        super().save()

    def _decorate(self, total: int):
        """Draw watermark, header band and footer onto the current page."""
        w, h = A4
        # Watermark (very light, diagonal, behind/over content).
        self.saveState()
        self.setFont("Helvetica-Bold", 70)
        self.setFillColor(colors.Color(0.45, 0.5, 0.6, alpha=0.08))
        self.translate(w / 2, h / 2)
        self.rotate(40)
        self.drawCentredString(0, 0, "SPECIMEN")
        self.restoreState()
        # Header band.
        self.saveState()
        self.setFillColor(NAVY)
        self.rect(0, h - 22 * mm, w, 22 * mm, fill=1, stroke=0)
        # Faux logo: a green rounded square with the issuer's initial.
        self.setFillColor(GREEN)
        self.roundRect(16 * mm, h - 18.5 * mm, 12 * mm, 12 * mm, 2 * mm, fill=1, stroke=0)
        self.setFillColor(colors.white)
        self.setFont("DV-Bold", 14)
        self.drawCentredString(22 * mm, h - 14.7 * mm, (CTX["header"][:1] or "L"))
        self.setFont("DV-Bold", 13)
        self.drawString(32 * mm, h - 11 * mm, CTX["header"])
        self.setFont("DV", 8.5)
        self.drawString(32 * mm, h - 16 * mm, CTX["sub"])
        self.restoreState()
        # Footer.
        self.saveState()
        self.setFillColor(colors.grey)
        self.setFont("DV", 7)
        self.drawString(16 * mm, 12 * mm, "SPECIMEN — synthetic sample data, not a valid document")
        self.drawRightString(w - 16 * mm, 12 * mm, f"Page {self._pageNumber} of {total}")
        self.setStrokeColor(colors.lightgrey)
        self.line(16 * mm, 15 * mm, w - 16 * mm, 15 * mm)
        self.restoreState()


# --------------------------------------------------------------------------- #
# Paragraph styles and small layout helpers shared by all PDF builders.
# --------------------------------------------------------------------------- #
P = ParagraphStyle("P", fontName="DV", fontSize=8.5, leading=12, textColor=INK)
PB = ParagraphStyle("PB", parent=P, fontName="DV-Bold")
SMALL = ParagraphStyle("SMALL", parent=P, fontSize=7.5, textColor=colors.grey)


def section(title: str) -> Table:
    """Return a full-width coloured section-heading bar."""
    t = Table([[title]], colWidths=[CONTENT_W])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), LIGHT),
        ("TEXTCOLOR", (0, 0), (-1, -1), NAVY),
        ("FONTNAME", (0, 0), (-1, -1), "DV-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 9.5),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("LINEBEFORE", (0, 0), (0, -1), 3, GREEN),
    ]))
    return t


def kv_block(pairs: list[tuple[str, str]]) -> Table:
    """Two-column key/value block (4 visual columns: label,val,label,val)."""
    rows, row = [], []
    for i, (k, v) in enumerate(pairs):
        row += [k, v]
        if len(row) == 4:
            rows.append(row)
            row = []
    if row:
        row += [""] * (4 - len(row))
        rows.append(row)
    t = Table(rows, colWidths=[30 * mm, 59 * mm, 30 * mm, 59 * mm])
    t.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, -1), "DV"),
        ("FONTNAME", (0, 0), (0, -1), "DV-Bold"),
        ("FONTNAME", (2, 0), (2, -1), "DV-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("TEXTCOLOR", (0, 0), (0, -1), colors.grey),
        ("TEXTCOLOR", (2, 0), (2, -1), colors.grey),
        ("TOPPADDING", (0, 0), (-1, -1), 2),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
    ]))
    return t


def build_pdf(filename: str, title: str, header: str, sub: str, flow: list) -> Path:
    """Build a PDF with the standard specimen frame (header/footer/watermark)."""
    CTX["header"], CTX["sub"] = header, sub
    path = OUT / filename
    doc = SimpleDocTemplate(
        str(path), pagesize=A4, title=title,
        topMargin=28 * mm, bottomMargin=20 * mm, leftMargin=16 * mm, rightMargin=16 * mm,
    )
    doc.build(flow, canvasmaker=SpecimenCanvas)
    print(f"  wrote {filename}")
    return path


def data_table(rows, col_widths, header_bg=NAVY, repeat=True, align_right=None,
               font_size=8) -> Table:
    """Return a styled data table (coloured header, grid, optional right-align)."""
    t = Table(rows, colWidths=col_widths, repeatRows=1 if repeat else 0)
    style = [
        ("BACKGROUND", (0, 0), (-1, 0), header_bg),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "DV-Bold"),
        ("FONTNAME", (0, 1), (-1, -1), "DV"),
        ("FONTSIZE", (0, 0), (-1, -1), font_size),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#d1d5db")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f7f9fc")]),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]
    if align_right:
        for c in align_right:
            style.append(("ALIGN", (c, 1), (c, -1), "RIGHT"))
    t.setStyle(TableStyle(style))
    return t


# ===========================================================================
# 1) SALARY SLIP  (born-digital PDF) — dense Indian payslip
# ===========================================================================
def make_salary_slip() -> Path:
    """Build a realistic Indian monthly payslip.

    Includes statutory identifiers (UAN, PF, ESI, PAN), an earnings/deductions
    grid with Monthly and Year-to-Date columns, net pay in words, and a system-
    generated footer note. Tests key-value extraction plus a dense multi-column
    financial table; gross (₹95,000) and net (₹78,500) are exact-match targets.
    """
    a = APPLICANT
    flow = [Spacer(1, 2 * mm)]
    flow.append(Paragraph(
        f"{a['employer']} &nbsp;|&nbsp; CIN: {a['employer_cin']} &nbsp;|&nbsp; "
        f"Regd. Office: {a['address']}", SMALL))
    flow.append(Spacer(1, 3 * mm))
    flow.append(section("Payslip for May 2026"))
    flow.append(Spacer(1, 2 * mm))
    flow.append(kv_block([
        ("Employee", a["name"]), ("Employee ID", a["emp_id"]),
        ("Designation", a["designation"]), ("Department", a["department"]),
        ("Date of Joining", a["doj"]), ("PAN", a["pan"]),
        ("UAN", a["uan"]), ("PF No.", a["pf_no"]),
        ("ESI No.", a["esi_no"]), ("Bank A/C", a["account_number"]),
        ("Pay Period", "01-May-2026 to 31-May-2026"), ("Pay Date", "31-May-2026"),
        ("Paid Days", "31"), ("LOP Days", "0"),
    ]))
    flow.append(Spacer(1, 3 * mm))

    g = a["monthly_gross"]
    basic, hra, conv, special, med = int(g * 0.4), int(g * 0.2), 1600, int(g * 0.3), 1250
    special = g - basic - hra - conv - med
    pf = int(basic * 0.12)
    pt = 200
    tds = g - a["monthly_net"] - pf - pt
    rows = [
        ["Earnings", "Monthly", "YTD", "Deductions", "Monthly", "YTD"],
        ["Basic", rupee(basic), rupee(basic * 2), "Provident Fund", rupee(pf), rupee(pf * 2)],
        ["House Rent Allowance", rupee(hra), rupee(hra * 2), "Professional Tax", rupee(pt), rupee(pt * 2)],
        ["Conveyance", rupee(conv), rupee(conv * 2), "Income Tax (TDS)", rupee(tds), rupee(tds * 2)],
        ["Medical Allowance", rupee(med), rupee(med * 2), "", "", ""],
        ["Special Allowance", rupee(special), rupee(special * 2), "", "", ""],
        ["Gross Earnings", rupee(g), rupee(g * 2), "Total Deductions", rupee(pf + pt + tds), rupee((pf + pt + tds) * 2)],
    ]
    cw = [38 * mm, 22 * mm, 22 * mm, 38 * mm, 19 * mm, 19 * mm]
    t = data_table(rows, cw, align_right=[1, 2, 4, 5], font_size=7.8)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), NAVY),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "DV-Bold"),
        ("FONTNAME", (0, 1), (-1, -1), "DV"),
        ("FONTNAME", (0, -1), (-1, -1), "DV-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 7.8),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#d1d5db")),
        ("BACKGROUND", (0, -1), (-1, -1), LIGHT),
        ("ALIGN", (1, 1), (2, -1), "RIGHT"),
        ("ALIGN", (4, 1), (5, -1), "RIGHT"),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    flow.append(t)
    flow.append(Spacer(1, 3 * mm))
    net = a["monthly_net"]
    nt = Table([[f"Net Pay for May 2026", rupee(net, paise=True)]], colWidths=[120 * mm, 58 * mm])
    nt.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), GREEN),
        ("TEXTCOLOR", (0, 0), (-1, -1), colors.white),
        ("FONTNAME", (0, 0), (-1, -1), "DV-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 11),
        ("ALIGN", (1, 0), (1, 0), "RIGHT"),
        ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    flow.append(nt)
    flow.append(Spacer(1, 2 * mm))
    flow.append(Paragraph("Net pay in words: Rupees Seventy Eight Thousand Five Hundred Only.", SMALL))
    flow.append(Spacer(1, 4 * mm))
    flow.append(Paragraph(
        "This is a computer-generated payslip and does not require a signature. "
        "For queries contact payroll@acme.example.com.", SMALL))
    return build_pdf("salary_slip.pdf", "Salary Slip", a["employer"], "Monthly Payslip", flow)


# ===========================================================================
# 2) BANK STATEMENT  (multi-page PDF with summary box + chart + ~30 txns)
# ===========================================================================
def _statement_transactions():
    """Generate ~30 realistic transactions across Mar–May 2026 with balances.

    Returns (rows, opening, total_dr, total_cr, closing, monthly_credits).
    Narrations mimic real channel strings (UPI/NEFT/IMPS/ECS/POS/ATM).
    """
    opening = 142360
    bal = opening
    rows = [["Date", "Value Date", "Narration", "Ref/Chq No.", "Withdrawal", "Deposit", "Balance"]]
    total_dr = total_cr = 0
    monthly_credits = {}
    months = [("Mar", "03"), ("Apr", "04"), ("May", "05")]
    salary = {"Mar": 78500, "Apr": 78500, "May": 78500}
    for mon, mm_ in months:
        events = [
            ("01", "NEFT CR/ACME TECH SOLUTIONS/SALARY MAY", f"N{mm_}26001", 0, salary[mon]),
            ("03", "UPI/DR/424%s@oksbi/Bigbazaar/Payment" % mm_, f"UPI{mm_}1102", 4380, 0),
            ("05", "ECS/SI DR/HDFC HOME LOAN EMI", f"ECS{mm_}5500", 18000, 0),
            ("09", "BIL/BBPS/HP STATE ELECTY BOARD", f"BIL{mm_}7781", 2240, 0),
            ("12", "POS/SWIGGY BANGALORE/CARD XX7788", f"POS{mm_}3321", 760, 0),
            ("16", "IMPS/P2A/Rent transfer/Mr Verma", f"IMP{mm_}9007", 12000, 0),
            ("20", "ACH/DR/SIP AXIS MF FLEXICAP", f"ACH{mm_}4410", 10000, 0),
            ("24", "ATW/CASH WDL/ATM MALL ROAD SHIMLA", f"ATM{mm_}0099", 6000, 0),
            ("28", "UPI/CR/Refund Amazon/426%s@ybl" % mm_, f"UPI{mm_}8820", 0, 1499),
            ("30", "INT.PD:SAV A/C INTEREST", f"INT{mm_}0001", 0, 318),
        ]
        cr_sum = 0
        for dd, narr, ref, dr, cr in events:
            bal = bal - dr + cr
            total_dr += dr
            total_cr += cr
            cr_sum += cr
            rows.append([f"{dd}-{mon}-26", f"{dd}-{mon}-26", narr, ref,
                         rupee(dr) if dr else "", rupee(cr) if cr else "", rupee(bal)])
        monthly_credits[mon] = cr_sum
    return rows, opening, total_dr, total_cr, bal, monthly_credits


def make_bank_statement() -> Path:
    """Build a multi-page bank statement with an account-summary box, an income
    bar chart (the FIGURE case), and a long transaction table that repeats its
    header across pages. Tests multi-page table extraction plus figure crop.
    """
    a = APPLICANT
    rows, opening, dr, cr, closing, mc = _statement_transactions()

    chart = OUT / "_chart.png"
    fig, ax = plt.subplots(figsize=(6, 2.4))
    ax.bar(list(mc.keys()), list(mc.values()), color="#16A34A")
    ax.set_title("Total monthly credits (INR)")
    for i, v in enumerate(mc.values()):
        ax.text(i, v, ind(v), ha="center", va="bottom", fontsize=8)
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(chart, dpi=120)
    plt.close(fig)

    flow = [Spacer(1, 2 * mm)]
    flow.append(kv_block([
        ("Account Holder", a["name"]), ("Customer ID", "CIF" + a["account_number"][-6:]),
        ("Account No.", a["account_number"]), ("Account Type", "Savings - Resident"),
        ("IFSC", a["ifsc"]), ("MICR", a["micr"]),
        ("Branch", a["branch"]), ("Currency", "INR"),
        ("Statement Period", "01-Mar-2026 to 31-May-2026"), ("Generated On", "03-Jun-2026"),
    ]))
    flow.append(Spacer(1, 3 * mm))
    flow.append(section("Account Summary"))
    flow.append(Spacer(1, 2 * mm))
    summ = [["Opening Balance", "Total Withdrawals", "Total Deposits", "Closing Balance", "Transactions"],
            [rupee(opening), rupee(dr), rupee(cr), rupee(closing), str(len(rows) - 1)]]
    st = data_table(summ, [38 * mm, 38 * mm, 36 * mm, 36 * mm, 30 * mm], repeat=False, font_size=8)
    flow.append(st)
    flow.append(Spacer(1, 3 * mm))
    flow.append(RLImage(str(chart), width=150 * mm, height=60 * mm))
    flow.append(Spacer(1, 3 * mm))
    flow.append(section("Transaction Details"))
    flow.append(Spacer(1, 2 * mm))
    cw = [16 * mm, 16 * mm, 70 * mm, 22 * mm, 18 * mm, 18 * mm, 18 * mm]
    flow.append(data_table(rows, cw, align_right=[4, 5, 6], font_size=7))
    flow.append(Spacer(1, 2 * mm))
    flow.append(Paragraph(
        "Legend: NEFT/IMPS/UPI/ACH electronic transfers; ECS standing instruction; "
        "POS card purchase; ATW ATM withdrawal; INT.PD interest paid. "
        "Closing balance carried forward. This statement is system generated.", SMALL))
    p = build_pdf("bank_statement.pdf", "Bank Statement", a["bank"], "Statement of Account", flow)
    chart.unlink(missing_ok=True)
    return p


# Checkbox glyphs (DejaVu renders these); used in the application form.
CHK, BOX = "☒", "☐"


def _check(selected: str, options: list[str]) -> str:
    """Render a row of checkbox options with the selected one ticked."""
    return "   ".join((CHK if o == selected else BOX) + " " + o for o in options)


# ===========================================================================
# 3) LOAN APPLICATION FORM  (multi-section, checkboxes, 2 pages)
# ===========================================================================
def make_application_form() -> Path:
    """Build a multi-section home-loan application form.

    Sections A–F cover loan details, personal, employment/income, existing
    obligations, references, and declaration, plus a 'for office use' box.
    Uses tick-box selection marks (☒/☐) to test Document Intelligence selection-
    mark detection alongside headings, key-values and tables across two pages.
    """
    a = APPLICANT
    flow = [Spacer(1, 2 * mm)]
    flow.append(Paragraph("Retail Home Loan Application Form", PB))
    flow.append(Paragraph(f"Application No.: {a['application_id']} &nbsp;&nbsp; Date: 02-Jun-2026", SMALL))
    flow.append(Spacer(1, 3 * mm))

    flow.append(section("A. Loan Details"))
    flow.append(Spacer(1, 1.5 * mm))
    flow.append(Paragraph("Product: " + _check("Home Loan", ["Home Loan", "Loan Against Property", "Top-up"]), P))
    flow.append(Spacer(1, 1 * mm))
    flow.append(kv_block([
        ("Loan Amount", rupee(a["loan_amount"])), ("Tenure (months)", str(a["loan_tenure_months"])),
        ("Purpose", a["loan_purpose"]), ("Collateral Value", rupee(a["collateral_value"])),
    ]))
    flow.append(Spacer(1, 3 * mm))

    flow.append(section("B. Applicant Personal Details"))
    flow.append(Spacer(1, 1.5 * mm))
    flow.append(kv_block([
        ("Full Name", a["name"]), ("Date of Birth", a["dob"]),
        ("PAN", a["pan"]), ("Aadhaar", a["aadhaar_masked"]),
        ("Mobile", a["mobile"]), ("Email", a["email"]),
        ("Address", a["address"]), ("Pincode", "171001"),
    ]))
    flow.append(Spacer(1, 1.5 * mm))
    flow.append(Paragraph("Gender: " + _check(a["gender"], ["Male", "Female", "Other"]), P))
    flow.append(Paragraph("Marital Status: " + _check(a["marital"], ["Single", "Married"]), P))
    flow.append(Paragraph("Residence: " + _check(a["residence"], ["Owned", "Rented", "Company-provided"]), P))
    flow.append(Spacer(1, 3 * mm))

    flow.append(section("C. Employment & Income"))
    flow.append(Spacer(1, 1.5 * mm))
    flow.append(Paragraph("Employment Type: " + _check("Salaried", ["Salaried", "Self-employed", "Professional"]), P))
    flow.append(Spacer(1, 1 * mm))
    flow.append(kv_block([
        ("Employer", a["employer"]), ("Designation", a["designation"]),
        ("Monthly Gross", rupee(a["monthly_gross"])), ("Monthly Net", rupee(a["monthly_net"])),
        ("Total Experience", "8 years"), ("Date of Joining", a["doj"]),
    ]))
    flow.append(Spacer(1, 3 * mm))

    flow.append(section("D. Existing Obligations"))
    flow.append(Spacer(1, 1.5 * mm))
    obl = [["Lender", "Type", "Monthly EMI", "Outstanding"],
           ["HDFC Bank", "Home Loan (existing)", rupee(a["monthly_emi_existing"]), rupee(a["existing_loan_outstanding"])],
           ["—", "Credit Card (revolving)", rupee(3500), rupee(42000)]]
    flow.append(data_table(obl, [55 * mm, 55 * mm, 34 * mm, 34 * mm], repeat=False, align_right=[2, 3]))
    flow.append(Spacer(1, 3 * mm))

    flow.append(section("E. References"))
    flow.append(Spacer(1, 1.5 * mm))
    flow.append(kv_block([
        ("Reference 1", "S. Negi, +91 9XXXXXXX01"), ("Relationship", "Colleague"),
        ("Reference 2", "P. Thakur, +91 9XXXXXXX02"), ("Relationship", "Relative"),
    ]))
    flow.append(Spacer(1, 3 * mm))

    flow.append(section("F. Declaration"))
    flow.append(Spacer(1, 1.5 * mm))
    flow.append(Paragraph(
        "I/We confirm that the information furnished above is true, complete and "
        "correct. I/We authorise the Bank and its agents to verify the information, "
        "obtain credit information reports, and exchange such information with "
        "credit bureaus and statutory authorities. I/We have read and understood "
        "the most important terms and conditions (MITC). FATCA status: Resident Indian.", P))
    flow.append(Spacer(1, 6 * mm))
    sign = Table([["_______________________", "_______________________"],
                  ["Applicant Signature", "Date"]], colWidths=[89 * mm, 89 * mm])
    sign.setStyle(TableStyle([("FONTNAME", (0, 0), (-1, -1), "DV"), ("FONTSIZE", (0, 0), (-1, -1), 8),
                              ("TEXTCOLOR", (0, 1), (-1, 1), colors.grey), ("TOPPADDING", (0, 1), (-1, 1), 0)]))
    flow.append(sign)
    flow.append(Spacer(1, 4 * mm))
    office = Table([["FOR OFFICE USE ONLY"],
                    ["Branch code: ________   Sourcing RM: ________   Login date: ________   "
                     "Recommended: ☐ Approve  ☐ Refer  ☐ Decline"]], colWidths=[CONTENT_W])
    office.setStyle(TableStyle([
        ("BOX", (0, 0), (-1, -1), 0.6, colors.grey), ("FONTNAME", (0, 0), (0, 0), "DV-Bold"),
        ("FONTNAME", (0, 1), (0, 1), "DV"), ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("BACKGROUND", (0, 0), (-1, 0), LIGHT), ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5), ("LEFTPADDING", (0, 0), (-1, -1), 6)]))
    flow.append(office)
    return build_pdf("loan_application_form.pdf", "Loan Application Form", a["bank"], "Retail Home Loan", flow)


# ===========================================================================
# 4) FORM 16 PART B  (income-tax certificate, nested financial tables)
# ===========================================================================
def make_form16() -> Path:
    """Build a Form 16 Part B style certificate (salary breakup + tax computation).

    Mirrors the real statutory layout: gross salary, exempt allowances u/s 10,
    deductions u/s 16, income chargeable, Chapter VI-A deductions, taxable income
    and the tax computation. Tests nested, label-heavy financial tables and is a
    second income-proof source for cross-checking the payslip.
    """
    a = APPLICANT
    annual_gross = a["monthly_gross"] * 12
    hra_exempt = 120000
    std_ded, pt = 50000, 2400
    income_salary = annual_gross - hra_exempt - std_ded - pt
    ch6a_80c, ch6a_80d = 150000, 25000
    taxable = income_salary - ch6a_80c - ch6a_80d
    tax = 12500 + int((taxable - 500000) * 0.20)
    cess = int(tax * 0.04)
    total_tax = tax + cess

    flow = [Spacer(1, 2 * mm)]
    flow.append(Paragraph("FORM NO. 16 — PART B (Annexure)", PB))
    flow.append(Paragraph("Certificate under Section 203 of the Income-tax Act, 1961 for tax "
                          "deducted at source on salary. Assessment Year 2026-27.", SMALL))
    flow.append(Spacer(1, 3 * mm))
    flow.append(kv_block([
        ("Employee", a["name"]), ("PAN of Employee", a["pan"]),
        ("Employer", a["employer"]), ("TAN of Deductor", "SMLA0XXXXG"),
        ("Period", "01-Apr-2025 to 31-Mar-2026"), ("Designation", a["designation"]),
    ]))
    flow.append(Spacer(1, 3 * mm))
    flow.append(section("Details of Salary Paid and Tax Computation"))
    flow.append(Spacer(1, 2 * mm))
    rows = [
        ["S.No", "Particulars", "Amount (₹)"],
        ["1", "Gross salary u/s 17(1)", rupee(annual_gross)],
        ["2", "Less: Allowances exempt u/s 10 (HRA)", rupee(hra_exempt)],
        ["3", "Less: Deduction u/s 16 (Standard Deduction)", rupee(std_ded)],
        ["4", "Less: Tax on Employment (Professional Tax)", rupee(pt)],
        ["5", "Income chargeable under head 'Salaries'", rupee(income_salary)],
        ["6", "Deductions Chapter VI-A: 80C", rupee(ch6a_80c)],
        ["7", "Deductions Chapter VI-A: 80D (Health Insurance)", rupee(ch6a_80d)],
        ["8", "Total taxable income", rupee(taxable)],
        ["9", "Tax on total income (old regime)", rupee(tax)],
        ["10", "Add: Health & Education Cess @ 4%", rupee(cess)],
        ["11", "Total tax payable", rupee(total_tax)],
        ["12", "Tax deducted at source (TDS)", rupee(total_tax)],
    ]
    flow.append(data_table(rows, [14 * mm, 122 * mm, 42 * mm], align_right=[2], font_size=8))
    flow.append(Spacer(1, 3 * mm))
    flow.append(Paragraph("Verification: I certify that the above information is true and "
                          "correct as per records. Place: Shimla. Date: 30-May-2026.", SMALL))
    return build_pdf("form16_partb.pdf", "Form 16 Part B", "Income Tax Department", "TDS Certificate on Salary", flow)


# ===========================================================================
# 5) CREDIT REPORT  (bureau report with a drawn score gauge)
# ===========================================================================
def make_credit_report() -> Path:
    """Build a credit-bureau report: a score gauge (PNG), an account summary,
    tradelines, and recent enquiries. Tests a mix of a figure plus several
    tables; the score (762) is an exact-match/authoritative cross-check.
    """
    a = APPLICANT
    score = a["credit_score"]

    gauge = OUT / "_gauge.png"
    fig, ax = plt.subplots(figsize=(6, 1.3))
    bands = [(300, 549, "#E24B4A"), (550, 649, "#EF9F27"), (650, 749, "#97C459"), (750, 900, "#16A34A")]
    for lo, hi, col in bands:
        ax.barh(0, hi - lo, left=lo, color=col, height=0.5)
    ax.axvline(score, color="#0C447C", lw=3)
    ax.text(score, 0.45, f"{score}", ha="center", color="#0C447C", fontsize=12, fontweight="bold")
    ax.set_xlim(300, 900)
    ax.set_yticks([])
    ax.set_xticks([300, 550, 650, 750, 900])
    ax.spines[["top", "right", "left"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(gauge, dpi=120)
    plt.close(fig)

    flow = [Spacer(1, 2 * mm)]
    flow.append(kv_block([
        ("Name", a["name"]), ("PAN", a["pan"]),
        ("Date of Birth", a["dob"]), ("Report Date", "01-Jun-2026"),
        ("Bureau", "DemoBureau"), ("Control No.", "CR-2026-998877"),
    ]))
    flow.append(Spacer(1, 3 * mm))
    flow.append(section("Credit Score  (range 300–900)"))
    flow.append(Spacer(1, 2 * mm))
    flow.append(RLImage(str(gauge), width=150 * mm, height=33 * mm))
    flow.append(Paragraph(f"Score band: <b>Excellent</b>. A score of {score} indicates a strong "
                          "repayment history and low credit risk.", P))
    flow.append(Spacer(1, 3 * mm))
    flow.append(section("Account Summary"))
    flow.append(Spacer(1, 2 * mm))
    summ = [["Total Accounts", "Active", "Overdue", "Total Sanctioned", "Total Outstanding"],
            ["3", "2", "0", rupee(1700000), rupee(a["existing_loan_outstanding"] + 42000)]]
    flow.append(data_table(summ, [34 * mm, 24 * mm, 24 * mm, 48 * mm, 48 * mm], repeat=False))
    flow.append(Spacer(1, 3 * mm))
    flow.append(section("Tradelines"))
    flow.append(Spacer(1, 2 * mm))
    tl = [["Lender", "Type", "Sanctioned", "Outstanding", "EMI", "Status", "DPD"],
          ["HDFC Bank", "Home Loan", rupee(1500000), rupee(a["existing_loan_outstanding"]), rupee(18000), "Standard", "0"],
          ["Demo Card Co", "Credit Card", rupee(200000), rupee(42000), rupee(3500), "Standard", "0"],
          ["Bajaj Fin", "Consumer Durable", rupee(0), rupee(0), rupee(0), "Closed", "0"]]
    flow.append(data_table(tl, [30 * mm, 30 * mm, 26 * mm, 26 * mm, 22 * mm, 24 * mm, 20 * mm],
                           align_right=[2, 3, 4], font_size=7.5))
    flow.append(Spacer(1, 3 * mm))
    flow.append(section("Recent Enquiries"))
    flow.append(Spacer(1, 2 * mm))
    enq = [["Date", "Member", "Purpose", "Amount"],
           ["02-Jun-2026", "Demo National Bank", "Home Loan", rupee(2500000)],
           ["18-Apr-2026", "Demo Card Co", "Credit Card", rupee(200000)]]
    flow.append(data_table(enq, [30 * mm, 60 * mm, 50 * mm, 38 * mm], repeat=False, align_right=[3]))
    p = build_pdf("credit_report.pdf", "Credit Report", "DemoBureau", "Credit Information Report", flow)
    gauge.unlink(missing_ok=True)
    return p


# ===========================================================================
# 6) SCANNED BANK STATEMENT  (image-only PDF, realistically degraded)
# ===========================================================================
def make_scanned_statement() -> Path:
    """Render a statement page to an image and degrade it like a poor scan
    (uneven lighting, sensor noise, slight skew, soft focus, JPEG artifacts).
    There is NO text layer, so the pipeline must OCR it — exercising per-token
    confidence and the null/quality guard on the lower-quality regions.
    """
    a = APPLICANT
    w, h = 1240, 1754  # ~150 DPI A4
    img = Image.new("L", (w, h), 255)
    d = ImageDraw.Draw(img)
    try:
        f = ImageFont.truetype(_DV, 26)
        fb = ImageFont.truetype(_DVB, 34)
    except OSError:
        f = fb = ImageFont.load_default()
    d.text((90, 90), f"{a['bank']}  (SPECIMEN)", fill=20, font=fb)
    lines = [
        f"Account Holder : {a['name']}",
        f"Account No.    : {a['account_number']}    IFSC: {a['ifsc']}",
        f"Period         : 01-May-2026 to 31-May-2026",
        "",
        "Date        Narration                         Withdrawal   Deposit    Balance",
        "01-May-26   NEFT CR ACME TECH SALARY                          78,500   2,03,500",
        "05-May-26   ECS DR HDFC HOME LOAN EMI            18,000                1,85,500",
        "12-May-26   POS SWIGGY CARD XX7788                  760                1,84,740",
        "16-May-26   IMPS RENT TRANSFER MR VERMA          12,000                1,72,740",
        "20-May-26   ACH SIP AXIS MF FLEXICAP             10,000                1,62,740",
        "24-May-26   ATW CASH WDL ATM MALL ROAD            6,000                1,56,740",
        "30-May-26   INT.PD SAV A/C INTEREST                              318   1,57,058",
        "",
        "Closing Balance : 1,57,058",
    ]
    y = 170
    for ln in lines:
        d.text((90, y), ln, fill=35, font=f)
        y += 56

    # DETERMINISTIC scan degradation (no RNG -> reproducible OCR confidence):
    # subtle vignette, slight skew, soft focus, heavy downscale, JPEG artifacts.
    vign = ImageOps.invert(Image.radial_gradient("L")).resize((w, h))
    vign = vign.point(lambda p: 205 + p // 6)          # light grey bg
    img = ImageChops.multiply(img, vign)               # dark text stays dark
    img = img.rotate(-1.0, fillcolor=235)              # slight skew
    img = img.filter(ImageFilter.GaussianBlur(1.3))    # soft focus
    img = img.resize((int(w * 0.55), int(h * 0.55))).resize((w, h))  # detail loss
    buf = io.BytesIO()
    img.convert("L").save(buf, "JPEG", quality=45)     # compression artifacts
    img = Image.open(buf)

    path = OUT / "bank_statement_scanned.pdf"
    img.convert("RGB").save(path, "PDF", resolution=72.0)
    print("  wrote bank_statement_scanned.pdf")
    return path


# ===========================================================================
# 7) FINANCIALS WORKBOOK  (XLSX: Transactions + Obligations + Summary)
# ===========================================================================
def make_financials_xlsx() -> Path:
    """Build a 3-sheet financial workbook with real formulas and formatting.

    'Transactions' (recent credits/debits), 'Obligations' (existing EMIs), and
    'Summary' (SUM/AVERAGE plus a DTI ratio formula). XLSX bypasses Document
    Intelligence and routes to the openpyxl/pandas extractor.
    """
    a = APPLICANT
    wb = Workbook()
    head = Font(bold=True, color="FFFFFF")
    fill = PatternFill("solid", fgColor="0C447C")

    ws = wb.active
    ws.title = "Transactions"
    ws.append(["Date", "Narration", "Withdrawal", "Deposit", "Balance"])
    data = [("01-May-26", "NEFT CR ACME TECH SALARY", 0, 78500, 203500),
            ("05-May-26", "ECS HDFC HOME LOAN EMI", 18000, 0, 185500),
            ("16-May-26", "IMPS RENT TRANSFER", 12000, 0, 173500),
            ("20-May-26", "ACH SIP AXIS MF", 10000, 0, 163500),
            ("30-May-26", "SAV INTEREST", 0, 318, 163818)]
    for r in data:
        ws.append(list(r))
    for c in ws[1]:
        c.font = head
        c.fill = fill
    for col, wdt in zip("ABCDE", [12, 32, 14, 12, 12]):
        ws.column_dimensions[col].width = wdt

    ws2 = wb.create_sheet("Obligations")
    ws2.append(["Lender", "Type", "Monthly EMI", "Outstanding"])
    ws2.append(["HDFC Bank", "Home Loan", a["monthly_emi_existing"], a["existing_loan_outstanding"]])
    ws2.append(["Demo Card Co", "Credit Card", 3500, 42000])
    ws2.append(["Total", "", "=SUM(C2:C3)", "=SUM(D2:D3)"])
    for c in ws2[1]:
        c.font = head
        c.fill = fill
    for col, wdt in zip("ABCD", [18, 16, 14, 14]):
        ws2.column_dimensions[col].width = wdt

    ws3 = wb.create_sheet("Summary")
    ws3.append(["Metric", "Value"])
    ws3.append(["Monthly Net Income", a["monthly_net"]])
    ws3.append(["Total Monthly EMI (existing)", "=Obligations!C4"])
    ws3.append(["Proposed New EMI (approx)", 21000])
    ws3.append(["Debt-to-Income Ratio", "=(B3+B4)/B2"])
    for c in ws3[1]:
        c.font = head
        c.fill = fill
    ws3["B5"].number_format = "0.0%"
    ws3.column_dimensions["A"].width = 30
    ws3.column_dimensions["B"].width = 16

    path = OUT / "financials.xlsx"
    wb.save(path)
    print("  wrote financials.xlsx")
    return path


# ===========================================================================
# 8) EMPLOYMENT VERIFICATION  (styled HTML)
# ===========================================================================
def make_employment_html() -> Path:
    """Build a styled HTML employment-verification letter (letterhead, prose,
    details table, signatory). Tests the HTML extractor on realistic markup.
    """
    a = APPLICANT
    html = f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><title>Employment Verification</title>
<style>
  body {{ font-family: Arial, Helvetica, sans-serif; color:#1f2937; max-width:760px; margin:24px auto; }}
  .lh {{ border-bottom:3px solid #16A34A; padding-bottom:8px; margin-bottom:18px; }}
  .lh h1 {{ color:#0C447C; margin:0; font-size:20px; }}
  .wm {{ color:#9ca3af; font-size:11px; }}
  table {{ border-collapse:collapse; width:100%; margin:14px 0; }}
  th,td {{ border:1px solid #d1d5db; padding:8px; text-align:left; font-size:14px; }}
  th {{ background:#EEF2F7; color:#0C447C; }}
  .sign {{ margin-top:36px; }}
</style></head>
<body>
  <!-- SPECIMEN: synthetic sample data, not a valid document -->
  <div class="lh"><h1>{a['employer']}</h1>
    <div class="wm">CIN {a['employer_cin']} · {a['address']} · SPECIMEN</div></div>
  <h2>Employment &amp; Income Verification</h2>
  <p>To Whom It May Concern,</p>
  <p>This is to certify that <strong>{a['name']}</strong> (Employee ID {a['emp_id']}) is
     employed with {a['employer']} as a <strong>{a['designation']}</strong> in the
     {a['department']} department since {a['doj']}. The compensation details below are
     provided at the employee's request for loan verification purposes.</p>
  <table>
    <tr><th>Field</th><th>Value</th></tr>
    <tr><td>Employee Name</td><td>{a['name']}</td></tr>
    <tr><td>PAN</td><td>{a['pan']}</td></tr>
    <tr><td>Monthly Gross Salary</td><td>{rupee(a['monthly_gross'])}</td></tr>
    <tr><td>Monthly Net Salary</td><td>{rupee(a['monthly_net'])}</td></tr>
    <tr><td>Employment Status</td><td>Permanent, full-time</td></tr>
    <tr><td>Date of Joining</td><td>{a['doj']}</td></tr>
  </table>
  <div class="sign"><p>For {a['employer']}</p><p><strong>Authorised Signatory</strong><br>
     Human Resources · verify@acme.example.com</p></div>
</body></html>"""
    path = OUT / "employment_verification.html"
    path.write_text(html, encoding="utf-8")
    print("  wrote employment_verification.html")
    return path


# ===========================================================================
# 9) AUTHORITATIVE FACTS  (SQLite + .sql)  — queried live, never embedded
# ===========================================================================
def make_database() -> tuple[Path, Path]:
    """Create the system-of-record DB of authoritative facts (income, obligations,
    credit score) used by the decision step. Per ADR-003 these are queried live
    and never embedded; one underwriter-notes row shows the narrative content
    that WOULD be indexed for semantic search.
    """
    a = APPLICANT
    db_path = OUT / "authoritative_facts.sqlite"
    sql_path = OUT / "seed_authoritative_facts.sql"
    db_path.unlink(missing_ok=True)
    seed = f"""
-- SPECIMEN: synthetic sample data, not a valid document.
CREATE TABLE applicant (application_id TEXT PRIMARY KEY, name TEXT, pan TEXT, dob TEXT);
CREATE TABLE income (application_id TEXT, monthly_gross INTEGER, monthly_net INTEGER, as_of TEXT);
CREATE TABLE obligations (application_id TEXT, lender TEXT, monthly_emi INTEGER, outstanding INTEGER);
CREATE TABLE credit_bureau (application_id TEXT, score INTEGER, bureau TEXT, pulled_on TEXT);
CREATE TABLE underwriter_notes (application_id TEXT, note TEXT, created_at TEXT);

INSERT INTO applicant VALUES ('{a['application_id']}','{a['name']}','{a['pan']}','{a['dob']}');
INSERT INTO income VALUES ('{a['application_id']}',{a['monthly_gross']},{a['monthly_net']},'2026-05-31');
INSERT INTO obligations VALUES ('{a['application_id']}','HDFC Bank',{a['monthly_emi_existing']},{a['existing_loan_outstanding']});
INSERT INTO obligations VALUES ('{a['application_id']}','Demo Card Co',3500,42000);
INSERT INTO credit_bureau VALUES ('{a['application_id']}',{a['credit_score']},'DemoBureau','2026-06-01');
INSERT INTO underwriter_notes VALUES ('{a['application_id']}','Applicant requested longer tenure to reduce EMI; salary stable over 6 months; collateral pending valuation.','2026-06-02');
""".strip()
    sql_path.write_text(seed, encoding="utf-8")
    conn = sqlite3.connect(db_path)
    conn.executescript(seed)
    conn.commit()
    conn.close()
    print("  wrote authoritative_facts.sqlite + seed_authoritative_facts.sql")
    return db_path, sql_path


# ===========================================================================
# Orchestration + manifest
# ===========================================================================
def main() -> None:
    """Generate the full specimen set and a manifest.json describing it."""
    print(f"Generating production-representative specimen documents into: {OUT}")
    make_salary_slip()
    make_bank_statement()
    make_application_form()
    make_form16()
    make_credit_report()
    make_scanned_statement()
    make_financials_xlsx()
    make_employment_html()
    make_database()
    manifest = {
        "applicant": APPLICANT,
        "documents": [
            {"file": "salary_slip.pdf", "source_kind": "pdf",
             "exercises": "key-value + dense earnings/deductions table",
             "expected_fields": {"monthly_gross": APPLICANT["monthly_gross"], "monthly_net": APPLICANT["monthly_net"]}},
            {"file": "bank_statement.pdf", "source_kind": "pdf",
             "exercises": "multi-page transaction table + account summary + income chart (FIGURE)"},
            {"file": "loan_application_form.pdf", "source_kind": "pdf",
             "exercises": "multi-section headings, selection marks (checkboxes), obligations table"},
            {"file": "form16_partb.pdf", "source_kind": "pdf",
             "exercises": "nested tax-computation financial table"},
            {"file": "credit_report.pdf", "source_kind": "pdf",
             "exercises": "score gauge (FIGURE) + tradelines + enquiries tables",
             "expected_fields": {"credit_score": APPLICANT["credit_score"]}},
            {"file": "bank_statement_scanned.pdf", "source_kind": "scanned_pdf",
             "exercises": "OCR + per-token confidence + null guard (image-only, degraded)"},
            {"file": "financials.xlsx", "source_kind": "xlsx",
             "exercises": "spreadsheet path (openpyxl); formulas + multi-sheet + DTI"},
            {"file": "employment_verification.html", "source_kind": "html",
             "exercises": "HTML extractor (letterhead + details table)"},
            {"file": "authoritative_facts.sqlite", "source_kind": "db",
             "exercises": "live authoritative-fact queries (never embedded)",
             "expected_facts": {"credit_score": APPLICANT["credit_score"], "monthly_emi_existing": APPLICANT["monthly_emi_existing"]}},
        ],
    }
    (OUT / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print("  wrote manifest.json")
    print("Done.")


if __name__ == "__main__":
    main()
