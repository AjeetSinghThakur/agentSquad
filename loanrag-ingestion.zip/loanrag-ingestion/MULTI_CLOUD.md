# Ingestion in Local, Azure, or GCP

Ingestion writes the clean chunks to whichever store you select with ONE setting,
`LOANRAG__BLOB__BACKEND` = `localfs` | `azure_blob` | `gcs`. Same code, different
destination — no copy step; it writes straight to the chosen store as
`loan-chunks/<application_id>/<doc>.json` (and originals to `loan-docs/`).

Run it:
```bash
./deploy/scripts/run-ingestion.sh local                       # ./_localblob
LOANRAG__BLOB__CONNECTION_STRING=... ./deploy/scripts/run-ingestion.sh azure
LOANRAG__BLOB__GCS_BUCKET=<bucket>   ./deploy/scripts/run-ingestion.sh gcp
```
Windows: `./deploy/scripts/run-ingestion.ps1 -Target gcp`

The decision stage (loanrag-loan-decision) then reads the SAME chunks from the
SAME backend. Full details + diagram: see MULTI_CLOUD.md in loanrag-loan-decision.
