# RAG_GUIDE — a beginner's guide to the LoanRAG pipeline

This explains, in plain language, what a RAG pipeline is, where the ingestion
you just ran fits in, how the **quality / null check** works, how **human review
(HITL)** works, and what each **KPI** means and *where* it is measured. It uses
your real sample (applicant **Ajeet Singh**, application `LOAN-2026-000123`).

---

## 1. What is RAG, in one paragraph

**RAG = Retrieval-Augmented Generation.** Instead of asking a language model to
answer from memory (where it can confidently make things up), you first
*retrieve* the relevant source text, then ask the model to answer *using only
that text*, with citations. For a loan, that means: when we ask "what is the
applicant's net monthly income?", the system finds the exact line in the salary
slip and answers from it — and if it can't find solid support, it says so
instead of guessing. RAG is what lets you trust the answer enough to make a
decision on it.

---

## 2. The whole loan pipeline, and where ingestion sits

Think of it as an assembly line. You have just built and run **Stage 1**.

```
   (Stage 1) INGESTION   <-- you are here
        |  read PDFs / scans / Excel / HTML / DB
        |  check quality, drop empty/low-confidence text
        |  send bad documents to a human (HITL)
        |  store clean, citable chunks in blob storage
        v
   (Stage 2) INDEXING
        |  turn each clean chunk into a vector (embedding) + keyword index
        v
   (Stage 3) RETRIEVAL
        |  for a question, fetch the most relevant chunks (vector + keyword)
        v
   (Stage 4) GROUNDED GENERATION
        |  answer using ONLY retrieved chunks, with citations; abstain if unsure
        v
   (Stage 5) DECISION + HUMAN APPROVAL (HITL)
        |  apply the lending policy; a human approves/rejects the final decision
```

Ingestion is the foundation: **garbage in, garbage out.** If a wrong number
gets in here (say an OCR misread of an EMI amount), every later stage will
faithfully serve that wrong number. That is exactly why Stage 1 has a quality
gate and a human-review step.

---

## 3. The quality / null check (what it does and why)

Every piece of text we extract becomes a **chunk**. Before any chunk is saved,
it goes through the **null/quality guard**. A chunk is **dropped (quarantined,
never written)** if it is:

- **empty** — no text at all (e.g. a blank or failed OCR page);
- **too short** — fewer than 3 characters (not real content);
- **low confidence** — for scanned documents, the OCR engine's confidence is
  below the threshold (default **0.70**). Your scanned bank statement had a
  worst-word confidence of **0.47**, so it was flagged;
- **garbage** — mostly noise characters (a sign of a bad scan).

This directly enforces your rule: **empty and no-confidence chunks are never
created** in the clean store. They are recorded in a quarantine report (with the
reason) so nothing disappears silently.

**Why confidence matters:** OCR on a poor scan is a *guess*. We carry that
uncertainty forward instead of trusting it blindly. A low-confidence digit in an
income figure is the difference between approving and rejecting a loan, so we
would rather pause than guess.

---

## 4. Human-in-the-loop (HITL) — how a bad document is handled

A single bad chunk is just dropped. But if a **whole document** looks unreliable
(fewer than 50% of its chunks pass, or none pass), we do **not** silently ingest
a half-empty document and we do **not** silently throw it away. Instead the
document is **parked** with status `pending_human_review`, and the pipeline
**pauses for that document** while continuing with the others.

A human then runs `review` to see what is waiting and why, and `resolve` with a
decision:

- **accept** — "I looked at the original; it's fine" → the extracted text is
  ingested (even the low-confidence chunks, because a human has vouched for it);
- **reject** — "unusable" → nothing is ingested; ask for a re-upload;
- **override** — "here is the correct text" → the human-typed content is
  ingested instead.

After the decision, the pipeline **resumes** for that document. You saw this
live: the scanned statement parked → you accepted it → it was ingested.

### How this maps to production (LangGraph)
Locally we use a simple JSON ledger to pause/resume — minimal moving parts. In
the production loan workflow this same pattern becomes a **LangGraph
`interrupt()`** with a **durable checkpointer**: the graph literally pauses at
the review node, persists its state, waits (could be hours/days) for a human's
input via `Command(resume=...)`, then continues exactly where it stopped. Same
idea you just used — accept / reject / override — but durable and resumable
across restarts. The final loan **approve/reject** in Stage 5 uses the very same
mechanism.

---

## 5. The KPIs — what each one means and where it's measured

These are how you *prove* the system is trustworthy. Some are measured at
ingestion (now), some at retrieval/decision (later). The `evaluate` command
computes the ingestion ones against `manifest.json` (the ground truth).

| KPI | Plain meaning | Measured where | Your result |
|---|---|---|---|
| **Exact-match rate** | Of the known field values, how many appear **exactly** in the extracted text (no fuzzy/approximate matching). | Ingestion | 3/3 = 100% (₹95,000 gross, ₹78,500 net, score 762) |
| **Null / quality detection** | Did we catch and drop empty/low-confidence text instead of storing it? | Ingestion | 1 low-confidence chunk quarantined; scan sent to HITL |
| **Completeness / completion decision** | Did every required document make it in (or get a human decision)? Only answer when coverage is complete. | Ingestion + Decision | 8/8 documents ingested |
| **Recall** | Of all the relevant chunks that *should* be retrieved for a question, what fraction *are* retrieved. Missing a relevant chunk = low recall. | Retrieval (Stage 3) | measured later |
| **False-positive rate** | How often the system returns/uses a chunk that is **not** actually relevant (or asserts a fact the source doesn't support). | Retrieval + Generation | measured later |

A few beginner notes:

- **"Exact match, no fuzzy"** means we check that the precise string (e.g.
  `78,500`) is present — we do **not** accept "close" values like `78,000`. For
  money and IDs, close is wrong. That is why `evaluate` uses exact substring
  matching after formatting numbers the way the documents render them (Indian
  digit grouping).
- **Recall vs. false-positive is a trade-off.** Retrieve more chunks → higher
  recall but more false positives (noise). Retrieve fewer → cleaner but you may
  miss something. The retrieval stage tunes this; ingestion's job is to make
  sure the chunks that *exist* are clean and citable.
- **The decision should abstain, not guess.** If the needed fact isn't
  confidently retrievable, the right behaviour is "insufficient evidence →
  human", not a confident wrong answer. Completeness gates the decision.

---

## 6. Why the database is treated differently

You have authoritative numbers in a database (income, obligations, credit
score). These are **not** ingested as chunks. They are queried **live** at
decision time by the loan RAG, because a cached copy can go stale and produce a
"grounded but wrong" answer. Only **narrative** DB text (e.g. underwriter notes)
is ingested. `evaluate` confirms the authoritative facts are absent from the
clean store — that absence is *correct*, by design.

---

## 7. What ingestion produced for the next stage

In blob storage you now have two containers (locally in Azurite; in cloud, real
Azure Blob):

- **`loan-docs`** — the original files, so a reviewer can always open the source.
- **`loan-chunks`** — clean, quality-passed chunks as JSON, one file per
  document. Each chunk carries its text, source type, page, confidence, and a
  deterministic id.

The loan RAG (Stage 2 onward) reads `loan-chunks`, embeds them, and indexes them
for retrieval. **Nothing needs to be re-ingested** — the same data, same schema,
flows straight into the next stage. To run it, see `LOCAL_RUN.md`.
