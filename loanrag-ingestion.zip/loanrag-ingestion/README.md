# LoanRAG — Ingestion subsystem

Reads loan documents (born-digital PDF, **scanned PDF via OCR**, XLSX, HTML, and
a narrative database), runs a **quality / null guard**, routes low-quality
documents to a **human-in-the-loop (HITL)** review, and uploads the clean,
citable chunks to **blob storage** (Azurite locally → real Azure Blob in the
cloud) for reuse by the loan RAG. Applicant in the sample data: **Ajeet Singh**
(`LOAN-2026-000123`).

## Start here
- **`LOCAL_RUN.md`** — run it on your machine in Docker (Azurite) or bare Python.
- **`RAG_GUIDE.md`** — beginner guide: what RAG is, where ingestion fits, how the
  quality check and HITL work, and what every KPI means (exact-match, recall,
  false-positive, completeness, null-detection).

## At a glance
```bash
docker compose up -d azurite
docker compose run --rm ingestion ingest     # read inbox -> quality gate -> blob
docker compose run --rm ingestion review      # see anything parked for a human
docker compose run --rm ingestion resolve --document-id <id> --decision accept
docker compose run --rm ingestion verify       # what is in blob + ledger + quarantine
docker compose run --rm ingestion evaluate     # KPIs vs ground truth (exact match)
```

## Layout (Clean Architecture)
```
loanrag/
  config/          settings (LOANRAG__Section__Key env binding)
  domain/          entities, value objects, enums, protocols (interfaces)
  infrastructure/
    extraction/    pdf-text, scanned-OCR (Tesseract), xlsx, html, db, router
    chunking/      layout chunker + null/quality guard
    persistence/   Azurite/local blob store + ingestion ledger (status/HITL)
  application/     ingestion_service (extract -> chunk -> guard -> HITL -> blob)
  presentation/    cli (ingest / review / resolve / verify / evaluate)
samples/           synthetic document generator (Ajeet Singh)
Dockerfile, docker-compose.yml, requirements.txt
```

Each extractor implements the same `IDocumentExtractor` protocol, so switching
local OSS (Tesseract/pdfplumber) → Azure Document Intelligence in the cloud is a
configuration change, not a code change. Same for the blob store.
