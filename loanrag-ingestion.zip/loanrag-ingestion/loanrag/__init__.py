"""LoanRAG ingestion package."""
