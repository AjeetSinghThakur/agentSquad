"""Ingestion service — the orchestrator for one document.

PIPELINE PER FILE
-----------------
  1. hash the bytes (idempotency) and build a RawDocument
  2. upload the RAW file to blob (loan-docs) so the loan RAG can show originals
  3. route to the right extractor -> ExtractedDocument
  4. chunk into IndexableChunks (one per block), stamping the content hash
  5. run the null/quality guard on every chunk
        - failing chunks are QUARANTINED (recorded, never persisted)
  6. QUALITY GATE:
        - if too few chunks pass (pass_rate < HITL min_pass_rate) OR none pass,
          the whole document is PARKED for human review (status
          'pending_human_review') and NOTHING is written to loan-chunks
        - otherwise the passing chunks are written to blob (loan-chunks) and the
          document is marked 'ingested'
  7. a human later resolves parked documents (accept / reject / override),
     and the pipeline resumes from where it paused.

This guarantees your rule: empty or low-confidence chunks are never created in
the clean store, and a low-quality document goes to a human rather than being
silently dropped or half-ingested.
"""

from __future__ import annotations

import dataclasses
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path

from loanrag.config.settings import Settings
from loanrag.domain.entities.indexable_chunk import IndexableChunk
from loanrag.domain.entities.raw_document import RawDocument
from loanrag.domain.enums import BlockKind, IngestionStatus, SourceKind


def _chunk_to_dict(chunk: IndexableChunk) -> dict:
    """Serialise an IndexableChunk to a JSON-safe dict (enums->str, dates->iso)."""
    d = dataclasses.asdict(chunk)
    d["kind"] = chunk.kind.value
    d["source_kind"] = chunk.source_kind.value
    d["indexed_at"] = chunk.indexed_at.isoformat() if chunk.indexed_at else None
    return d


class IngestionService:
    """Coordinates extraction, quality gating, HITL and blob writes."""

    def __init__(self, settings: Settings, router, chunker, guard, blob, ledger) -> None:
        """Wire in the collaborators (all behind protocols / interfaces)."""
        self._s = settings
        self._router = router
        self._chunker = chunker
        self._guard = guard
        self._blob = blob
        self._ledger = ledger
        self._hitl_dir = Path(settings.paths.state_dir) / "hitl"
        self._hitl_dir.mkdir(parents=True, exist_ok=True)
        self._quarantine_path = Path(settings.paths.state_dir) / "quarantine.json"

    # ---- main entrypoint ------------------------------------------------- #
    async def ingest_file(self, path: Path, application_id: str) -> dict:
        """Run the full pipeline for one file and return a short result dict."""
        data = path.read_bytes()
        sha = hashlib.sha256(data).hexdigest()
        document_id = self._doc_id(application_id, path.name)

        # Idempotency / resume: skip files already done or awaiting a human.
        existing = self._ledger.get(document_id)
        if existing and existing.get("status") == IngestionStatus.INGESTED and existing.get("sha") == sha:
            return {"document_id": document_id, "status": "skipped (already ingested)"}
        if existing and existing.get("status") == IngestionStatus.PENDING_HUMAN_REVIEW:
            return {"document_id": document_id, "status": "skipped (awaiting human review)"}

        raw = RawDocument(
            document_id=document_id, application_id=application_id, filename=path.name,
            mime_type=self._mime(path), content_sha256=sha, size_bytes=len(data),
            blob_uri=str(path),  # extractors read the local file; raw bytes also go to blob
            received_at=datetime.now(timezone.utc),
        )

        # Step 2: stash the original in blob storage for later reuse.
        await self._blob.put(self._s.blob.raw_container, f"{application_id}/{path.name}",
                             data, raw.mime_type)

        # Step 3: pick an extractor.
        extractor = self._router.select(raw)
        if extractor is None:
            self._ledger.upsert(document_id, status=IngestionStatus.UNREADABLE, sha=sha,
                                filename=path.name, reason="no extractor for this file type")
            return {"document_id": document_id, "status": "unreadable (unsupported type)"}

        # Steps 4-5: extract, chunk, stamp hash, run the guard.
        # A corrupt / unreadable / mislabelled file (e.g. a non-xlsx with an
        # .xlsx name, or an Excel ~$ lock file) must NOT abort the whole batch.
        # We catch it, mark the document unreadable, and let the loop continue.
        try:
            extracted = await extractor.extract(raw)
            chunks = [dataclasses.replace(c, content_sha256=sha)
                      for c in self._chunker.chunk(extracted)]
        except Exception as exc:
            self._ledger.upsert(document_id, status=IngestionStatus.UNREADABLE, sha=sha,
                                filename=path.name,
                                reason=f"extraction failed: {type(exc).__name__}: {exc}")
            return {"document_id": document_id,
                    "status": f"unreadable (extraction error: {type(exc).__name__})"}
        passed, quarantined = [], []
        for c in chunks:
            verdict = self._guard.inspect(c)
            (passed if verdict.passed else quarantined).append((c, verdict))
        self._record_quarantine(document_id, quarantined)

        total = len(chunks)
        pass_rate = (len(passed) / total) if total else 0.0

        # Step 6: the quality gate / HITL decision.
        if total == 0 or pass_rate < self._s.hitl.min_pass_rate:
            self._park_for_review(raw, passed, quarantined, pass_rate)
            return {"document_id": document_id,
                    "status": "PENDING HUMAN REVIEW",
                    "pass_rate": round(pass_rate, 2),
                    "passed": len(passed), "quarantined": len(quarantined)}

        await self._write_chunks(application_id, document_id, [c for c, _ in passed])
        self._ledger.upsert(document_id, status=IngestionStatus.INGESTED, sha=sha,
                            filename=path.name, source_kind=extracted.provenance.source_kind.value,
                            chunks_written=len(passed), quarantined=len(quarantined),
                            pass_rate=round(pass_rate, 2))
        return {"document_id": document_id, "status": "ingested",
                "chunks_written": len(passed), "quarantined": len(quarantined)}

    # ---- HITL resume ----------------------------------------------------- #
    async def resolve_review(self, document_id: str, decision: str,
                             note: str = "", corrected_text: str = "") -> dict:
        """Apply a human's decision to a parked document and resume the pipeline.

        decision = 'accept'   -> ingest the chunks that passed the guard
                   'reject'   -> mark unreadable (e.g. ask for re-upload)
                   'override' -> ingest human-supplied corrected_text as content
        """
        review = self._load_review(document_id)
        if review is None:
            return {"document_id": document_id, "status": "no pending review found"}
        app = review["application_id"]

        if decision == "reject":
            self._ledger.upsert(document_id, status=IngestionStatus.UNREADABLE,
                                hitl_decision="reject", hitl_note=note)
            return {"document_id": document_id, "status": "rejected by reviewer"}

        if decision == "override" and corrected_text.strip():
            # Build a single human-verified chunk; still run it past the guard.
            chunk = IndexableChunk(
                chunk_id=f"{document_id}:human-override", application_id=app,
                document_id=document_id, kind=BlockKind.PARAGRAPH, text=corrected_text.strip(),
                source_kind=SourceKind(review["source_kind"]), extractor_version="human@1.0",
                content_sha256=review["sha"], min_token_confidence=1.0, inferred=False)
            verdict = self._guard.inspect(chunk)
            if not verdict.passed:
                return {"document_id": document_id, "status": f"override still fails guard: {verdict.reasons}"}
            await self._write_chunks(app, document_id, [chunk])
            self._ledger.upsert(document_id, status=IngestionStatus.INGESTED,
                                hitl_decision="override", hitl_note=note, chunks_written=1)
            return {"document_id": document_id, "status": "ingested via human override"}

        # decision == 'accept': the human has inspected the original and vouches
        # for it, so we ingest the extracted content (even low-confidence chunks
        # the guard had quarantined). Empty chunks are still skipped.
        accepted = [self._dict_to_chunk(c) for c in review.get("chunks", review.get("passed_chunks", []))]
        accepted = [c for c in accepted if (c.text or "").strip()]
        if not accepted:
            return {"document_id": document_id, "status": "accept failed: nothing readable to ingest (use override or reject)"}
        await self._write_chunks(app, document_id, accepted)
        self._ledger.upsert(document_id, status=IngestionStatus.INGESTED,
                            hitl_decision="accept", hitl_note=note, chunks_written=len(accepted))
        return {"document_id": document_id, "status": "ingested (human-accepted)", "chunks_written": len(accepted)}

    # ---- helpers --------------------------------------------------------- #
    async def _write_chunks(self, app: str, document_id: str, chunks: list[IndexableChunk]) -> None:
        """Write the clean chunks as one JSON blob under loan-chunks."""
        payload = [_chunk_to_dict(dataclasses.replace(c, indexed_at=datetime.now(timezone.utc)))
                   for c in chunks]
        body = json.dumps(payload, indent=2).encode("utf-8")
        key = f"{app}/{document_id}.json"
        await self._blob.put(self._s.blob.chunks_container, key, body, "application/json")

    def _park_for_review(self, raw: RawDocument, passed, quarantined, pass_rate: float) -> None:
        """Persist a review record and mark the document pending_human_review."""
        preview = " ".join([c.text for c, _ in (passed + quarantined)][:1])[:600]
        review = {
            "document_id": raw.document_id, "application_id": raw.application_id,
            "filename": raw.filename, "sha": raw.content_sha256,
            "source_kind": (passed + quarantined)[0][0].source_kind.value if (passed or quarantined) else "unknown",
            "pass_rate": round(pass_rate, 2),
            "preview": preview,
            "quarantine_reasons": [{"chunk_id": v.chunk_id, "reasons": v.reasons} for _, v in quarantined],
            "passed_chunks": [_chunk_to_dict(c) for c, _ in passed],
            # All extracted chunks (passed + quarantined): a human who inspects the
            # original may vouch for the document and ingest these via 'accept'.
            "chunks": [_chunk_to_dict(c) for c, _ in (passed + quarantined)],
        }
        (self._hitl_dir / f"{raw.document_id}.json").write_text(
            json.dumps(review, indent=2), encoding="utf-8")
        self._ledger.upsert(raw.document_id, status=IngestionStatus.PENDING_HUMAN_REVIEW,
                            sha=raw.content_sha256, filename=raw.filename,
                            source_kind=review["source_kind"], pass_rate=round(pass_rate, 2),
                            quarantined=len(quarantined), passed=len(passed))

    def _load_review(self, document_id: str) -> dict | None:
        """Load a parked review record, if present."""
        path = self._hitl_dir / f"{document_id}.json"
        return json.loads(path.read_text(encoding="utf-8")) if path.exists() else None

    def _record_quarantine(self, document_id: str, quarantined) -> None:
        """Append quarantined-chunk reasons to the quarantine report file."""
        existing = {}
        if self._quarantine_path.exists():
            existing = json.loads(self._quarantine_path.read_text(encoding="utf-8"))
        existing[document_id] = [{"chunk_id": v.chunk_id, "reasons": v.reasons} for _, v in quarantined]
        self._quarantine_path.write_text(json.dumps(existing, indent=2), encoding="utf-8")

    def _dict_to_chunk(self, d: dict) -> IndexableChunk:
        """Rebuild an IndexableChunk from a stored dict (for HITL accept)."""
        d = dict(d)
        d["kind"] = BlockKind(d["kind"])
        d["source_kind"] = SourceKind(d["source_kind"])
        d["indexed_at"] = None
        return IndexableChunk(**d)

    @staticmethod
    def _doc_id(application_id: str, filename: str) -> str:
        """Deterministic, filesystem-safe document id (stable across re-runs)."""
        stem = re.sub(r"[^A-Za-z0-9_.-]", "_", filename)
        return f"{application_id}__{stem}"

    @staticmethod
    def _mime(path: Path) -> str:
        """Best-effort MIME type from the file extension."""
        ext = path.suffix.lower()
        return {".pdf": "application/pdf", ".xlsx": "application/vnd.openxmlformats",
                ".html": "text/html", ".htm": "text/html",
                ".sqlite": "application/x-sqlite3", ".db": "application/x-sqlite3"}.get(ext, "application/octet-stream")
