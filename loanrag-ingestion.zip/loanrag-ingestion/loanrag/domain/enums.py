"""Enumerations shared across the domain model."""

from enum import StrEnum


class BlockKind(StrEnum):
    """The kind of a logical content block."""

    PARAGRAPH = "paragraph"
    TABLE = "table"
    FIGURE = "figure"
    KEY_VALUE = "key_value"
    LIST = "list"


class SourceKind(StrEnum):
    """The originating source type of a document."""

    PDF = "pdf"
    SCANNED_PDF = "scanned_pdf"
    IMAGE = "image"
    XLSX = "xlsx"
    DOCX = "docx"
    PPTX = "pptx"
    HTML = "html"
    DB = "db"
    UNKNOWN = "unknown"


class ChunkStatus(StrEnum):
    """Lifecycle status of an indexable chunk."""

    PENDING = "pending"
    INDEXED = "indexed"
    QUARANTINED = "quarantined"


class IngestionStatus(StrEnum):
    """Lifecycle status of a document moving through ingestion."""

    RECEIVED = "received"
    EXTRACTING = "extracting"
    CHUNKING = "chunking"
    GUARDING = "guarding"
    EMBEDDING = "embedding"
    INDEXING = "indexing"
    INDEXED = "indexed"
    INGESTED = "ingested"                       # clean chunks written to blob (success)
    PENDING_HUMAN_REVIEW = "pending_human_review"  # failed quality gate -> HITL
    UNREADABLE = "unreadable"
    REJECTED = "rejected"                       # human declined to ingest
    DEAD_LETTER = "dead_letter"
