"""Domain layer: entities, value objects, enums, and protocols."""
