"""Money value object."""

from dataclasses import dataclass
from decimal import Decimal


@dataclass(frozen=True)
class Money:
    """An immutable monetary amount with an ISO 4217 currency code."""

    amount: Decimal
    currency: str = "INR"

    def __post_init__(self) -> None:
        """Validate the amount type and currency code length."""
        if not isinstance(self.amount, Decimal):
            raise TypeError("Money.amount must be a Decimal")
        if len(self.currency) != 3:
            raise ValueError("Money.currency must be a 3-letter ISO code")
