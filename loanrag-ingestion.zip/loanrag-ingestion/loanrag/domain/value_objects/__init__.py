"""Domain value objects."""
