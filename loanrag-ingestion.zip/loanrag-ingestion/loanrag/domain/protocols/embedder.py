"""IEmbedder protocol."""

from typing import Protocol, runtime_checkable


@runtime_checkable
class IEmbedder(Protocol):
    """Produces embedding vectors for a batch of texts."""

    async def embed(self, texts: list[str]) -> list[list[float]]:
        """Return one embedding vector per input text, in input order."""
        ...
