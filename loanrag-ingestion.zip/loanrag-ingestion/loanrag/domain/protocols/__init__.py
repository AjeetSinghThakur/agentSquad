"""Domain protocols (interfaces / seams for dependency inversion)."""
