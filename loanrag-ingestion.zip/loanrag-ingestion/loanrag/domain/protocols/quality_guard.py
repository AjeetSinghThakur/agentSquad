"""IQualityGuard protocol."""

from typing import Protocol, runtime_checkable

from loanrag.domain.entities.chunk_quality import ChunkQuality
from loanrag.domain.entities.indexable_chunk import IndexableChunk


@runtime_checkable
class IQualityGuard(Protocol):
    """Detects null / garbage / low-quality chunks before indexing."""

    def inspect(self, chunk: IndexableChunk) -> ChunkQuality:
        """Return a pass/fail quality verdict with reasons for one chunk."""
        ...
