"""IIngestionLedger protocol."""

from typing import Protocol, runtime_checkable


@runtime_checkable
class IIngestionLedger(Protocol):
    """Tracks idempotency and per-chunk ingestion status."""

    async def already_done(self, chunk_id: str, extractor_version: str) -> bool:
        """Return True if this chunk was already produced by this extractor version."""
        ...

    async def mark(self, chunk_id: str, status: str, detail: dict[str, object]) -> None:
        """Record the ingestion status of a chunk."""
        ...
