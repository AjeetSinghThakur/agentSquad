"""IBlobStore protocol."""

from typing import Protocol, runtime_checkable


@runtime_checkable
class IBlobStore(Protocol):
    """Stores and retrieves raw document bytes and figure crops."""

    async def put(self, key: str, data: bytes, content_type: str) -> str:
        """Store bytes under a key and return the blob URI."""
        ...

    async def get(self, key: str) -> bytes:
        """Retrieve previously stored bytes by key."""
        ...
