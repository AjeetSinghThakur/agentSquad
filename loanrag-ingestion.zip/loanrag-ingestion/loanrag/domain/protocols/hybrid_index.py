"""IHybridIndex protocol."""

from collections.abc import Sequence
from typing import Protocol, runtime_checkable

from loanrag.domain.entities.indexable_chunk import IndexableChunk


@runtime_checkable
class IHybridIndex(Protocol):
    """Hybrid vector + keyword index for indexable chunks."""

    async def upsert(self, chunks: Sequence[IndexableChunk]) -> None:
        """Insert or update chunks in the index (idempotent on chunk_id)."""
        ...
