"""IChunker protocol."""

from typing import Protocol, runtime_checkable

from loanrag.domain.entities.extracted_document import ExtractedDocument
from loanrag.domain.entities.indexable_chunk import IndexableChunk


@runtime_checkable
class IChunker(Protocol):
    """Splits an extracted document into indexable chunks."""

    def chunk(self, doc: ExtractedDocument) -> list[IndexableChunk]:
        """Produce indexable chunks with deterministic ids from a document."""
        ...
