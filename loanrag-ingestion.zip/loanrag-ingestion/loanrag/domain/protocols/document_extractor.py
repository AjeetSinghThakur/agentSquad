"""IDocumentExtractor protocol."""

from typing import Protocol, runtime_checkable

from loanrag.domain.entities.extracted_document import ExtractedDocument
from loanrag.domain.entities.raw_document import RawDocument


@runtime_checkable
class IDocumentExtractor(Protocol):
    """Turns one raw document into the canonical ExtractedDocument."""

    def supports(self, doc: RawDocument) -> bool:
        """Return True if this extractor can handle the given document."""
        ...

    async def extract(self, doc: RawDocument) -> ExtractedDocument:
        """Extract structured content from the raw document."""
        ...
