"""RawDocument entity."""

from dataclasses import dataclass
from datetime import datetime


@dataclass(frozen=True)
class RawDocument:
    """A source artifact exactly as received, before any extraction."""

    document_id: str
    application_id: str
    filename: str
    mime_type: str
    content_sha256: str
    size_bytes: int
    blob_uri: str
    received_at: datetime
