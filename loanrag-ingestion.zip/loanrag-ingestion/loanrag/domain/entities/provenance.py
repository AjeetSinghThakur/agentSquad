"""Provenance entity (where extracted content came from)."""

from dataclasses import dataclass
from datetime import datetime

from loanrag.domain.enums import SourceKind


@dataclass(frozen=True)
class Provenance:
    """Where an extracted document came from and what produced it."""

    source_kind: SourceKind
    extractor: str
    extractor_version: str
    source_ref: str
    extracted_at: datetime
    model_version: str | None = None
