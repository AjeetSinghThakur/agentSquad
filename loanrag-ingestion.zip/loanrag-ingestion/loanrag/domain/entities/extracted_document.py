"""ExtractedDocument entity (the canonical model every extractor produces)."""

from dataclasses import dataclass, field

from loanrag.domain.entities.provenance import Provenance
from loanrag.domain.entities.section import Section


@dataclass(frozen=True)
class ExtractedDocument:
    """The normalized structure any extractor must produce.

    This is the contract that decouples *how* a source is read from how it is
    chunked, guarded, indexed, and audited.
    """

    document_id: str
    application_id: str
    provenance: Provenance
    sections: list[Section] = field(default_factory=list)
    contract_version: str = "1.0"
