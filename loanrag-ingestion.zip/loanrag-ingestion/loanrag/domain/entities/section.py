"""Section entity (a heading and its ordered blocks)."""

from dataclasses import dataclass, field

from loanrag.domain.entities.block import Block


@dataclass(frozen=True)
class Section:
    """A heading and its ordered content blocks."""

    section_id: str
    heading: str | None
    blocks: list[Block] = field(default_factory=list)
