"""ChunkQuality entity (verdict of the null / quality guard)."""

from dataclasses import dataclass, field


@dataclass(frozen=True)
class ChunkQuality:
    """The pass/fail verdict of the null / quality guard for one chunk."""

    chunk_id: str
    passed: bool
    reasons: list[str] = field(default_factory=list)
