"""IndexableChunk entity (the unit that is embedded and indexed)."""

from dataclasses import dataclass, field
from datetime import datetime


from loanrag.domain.enums import BlockKind, SourceKind


@dataclass(frozen=True)
class IndexableChunk:
    """The unit that is embedded and indexed.

    Carries everything downstream needs: retrieval filtering (application_id),
    grounding citations (chunk_id, page, bounding_region), the null guard
    (min_token_confidence), and audit (extractor_version, content_sha256).
    `chunk_id` is deterministic (f"{document_id}:{block_id}") for idempotency.
    """

    chunk_id: str
    application_id: str
    document_id: str
    kind: BlockKind
    text: str
    source_kind: SourceKind
    extractor_version: str
    content_sha256: str
    parent_chunk_id: str | None = None
    page: int | None = None
    bounding_region: list[float] | None = None
    min_token_confidence: float = 1.0
    inferred: bool = False
    embedding: list[float] | None = None
    indexed_at: datetime | None = None
    extra: dict[str, object] = field(default_factory=dict)
