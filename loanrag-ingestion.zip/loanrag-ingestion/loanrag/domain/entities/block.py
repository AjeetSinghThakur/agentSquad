"""Block entity (a single logical unit of extracted content)."""

from dataclasses import dataclass, field


from loanrag.domain.enums import BlockKind


@dataclass(frozen=True)
class Block:
    """One logical unit of content with provenance and quality signals.

    `min_token_confidence` is 1.0 for born-digital / DB sources and is the
    per-token OCR confidence for scanned sources (feeds the null guard).
    `inferred` is True when an LLM/VLM produced the content.
    """

    block_id: str
    kind: BlockKind
    text: str
    page: int | None = None
    bounding_region: list[float] | None = None
    min_token_confidence: float = 1.0
    inferred: bool = False
    extra: dict[str, object] = field(default_factory=dict)
