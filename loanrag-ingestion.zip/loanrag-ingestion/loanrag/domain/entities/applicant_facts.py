"""ApplicantFacts entity (authoritative facts, queried live, never embedded)."""

from dataclasses import dataclass
from datetime import datetime

from loanrag.domain.value_objects.money import Money


@dataclass(frozen=True)
class ApplicantFacts:
    """Authoritative facts queried live from the system of record at decision
    time. Per ADR-003 these are never embedded or cached as chunks.
    """

    monthly_income: Money
    monthly_obligations: Money
    credit_score: int
    as_of: datetime
    source_query_id: str
    collateral_value: Money | None = None
