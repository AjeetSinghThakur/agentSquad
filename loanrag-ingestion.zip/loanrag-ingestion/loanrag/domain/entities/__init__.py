"""Domain entities."""
