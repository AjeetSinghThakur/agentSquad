"""LoanRAG ingestion CLI.

Subcommands:
  ingest    Read every file in the inbox, run the pipeline, write to blob.
  review    List documents parked for human review (HITL queue).
  resolve   Apply a human decision (accept/reject/override) to a parked doc.
  verify    Show what is in blob storage + the ledger + the quarantine report.
  evaluate  Score the KPIs (exact-match, completeness, quality) vs manifest.json.

Run:  python -m loanrag.presentation.cli <subcommand> [options]
"""

from __future__ import annotations

import argparse
import asyncio
import json
import re
from pathlib import Path

from loanrag.application.ingestion_service import IngestionService
from loanrag.config.settings import get_settings
from loanrag.infrastructure.chunking.layout_chunker import LayoutChunker
from loanrag.infrastructure.chunking.null_guard import NullGuard
from loanrag.infrastructure.extraction.router import ExtractorRouter
from loanrag.infrastructure.persistence.blob_store import make_blob_store
from loanrag.infrastructure.persistence.ingestion_ledger import IngestionLedger

SUPPORTED = {".pdf", ".xlsx", ".xlsm", ".html", ".htm", ".sqlite", ".db"}
DEFAULT_APP = "LOAN-2026-000123"


def _ind(n: int) -> str:
    """Indian digit grouping (same format the documents render), e.g. 95000 -> 95,000."""
    s = str(int(n))
    if len(s) > 3:
        last3, rest = s[-3:], s[:-3]
        rest = re.sub(r"(\d)(?=(\d\d)+$)", r"\1,", rest)
        s = rest + "," + last3
    return s


def build_service():
    """Composition root: assemble the IngestionService from settings."""
    s = get_settings()
    guard = NullGuard(s.guard.min_confidence, s.guard.min_chars, s.guard.max_garbage_ratio)
    service = IngestionService(
        settings=s, router=ExtractorRouter(), chunker=LayoutChunker(),
        guard=guard, blob=make_blob_store(s.blob), ledger=IngestionLedger(s.paths.state_dir))
    return service, s


# --------------------------------------------------------------------------- #
def cmd_ingest(args) -> None:
    """Ingest every supported file in the inbox folder."""
    service, s = build_service()
    inbox = Path(s.paths.inbox)
    files = [p for p in sorted(inbox.iterdir())
             if p.is_file() and p.suffix.lower() in SUPPORTED
             and not p.name.startswith("~$")   # Excel lock files
             and not p.name.startswith(".")]    # hidden / temp files
    if not files:
        print(f"No supported files in {inbox.resolve()}")
        return
    print(f"Ingesting {len(files)} file(s) from {inbox} (application {args.application_id})\n")

    async def run():
        for p in files:
            # Final safety net: one unexpected error never aborts the batch.
            try:
                result = await service.ingest_file(p, args.application_id)
            except Exception as exc:
                result = {"status": f"ERROR ({type(exc).__name__}): {exc}"}
            print(f"  {p.name:32s} -> {result.get('status')}"
                  + (f"  [pass_rate={result['pass_rate']}, passed={result['passed']}, "
                     f"quarantined={result['quarantined']}]" if "pass_rate" in result else ""))
    asyncio.run(run())
    print("\nDone. Run 'review' to see anything needing human inspection.")


def cmd_review(args) -> None:
    """List documents currently parked for human review."""
    _, s = build_service()
    ledger = IngestionLedger(s.paths.state_dir)
    pending = ledger.by_status("pending_human_review")
    if not pending:
        print("HITL queue is empty — nothing awaiting review.")
        return
    print(f"{len(pending)} document(s) awaiting human review:\n")
    hitl_dir = Path(s.paths.state_dir) / "hitl"
    for rec in pending:
        doc_id = rec["document_id"]
        review = json.loads((hitl_dir / f"{doc_id}.json").read_text())
        print(f"  document_id : {doc_id}")
        print(f"  file        : {review['filename']}  (pass_rate={review['pass_rate']})")
        print(f"  why         : {len(review['quarantine_reasons'])} chunk(s) quarantined; "
              f"reasons e.g. {review['quarantine_reasons'][:1]}")
        print(f"  preview     : {review['preview'][:160]!r}")
        print(f"  resolve via : python -m loanrag.presentation.cli resolve "
              f"--document-id {doc_id} --decision accept|reject|override\n")


def cmd_resolve(args) -> None:
    """Apply a human decision to a parked document and resume the pipeline."""
    service, _ = build_service()
    result = asyncio.run(service.resolve_review(
        args.document_id, args.decision, note=args.note or "",
        corrected_text=args.corrected_text or ""))
    print(result)


def cmd_verify(args) -> None:
    """Show blob contents, ledger statuses, and the quarantine report."""
    _, s = build_service()
    blob = make_blob_store(s.blob)
    print("== Blob: raw documents (loan-docs) ==")
    for k in sorted(blob.list_keys(s.blob.raw_container)):
        print("  ", k)
    print("\n== Blob: clean chunks (loan-chunks) ==")
    for k in sorted(blob.list_keys(s.blob.chunks_container)):
        print("  ", k)
    print("\n== Ledger (per-document status) ==")
    for rec in IngestionLedger(s.paths.state_dir).all():
        print(f"  {rec['document_id']:48s} {rec.get('status'):22s} "
              f"chunks={rec.get('chunks_written', '-')} quarantined={rec.get('quarantined', '-')}")
    qpath = Path(s.paths.state_dir) / "quarantine.json"
    if qpath.exists():
        q = json.loads(qpath.read_text())
        dropped = sum(len(v) for v in q.values())
        print(f"\n== Quarantine report: {dropped} chunk(s) dropped (never written) ==")


def cmd_evaluate(args) -> None:
    """Score ingestion KPIs against the ground-truth manifest.json.

    EXACT MATCH (strictly exact, no fuzzy): for each known field value we check
    whether the exactly-formatted value string appears in that document's clean
    chunk text. COMPLETENESS: fraction of expected documents that ingested.
    QUALITY: guard pass/quarantine stats and the HITL count.
    """
    _, s = build_service()
    blob = make_blob_store(s.blob)
    manifest = json.loads((Path(s.paths.inbox) / "manifest.json").read_text())
    app = manifest["applicant"]["application_id"]
    ledger = IngestionLedger(s.paths.state_dir)

    def clean_text(filename: str) -> str | None:
        """Load the concatenated clean-chunk text for a document, if ingested."""
        doc_id = f"{app}__{re.sub(r'[^A-Za-z0-9_.-]', '_', filename)}"
        if ledger.status(doc_id) != "ingested":
            return None
        try:
            raw = blob.list_keys(s.blob.chunks_container)
            key = next(k for k in raw if k.endswith(f"{doc_id}.json"))
            data = asyncio.run(blob.get(s.blob.chunks_container, key))
            return " ".join(c["text"] for c in json.loads(data))
        except Exception:
            return None

    total_fields = hits = 0
    print("== Exact-match field extraction (no fuzzy matching) ==")
    for doc in manifest["documents"]:
        expected = doc.get("expected_fields")
        if not expected:
            continue
        text = clean_text(doc["file"])
        if text is None:
            print(f"  {doc['file']:28s} not in clean store (in HITL / not ingested) — fields skipped")
            continue
        for field, value in expected.items():
            total_fields += 1
            needle = _ind(value) if isinstance(value, int) else str(value)
            found = needle in text          # EXACT substring match, no fuzz
            hits += found
            print(f"  {doc['file']:28s} {field:18s} expected '{needle}' -> {'MATCH' if found else 'MISS'}")

    print("\n== Completeness / coverage ==")
    expected_docs = [d["file"] for d in manifest["documents"] if d["source_kind"] != "db"]
    ingested = [d for d in expected_docs if ledger.status(f"{app}__{re.sub(r'[^A-Za-z0-9_.-]', '_', d)}") == "ingested"]
    in_hitl = [d for d in expected_docs if ledger.status(f"{app}__{re.sub(r'[^A-Za-z0-9_.-]', '_', d)}") == "pending_human_review"]

    print("\n== KPI summary ==")
    print(f"  Exact-match rate     : {hits}/{total_fields} = {(hits/total_fields if total_fields else 0):.0%}")
    print(f"  Document completeness: {len(ingested)}/{len(expected_docs)} ingested "
          f"({len(in_hitl)} parked for human review)")
    print(f"  Authoritative DB facts: intentionally NOT ingested (queried live by loan RAG — ADR-003)")
    print("\n  Note: retrieval recall / false-positive are measured in the RETRIEVAL step")
    print("  (not part of ingestion). See RAG_GUIDE.md for how each KPI is computed and where.")


def main() -> None:
    """Parse arguments and dispatch to the chosen subcommand."""
    parser = argparse.ArgumentParser(prog="loanrag-ingest", description="LoanRAG ingestion CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("ingest", help="ingest all files in the inbox")
    p.add_argument("--application-id", default=DEFAULT_APP)
    p.set_defaults(func=cmd_ingest)

    sub.add_parser("review", help="list documents awaiting human review").set_defaults(func=cmd_review)

    p = sub.add_parser("resolve", help="resolve a parked document")
    p.add_argument("--document-id", required=True)
    p.add_argument("--decision", required=True, choices=["accept", "reject", "override"])
    p.add_argument("--note", default="")
    p.add_argument("--corrected-text", default="")
    p.set_defaults(func=cmd_resolve)

    sub.add_parser("verify", help="show blob + ledger + quarantine").set_defaults(func=cmd_verify)
    sub.add_parser("evaluate", help="score KPIs vs manifest").set_defaults(func=cmd_evaluate)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
