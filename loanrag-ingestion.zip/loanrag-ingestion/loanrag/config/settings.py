"""Application settings bound from environment variables.

Uses the LOANRAG__Section__Key convention (double-underscore nesting), e.g.:
    LOANRAG__BLOB__CONNECTION_STRING=UseDevelopmentStorage=true
    LOANRAG__GUARD__MIN_CONFIDENCE=0.6
    LOANRAG__HITL__MIN_PASS_RATE=0.5
Secrets are stored as Key Vault *references* (resolved at runtime), never literals.
"""

from functools import lru_cache

from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class EmbeddingSettings(BaseModel):
    """Embedding model selection and batching (used by the later RAG step)."""

    model: str = "text-embedding-3-large"
    batch_size: int = 64


class GuardSettings(BaseModel):
    """Thresholds for the null / quality guard.

    A chunk is dropped (never persisted) if it is empty, below min_confidence,
    shorter than min_chars, or has a garbage-character ratio above max_garbage.
    """

    min_confidence: float = 0.70
    min_chars: int = 3
    max_garbage_ratio: float = 0.30


class HitlSettings(BaseModel):
    """Human-in-the-loop gating for low-quality documents.

    If the fraction of a document's chunks that pass the guard is below
    min_pass_rate (or zero chunks pass), the whole document is paused and
    routed to a human reviewer instead of being silently ingested or dropped.
    """

    min_pass_rate: float = 0.50


class BlobSettings(BaseModel):
    """Blob storage (Azurite locally, real Azure Blob in the cloud).

    'UseDevelopmentStorage=true' is the well-known Azurite connection string.
    backend = 'azurite' uses azure-storage-blob; 'localfs' writes to a folder
    (handy for running without Docker). raw_container holds the original files;
    chunks_container holds the clean, quality-passed chunk JSON.
    """

    backend: str = "azure_blob"  # 'localfs' | 'azure_blob' (emulator OR real Azure) | 'gcs' (GCP)
    connection_string: str = "UseDevelopmentStorage=true"   # Azure
    localfs_root: str = "./_localblob"                      # local
    gcs_bucket: str = ""                                    # GCP: one bucket; container is a prefix
    raw_container: str = "loan-docs"
    chunks_container: str = "loan-chunks"


class PathsSettings(BaseModel):
    """Local filesystem paths used by the CLI pipeline."""

    inbox: str = "./inbox"          # documents to ingest
    state_dir: str = "./_state"     # ledger + HITL queue + quarantine live here


class Settings(BaseSettings):
    """Root settings object, composed of nested sections."""

    model_config = SettingsConfigDict(
        env_prefix="LOANRAG__",
        env_nested_delimiter="__",
        case_sensitive=False,
        extra="ignore",
    )

    embedding: EmbeddingSettings = Field(default_factory=EmbeddingSettings)
    guard: GuardSettings = Field(default_factory=GuardSettings)
    hitl: HitlSettings = Field(default_factory=HitlSettings)
    blob: BlobSettings = Field(default_factory=BlobSettings)
    paths: PathsSettings = Field(default_factory=PathsSettings)


@lru_cache
def get_settings() -> Settings:
    """Return a process-wide cached Settings singleton."""
    return Settings()
