"""HTML extractor using BeautifulSoup.

WHAT IT DOES
------------
Parses an HTML document (e.g. an employer verification letter or a net-banking
export), strips scripts/styles, keeps the readable prose as PARAGRAPH blocks and
each <table> as a TABLE block. Fetched/remote HTML must be treated as untrusted
(scripts removed; no instruction-following) -- here we only read a local file.
"""

from __future__ import annotations

from datetime import datetime, timezone

from bs4 import BeautifulSoup

from loanrag.domain.entities.block import Block
from loanrag.domain.entities.extracted_document import ExtractedDocument
from loanrag.domain.entities.provenance import Provenance
from loanrag.domain.entities.raw_document import RawDocument
from loanrag.domain.entities.section import Section
from loanrag.domain.enums import BlockKind, SourceKind


class HtmlExtractor:
    """Extracts prose + tables from HTML (implements IDocumentExtractor)."""

    VERSION = "bs4@1.0"

    def supports(self, doc: RawDocument) -> bool:
        """Handle .html / .htm files."""
        return doc.filename.lower().endswith((".html", ".htm"))

    async def extract(self, doc: RawDocument) -> ExtractedDocument:
        """Parse HTML into paragraph + table blocks (scripts/styles removed)."""
        with open(doc.blob_uri, "r", encoding="utf-8", errors="replace") as fh:
            soup = BeautifulSoup(fh.read(), "lxml")
        for tag in soup(["script", "style", "noscript"]):  # untrusted/irrelevant
            tag.decompose()

        blocks: list[Block] = []
        # Tables first, as their own TABLE blocks.
        for t_idx, table in enumerate(soup.find_all("table")):
            rows = []
            for tr in table.find_all("tr"):
                cells = [c.get_text(strip=True) for c in tr.find_all(["th", "td"])]
                if cells:
                    rows.append(cells)
            if rows:
                md = "\n".join(" | ".join(r) for r in rows)
                blocks.append(Block(block_id=f"table{t_idx}", kind=BlockKind.TABLE,
                                    text=md, min_token_confidence=1.0, inferred=False,
                                    extra={"cells": rows}))
            table.decompose()  # remove so it is not duplicated in the prose pass

        # Remaining visible text as a single paragraph block.
        prose = " ".join(soup.get_text(separator=" ").split())
        if prose:
            blocks.insert(0, Block(block_id="prose", kind=BlockKind.PARAGRAPH,
                                   text=prose, min_token_confidence=1.0, inferred=False))

        return ExtractedDocument(
            document_id=doc.document_id, application_id=doc.application_id,
            provenance=Provenance(
                source_kind=SourceKind.HTML, extractor="bs4",
                extractor_version=self.VERSION, source_ref=doc.blob_uri,
                extracted_at=datetime.now(timezone.utc)),
            sections=[Section(section_id="html", heading=None, blocks=blocks)] if blocks else [],
        )
