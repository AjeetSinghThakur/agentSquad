"""Scanned / image-only PDF extractor using Tesseract OCR.

WHAT IT DOES
------------
Handles PDFs that have NO text layer (phone photos, faxes, the degraded
bank_statement_scanned.pdf). It rasterises each page to an image (poppler via
pdf2image), runs Tesseract, and -- crucially -- reads Tesseract's PER-WORD
CONFIDENCE. The lowest word confidence on a page becomes the block's
min_token_confidence, which is the signal the null/quality guard uses to decide
whether a chunk is trustworthy or must be quarantined / sent to HITL.

WHY CONFIDENCE MATTERS HERE
---------------------------
OCR on poor scans is uncertain. Instead of blindly trusting it, we carry the
confidence forward so bad reads are caught downstream rather than turning into a
wrong loan decision. In the cloud this is replaced by Azure Document
Intelligence (which returns its own per-token confidence); the contract is the
same, so nothing downstream changes.
"""

from __future__ import annotations

from datetime import datetime, timezone

import pytesseract
from pdf2image import convert_from_path

from loanrag.domain.entities.block import Block
from loanrag.domain.entities.extracted_document import ExtractedDocument
from loanrag.domain.entities.provenance import Provenance
from loanrag.domain.entities.raw_document import RawDocument
from loanrag.domain.entities.section import Section
from loanrag.domain.enums import BlockKind, SourceKind


class ScannedPdfExtractor:
    """OCRs image-only PDFs and records per-word confidence (IDocumentExtractor)."""

    VERSION = "tesseract-ocr@1.0"

    def supports(self, doc: RawDocument) -> bool:
        """Handle any PDF. The router tries the text extractor first; this one is
        the fallback for PDFs whose text layer is empty (i.e. scanned)."""
        return doc.mime_type == "application/pdf" or doc.filename.lower().endswith(".pdf")

    async def extract(self, doc: RawDocument) -> ExtractedDocument:
        """Rasterise each page, OCR it, and capture text + min word confidence."""
        sections: list[Section] = []
        # 200 DPI is a good balance of accuracy vs speed for A4 scans.
        pages = convert_from_path(doc.blob_uri, dpi=200)

        for page_no, image in enumerate(pages, start=1):
            # image_to_data gives us per-word text AND confidence (0-100, -1 = none).
            data = pytesseract.image_to_data(image, output_type=pytesseract.Output.DICT)
            words, confs = [], []
            for word, conf in zip(data["text"], data["conf"]):
                word = (word or "").strip()
                try:
                    c = float(conf)
                except (TypeError, ValueError):
                    c = -1.0
                if word and c >= 0:
                    words.append(word)
                    confs.append(c / 100.0)  # normalise Tesseract 0-100 -> 0-1

            text = " ".join(words).strip()
            if not text:
                # An empty page after OCR is itself a quality signal: emit an
                # explicitly low-confidence empty block so the guard can flag it.
                sections.append(Section(
                    section_id=f"page-{page_no}", heading=f"Page {page_no}",
                    blocks=[Block(block_id=f"p{page_no}-ocr", kind=BlockKind.PARAGRAPH,
                                  text="", page=page_no, min_token_confidence=0.0,
                                  inferred=True)]))
                continue

            min_conf = min(confs) if confs else 0.0
            avg_conf = sum(confs) / len(confs) if confs else 0.0
            sections.append(Section(
                section_id=f"page-{page_no}", heading=f"Page {page_no}",
                blocks=[Block(
                    block_id=f"p{page_no}-ocr",
                    kind=BlockKind.PARAGRAPH,
                    text=text,
                    page=page_no,
                    # min word confidence drives the guard; avg kept for reporting.
                    min_token_confidence=round(min_conf, 4),
                    inferred=True,  # OCR output is a machine read, not ground truth
                    extra={"avg_confidence": round(avg_conf, 4), "word_count": len(words)},
                )]))

        return ExtractedDocument(
            document_id=doc.document_id,
            application_id=doc.application_id,
            provenance=Provenance(
                source_kind=SourceKind.SCANNED_PDF,
                extractor="tesseract",
                extractor_version=self.VERSION,
                model_version=pytesseract.get_tesseract_version().__str__(),
                source_ref=doc.blob_uri,
                extracted_at=datetime.now(timezone.utc),
            ),
            sections=sections,
        )
