"""infrastructure/extraction layer."""
