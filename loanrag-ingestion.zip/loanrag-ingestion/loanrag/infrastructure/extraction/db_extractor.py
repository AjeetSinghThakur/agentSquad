"""SQLite database extractor (NARRATIVE content only).

WHAT IT DOES
------------
Reads ONLY the narrative tables from the system-of-record DB (here:
underwriter_notes) and turns each row into a paragraph block for indexing.

WHAT IT DELIBERATELY DOES NOT DO
--------------------------------
It does NOT read the authoritative numeric facts (income, obligations, credit
score). Per ADR-003 those are queried LIVE at decision time by the loan RAG and
are never embedded, because cached snapshots go stale and invite grounded-but-
wrong answers. This separation is the whole point of treating the DB differently
from documents.
"""

from __future__ import annotations

import sqlite3
from datetime import datetime, timezone

from loanrag.domain.entities.block import Block
from loanrag.domain.entities.extracted_document import ExtractedDocument
from loanrag.domain.entities.provenance import Provenance
from loanrag.domain.entities.raw_document import RawDocument
from loanrag.domain.entities.section import Section
from loanrag.domain.enums import BlockKind, SourceKind

# Only these tables are safe to index. Authoritative numeric tables are excluded.
NARRATIVE_TABLES = {"underwriter_notes": "note"}


class DbExtractor:
    """Indexes narrative DB rows only; authoritative facts stay query-time (ADR-003)."""

    VERSION = "sqlite-narrative@1.0"

    def supports(self, doc: RawDocument) -> bool:
        """Handle .sqlite / .db files."""
        return doc.filename.lower().endswith((".sqlite", ".db"))

    async def extract(self, doc: RawDocument) -> ExtractedDocument:
        """Read each allowed narrative table into paragraph blocks."""
        conn = sqlite3.connect(doc.blob_uri)
        conn.row_factory = sqlite3.Row
        blocks: list[Block] = []
        for table, text_col in NARRATIVE_TABLES.items():
            try:
                cur = conn.execute(f"SELECT rowid, * FROM {table}")
            except sqlite3.OperationalError:
                continue  # table absent in this DB
            for row in cur.fetchall():
                value = (row[text_col] or "").strip()
                if value:
                    blocks.append(Block(
                        block_id=f"{table}-{row['rowid']}", kind=BlockKind.PARAGRAPH,
                        text=value, min_token_confidence=1.0, inferred=False,
                        extra={"table": table, "rowid": row["rowid"]}))
        conn.close()
        return ExtractedDocument(
            document_id=doc.document_id, application_id=doc.application_id,
            provenance=Provenance(
                source_kind=SourceKind.DB, extractor="sqlite",
                extractor_version=self.VERSION, source_ref=doc.blob_uri,
                extracted_at=datetime.now(timezone.utc)),
            sections=[Section(section_id="db-narrative", heading="Narrative DB content",
                              blocks=blocks)] if blocks else [],
        )
