"""XLSX extractor using openpyxl.

WHAT IT DOES
------------
Reads each worksheet of an Excel workbook into a TABLE block (one block per
sheet). Spreadsheets do NOT go through Document Intelligence (it can't analyse
spreadsheet tables), so this is the canonical path for .xlsx in both local and
cloud modes. Values are read with data_only=True so computed formula results
are captured where the workbook has cached them.
"""

from __future__ import annotations

from datetime import datetime, timezone

from openpyxl import load_workbook

from loanrag.domain.entities.block import Block
from loanrag.domain.entities.extracted_document import ExtractedDocument
from loanrag.domain.entities.provenance import Provenance
from loanrag.domain.entities.raw_document import RawDocument
from loanrag.domain.entities.section import Section
from loanrag.domain.enums import BlockKind, SourceKind


class XlsxExtractor:
    """Extracts each worksheet as a table block (implements IDocumentExtractor)."""

    VERSION = "openpyxl@1.0"

    def supports(self, doc: RawDocument) -> bool:
        """Handle .xlsx / .xlsm files."""
        return doc.filename.lower().endswith((".xlsx", ".xlsm"))

    async def extract(self, doc: RawDocument) -> ExtractedDocument:
        """Read every sheet into a TABLE block with both text and raw cells."""
        # data_only=True returns the last-computed value of formula cells.
        wb = load_workbook(doc.blob_uri, data_only=True, read_only=True)
        sections: list[Section] = []
        for sheet in wb.worksheets:
            rows = [[("" if c is None else str(c)) for c in row]
                    for row in sheet.iter_rows(values_only=True)]
            rows = [r for r in rows if any(cell.strip() for cell in r)]  # drop blank rows
            if not rows:
                continue
            md = "\n".join(" | ".join(r) for r in rows)
            sections.append(Section(
                section_id=f"sheet-{sheet.title}", heading=sheet.title,
                blocks=[Block(
                    block_id=f"sheet-{sheet.title}",
                    kind=BlockKind.TABLE,
                    text=f"Sheet: {sheet.title}\n{md}",
                    min_token_confidence=1.0,   # spreadsheet cells are exact
                    inferred=False,
                    extra={"sheet": sheet.title, "cells": rows,
                           "row_count": len(rows), "col_count": len(rows[0]) if rows else 0},
                )]))
        wb.close()
        return ExtractedDocument(
            document_id=doc.document_id,
            application_id=doc.application_id,
            provenance=Provenance(
                source_kind=SourceKind.XLSX, extractor="openpyxl",
                extractor_version=self.VERSION, source_ref=doc.blob_uri,
                extracted_at=datetime.now(timezone.utc),
            ),
            sections=sections,
        )
