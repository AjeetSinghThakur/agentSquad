"""Extractor router.

Picks the right IDocumentExtractor for a RawDocument by asking each registered
extractor (in priority order) whether it `supports` the file. The PDF text
extractor is tried BEFORE the OCR extractor, so a born-digital PDF takes the
cheap deterministic path and only image-only PDFs fall through to OCR.
"""

from __future__ import annotations

from loanrag.domain.entities.raw_document import RawDocument
from loanrag.infrastructure.extraction.db_extractor import DbExtractor
from loanrag.infrastructure.extraction.html_extractor import HtmlExtractor
from loanrag.infrastructure.extraction.pdf_text_extractor import PdfTextExtractor
from loanrag.infrastructure.extraction.scanned_pdf_extractor import ScannedPdfExtractor
from loanrag.infrastructure.extraction.xlsx_extractor import XlsxExtractor


class ExtractorRouter:
    """Selects an extractor for a document. Order encodes priority."""

    def __init__(self) -> None:
        """Register extractors. PDF-text before scanned-OCR is intentional."""
        self._extractors = [
            PdfTextExtractor(),    # born-digital PDF (declines if no text layer)
            ScannedPdfExtractor(),  # image-only PDF -> OCR
            XlsxExtractor(),
            HtmlExtractor(),
            DbExtractor(),
        ]

    def select(self, doc: RawDocument):
        """Return the first extractor that supports the document, else None."""
        for extractor in self._extractors:
            if extractor.supports(doc):
                return extractor
        return None
