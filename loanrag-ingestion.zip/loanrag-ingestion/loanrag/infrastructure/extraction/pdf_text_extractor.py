"""Born-digital PDF extractor using pdfplumber.

WHAT IT DOES
------------
Reads PDFs that already contain a real text layer (salary slip, bank statement,
application form, Form 16, credit report). For each page it pulls the text and
any detected tables, and maps them onto the canonical ExtractedDocument model
(Section -> Block). Because the text is embedded (not OCR'd), every block gets
min_token_confidence = 1.0 and inferred = False.

WHY A SEPARATE EXTRACTOR
------------------------
This is the cheap, deterministic, high-accuracy path. The router only sends it
PDFs that have a usable text layer; image-only/scanned PDFs go to the OCR
extractor instead. In the cloud, this implementation is swapped for the Azure
Document Intelligence adapter -- the rest of the pipeline does not change
because both satisfy the same IDocumentExtractor protocol.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

import pdfplumber

from loanrag.domain.entities.block import Block
from loanrag.domain.entities.extracted_document import ExtractedDocument
from loanrag.domain.entities.provenance import Provenance
from loanrag.domain.entities.raw_document import RawDocument
from loanrag.domain.entities.section import Section
from loanrag.domain.enums import BlockKind, SourceKind


class PdfTextExtractor:
    """Extracts text + tables from born-digital PDFs (implements IDocumentExtractor)."""

    VERSION = "pdf-text@1.0"

    def supports(self, doc: RawDocument) -> bool:
        """Handle PDFs that contain an extractable text layer.

        We open the PDF and check the first couple of pages for real text. If
        there is none, this is a scanned/image PDF and we decline (the router
        then falls through to the OCR extractor).
        """
        if doc.mime_type != "application/pdf" and not doc.filename.lower().endswith(".pdf"):
            return False
        try:
            with pdfplumber.open(doc.blob_uri) as pdf:
                for page in pdf.pages[:2]:
                    if (page.extract_text() or "").strip():
                        return True
        except Exception:
            return False
        return False  # no text layer -> let the OCR extractor take it

    async def extract(self, doc: RawDocument) -> ExtractedDocument:
        """Read every page into Sections of text + table blocks."""
        sections: list[Section] = []
        with pdfplumber.open(doc.blob_uri) as pdf:
            for page_no, page in enumerate(pdf.pages, start=1):
                blocks: list[Block] = []

                # 1) Page text as one paragraph block (kept simple & deterministic).
                text = (page.extract_text() or "").strip()
                if text:
                    blocks.append(Block(
                        block_id=f"p{page_no}-text",
                        kind=BlockKind.PARAGRAPH,
                        text=text,
                        page=page_no,
                        min_token_confidence=1.0,  # embedded text => fully trusted
                        inferred=False,
                    ))

                # 2) Each detected table becomes its own TABLE block. We keep a
                #    readable text form AND the raw cell grid in `extra` so a
                #    later step can read a specific cell without re-parsing prose.
                for t_idx, table in enumerate(page.extract_tables() or []):
                    rows = [[(c or "").strip() for c in row] for row in table]
                    md = "\n".join(" | ".join(r) for r in rows)
                    blocks.append(Block(
                        block_id=f"p{page_no}-table{t_idx}",
                        kind=BlockKind.TABLE,
                        text=md,
                        page=page_no,
                        min_token_confidence=1.0,
                        inferred=False,
                        extra={"cells": rows, "row_count": len(rows),
                               "col_count": len(rows[0]) if rows else 0},
                    ))

                if blocks:
                    sections.append(Section(section_id=f"page-{page_no}",
                                            heading=f"Page {page_no}", blocks=blocks))

        return ExtractedDocument(
            document_id=doc.document_id,
            application_id=doc.application_id,
            provenance=Provenance(
                source_kind=SourceKind.PDF,
                extractor="pdfplumber",
                extractor_version=self.VERSION,
                source_ref=doc.blob_uri,
                extracted_at=datetime.now(timezone.utc),
            ),
            sections=sections,
        )
