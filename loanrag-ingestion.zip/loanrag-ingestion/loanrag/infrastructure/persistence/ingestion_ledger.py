"""Ingestion ledger (JSON file).

A tiny, human-readable state store that tracks every document's status so the
pipeline is idempotent and RESUMABLE:

  ingested              -> clean chunks written to blob (terminal, success)
  pending_human_review  -> failed the quality gate; waiting for a human (HITL)
  unreadable / rejected -> human decided not to ingest (terminal)

Why a JSON file and not LangGraph here?
  For LOCAL testing this keeps the moving parts to a minimum (no Postgres). It
  models exactly the same pause/resume idea: a document parks in
  'pending_human_review' until a human resolves it, then the pipeline continues.
  In the production loan workflow this same gate becomes a LangGraph interrupt()
  with a durable checkpointer -- see RAG_GUIDE.md.
"""

from __future__ import annotations

import json
from pathlib import Path



class IngestionLedger:
    """Per-document status + HITL queue, persisted as a JSON file."""

    def __init__(self, state_dir: str) -> None:
        """Open (or create) the ledger file under the state directory."""
        self._dir = Path(state_dir)
        self._dir.mkdir(parents=True, exist_ok=True)
        self._path = self._dir / "ledger.json"
        self._data: dict[str, object] = {}
        if self._path.exists():
            self._data = json.loads(self._path.read_text(encoding="utf-8"))

    def _save(self) -> None:
        """Persist the ledger to disk (called after every change)."""
        self._path.write_text(json.dumps(self._data, indent=2), encoding="utf-8")

    def get(self, document_id: str) -> dict | None:
        """Return the record for a document, or None if unseen."""
        return self._data.get(document_id)

    def status(self, document_id: str) -> str | None:
        """Return just the status string for a document."""
        rec = self._data.get(document_id)
        return rec["status"] if rec else None

    def upsert(self, document_id: str, **fields: object) -> None:
        """Create or update a document's record and save."""
        rec = self._data.setdefault(document_id, {})
        rec.update(fields)
        self._save()

    def by_status(self, status: str) -> list[dict]:
        """Return all records currently in a given status (e.g. for HITL listing)."""
        return [{"document_id": k, **v} for k, v in self._data.items() if v.get("status") == status]

    def all(self) -> list[dict]:
        """Return every record (used by the verify/report command)."""
        return [{"document_id": k, **v} for k, v in self._data.items()]
