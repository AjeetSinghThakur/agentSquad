"""Blob storage adapters (implements IBlobStore).

Two interchangeable implementations behind the same protocol:

  AzureBlobStore    -> uses the Azure Blob SDK. This ONE code path works for
                       BOTH the local Azurite emulator AND real Azure Blob -- the
                       CONNECTION STRING decides which (not the backend name).
                       'UseDevelopmentStorage=true' targets the local emulator.

  LocalFsBlobStore  -> writes blobs to a local folder. Handy for running the
                       pipeline WITHOUT Docker/Azurite (e.g. quick tests).

The factory `make_blob_store(settings)` returns the one selected by
LOANRAG__BLOB__BACKEND. The rest of the code only ever sees the protocol, so
switching local <-> Azurite <-> real Azure changes one setting, not the code.
"""

from __future__ import annotations

from pathlib import Path

from loanrag.config.settings import BlobSettings


class AzureBlobStore:
    """Stores blobs via the Azure Blob SDK (real Azure Blob or the Azurite emulator)."""

    def __init__(self, connection_string: str) -> None:
        """Connect lazily; create a client per call so it is import-safe."""
        self._conn = connection_string

    def _service(self):
        """Build a BlobServiceClient from the connection string."""
        from azure.storage.blob import BlobServiceClient
        return BlobServiceClient.from_connection_string(self._conn)

    def ensure_container(self, container: str) -> None:
        """Create the container if it does not already exist (idempotent)."""
        svc = self._service()
        try:
            svc.create_container(container)
        except Exception:
            pass  # already exists

    async def put(self, container: str, key: str, data: bytes, content_type: str) -> str:
        """Upload bytes to {container}/{key}, overwriting; return the blob URL."""
        from azure.storage.blob import ContentSettings
        self.ensure_container(container)
        client = self._service().get_blob_client(container=container, blob=key)
        client.upload_blob(data, overwrite=True,
                           content_settings=ContentSettings(content_type=content_type))
        return client.url

    async def get(self, container: str, key: str) -> bytes:
        """Download the bytes stored at {container}/{key}."""
        client = self._service().get_blob_client(container=container, blob=key)
        return client.download_blob().readall()

    def list_keys(self, container: str) -> list[str]:
        """List blob names in a container (used by the verify command)."""
        try:
            return [b.name for b in self._service().get_container_client(container).list_blobs()]
        except Exception:
            return []


class LocalFsBlobStore:
    """Stores blobs as files under a local root (implements IBlobStore)."""

    def __init__(self, root: str) -> None:
        """Remember the root folder that stands in for blob storage."""
        self._root = Path(root).resolve()

    def ensure_container(self, container: str) -> None:
        """Create the container folder if missing."""
        (self._root / container).mkdir(parents=True, exist_ok=True)

    async def put(self, container: str, key: str, data: bytes, content_type: str) -> str:
        """Write bytes to {root}/{container}/{key}; return a file URI."""
        self.ensure_container(container)
        path = self._root / container / key
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        return path.as_uri()

    async def get(self, container: str, key: str) -> bytes:
        """Read previously stored bytes."""
        return (self._root / container / key).read_bytes()

    def list_keys(self, container: str) -> list[str]:
        """List stored blob names in a container."""
        base = self._root / container
        if not base.exists():
            return []
        return [str(p.relative_to(base)) for p in base.rglob("*") if p.is_file()]



class GcsBlobStore:
    """Stores blobs in Google Cloud Storage (implements IBlobStore).

    GCP mapping: ONE bucket holds everything; the 'container' (loan-docs /
    loan-chunks) becomes a top-level object PREFIX. So an object lands at
    gs://<bucket>/<container>/<key>. The same code serves local testing against a
    real bucket too — credentials (ADC) decide access, not this class.
    """

    def __init__(self, bucket: str) -> None:
        """Remember the target bucket; build the client lazily."""
        self._bucket_name = bucket

    def _bucket(self):
        """Create a GCS bucket handle from Application Default Credentials."""
        from google.cloud import storage
        return storage.Client().bucket(self._bucket_name)

    def ensure_container(self, container: str) -> None:
        """No-op for GCS: prefixes are implicit (the bucket already exists)."""
        return None

    async def put(self, container: str, key: str, data: bytes, content_type: str) -> str:
        """Upload bytes to gs://<bucket>/<container>/<key>; return the gs:// URI."""
        blob = self._bucket().blob(f"{container}/{key}")
        blob.upload_from_string(data, content_type=content_type)
        return f"gs://{self._bucket_name}/{container}/{key}"

    async def get(self, container: str, key: str) -> bytes:
        """Download the bytes stored at gs://<bucket>/<container>/<key>."""
        return self._bucket().blob(f"{container}/{key}").download_as_bytes()

    def list_keys(self, container: str) -> list[str]:
        """List object names under the container prefix (without the prefix)."""
        try:
            prefix = f"{container}/"
            return [b.name[len(prefix):] for b in self._bucket().list_blobs(prefix=prefix)]
        except Exception:
            return []


def make_blob_store(settings: BlobSettings):
    """Return the blob store selected by configuration: localfs | azure_blob | gcs.

    The rest of the pipeline only sees the IBlobStore protocol, so switching
    local <-> Azure <-> GCP is ONE setting (LOANRAG__BLOB__BACKEND), not a rewrite.
    """
    if settings.backend == "localfs":
        return LocalFsBlobStore(settings.localfs_root)
    if settings.backend == "gcs":
        return GcsBlobStore(settings.gcs_bucket)
    return AzureBlobStore(settings.connection_string)
