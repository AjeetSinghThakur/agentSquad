"""Null / quality guard.

This is the gate that enforces your rule: empty and low-confidence chunks must
NEVER be created/persisted. For each chunk it returns a pass/fail verdict with
reasons. The ingestion service drops failing chunks (recording them in a
quarantine report) and, if too many of a document's chunks fail, routes the
whole document to human review instead of ingesting partial garbage.

A chunk FAILS if ANY of these is true:
  empty           -> text is missing or whitespace-only
  too_short       -> fewer than `min_chars` non-space characters
  low_confidence  -> OCR confidence below `min_confidence` (scanned docs)
  garbage         -> too high a ratio of non-alphanumeric 'noise' characters
"""

from __future__ import annotations

import re

from loanrag.domain.entities.chunk_quality import ChunkQuality
from loanrag.domain.entities.indexable_chunk import IndexableChunk

# Characters we consider "real" content; everything else counts toward garbage.
_MEANINGFUL = re.compile(r"[0-9A-Za-z\u00C0-\u024F\u0900-\u097F .,:/@%+()-]")


class NullGuard:
    """Detects empty / low-confidence / garbage chunks (implements IQualityGuard)."""

    def __init__(self, min_confidence: float, min_chars: int, max_garbage_ratio: float) -> None:
        """Store the thresholds (injected from settings)."""
        self._min_conf = min_confidence
        self._min_chars = min_chars
        self._max_garbage = max_garbage_ratio

    def inspect(self, chunk: IndexableChunk) -> ChunkQuality:
        """Return a pass/fail verdict with the list of failure reasons."""
        reasons: list[str] = []
        text = (chunk.text or "").strip()

        if not text:
            reasons.append("empty")
        else:
            if len(text) < self._min_chars:
                reasons.append("too_short")
            if self._garbage_ratio(text) > self._max_garbage:
                reasons.append("garbage")

        # Confidence check applies whenever we have a meaningful read to judge.
        if chunk.min_token_confidence < self._min_conf and text:
            reasons.append(f"low_confidence({chunk.min_token_confidence:.2f}<{self._min_conf:.2f})")

        return ChunkQuality(chunk_id=chunk.chunk_id, passed=not reasons, reasons=reasons)

    def _garbage_ratio(self, text: str) -> float:
        """Fraction of characters that are NOT meaningful content (OCR noise)."""
        if not text:
            return 1.0
        meaningful = len(_MEANINGFUL.findall(text))
        return 1.0 - (meaningful / len(text))
