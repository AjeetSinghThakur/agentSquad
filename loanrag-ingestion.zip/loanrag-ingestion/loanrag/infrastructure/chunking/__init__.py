"""infrastructure/chunking layer."""
