"""Layout-aware chunker.

Turns an ExtractedDocument into IndexableChunks: one chunk per logical block
(paragraph / table / figure), NOT fixed-size windows -- so tables and sections
stay intact, which is what makes retrieval and grounding accurate later.

Each chunk_id is deterministic ('{document_id}:{block_id}') so re-running
ingestion on the same file produces the same ids (idempotency).
"""

from __future__ import annotations

from loanrag.domain.entities.extracted_document import ExtractedDocument
from loanrag.domain.entities.indexable_chunk import IndexableChunk


class LayoutChunker:
    """Maps document blocks to indexable chunks (implements IChunker)."""

    def chunk(self, doc: ExtractedDocument) -> list[IndexableChunk]:
        """Produce one IndexableChunk per block, carrying all provenance/quality."""
        chunks: list[IndexableChunk] = []
        for section in doc.sections:
            for block in section.blocks:
                chunks.append(IndexableChunk(
                    chunk_id=f"{doc.document_id}:{block.block_id}",
                    application_id=doc.application_id,
                    document_id=doc.document_id,
                    kind=block.kind,
                    text=block.text,
                    source_kind=doc.provenance.source_kind,
                    extractor_version=doc.provenance.extractor_version,
                    content_sha256="",  # set by the service from the raw document hash
                    page=block.page,
                    bounding_region=block.bounding_region,
                    min_token_confidence=block.min_token_confidence,
                    inferred=block.inferred,
                    extra={**block.extra, "section": section.heading},
                ))
        return chunks
