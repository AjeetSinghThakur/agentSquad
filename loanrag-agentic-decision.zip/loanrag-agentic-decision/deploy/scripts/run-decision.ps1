# Run a decision reading chunks from local | azure | gcp.
# Usage: ./run-decision.ps1 -Target gcp -App LOAN-2026-000123
param([ValidateSet("local","azure","gcp")][string]$Target="local",[string]$App="LOAN-2026-000123")
switch ($Target) {
  "local" { $env:LOANRAG__BLOB__BACKEND="localfs"
            if (-not $env:LOANRAG__BLOB__LOCALFS_ROOT) { $env:LOANRAG__BLOB__LOCALFS_ROOT="./_localblob" } }
  "azure" { $env:LOANRAG__BLOB__BACKEND="azure_blob"
            if (-not $env:LOANRAG__BLOB__CONNECTION_STRING) { throw "Set LOANRAG__BLOB__CONNECTION_STRING" } }
  "gcp"   { $env:LOANRAG__BLOB__BACKEND="gcs"
            if (-not $env:LOANRAG__BLOB__GCS_BUCKET) { throw "Set LOANRAG__BLOB__GCS_BUCKET" } }
}
Write-Host ">> Deciding $App from backend=$($env:LOANRAG__BLOB__BACKEND)"
python -m agentic_rag.presentation.cli run --application-id $App
