# Deploying LoanRAG to Google Cloud (GCP)

Same code, GCP services. Like the Azure path, moving to GCP is **configuration +
adapter swaps**, not a rewrite — every seam is already an interface.

## 1. Services you need (Azure → GCP equivalents)

| Concern | Azure | GCP | Required? |
|---|---|---|---|
| Chunk store (shared) | Blob Storage | **Cloud Storage (GCS)** | Yes |
| OCR for scans (ingestion) | Document Intelligence | **Document AI** | Yes (scans) |
| Authoritative facts (live) | Azure SQL | **Cloud SQL** (Postgres/MySQL) | Yes |
| Checkpointer (durable HITL) | Azure DB for PostgreSQL | **Cloud SQL for PostgreSQL** | Yes |
| Evidence retrieval | Azure AI Search | **Vertex AI Search / Vector Search** | Recommended |
| Rationale LLM (optional) | Azure OpenAI | **Vertex AI (Gemini)** | Optional |
| Image registry | Container Registry | **Artifact Registry** | Yes |
| Compute + scaling | AKS | **GKE (Autopilot)** + HPA | Yes |
| Secrets | Key Vault | **Secret Manager** | Yes |
| Observability | Monitor/App Insights | **Cloud Logging/Monitoring** | Recommended |

## 2. Provision everything

```bash
chmod +x deploy/scripts/provision-gcp.sh
./deploy/scripts/provision-gcp.sh -p YOUR_PROJECT_ID -r asia-south1 -x loanrag
```
It enables APIs and creates GCS buckets, a Document AI OCR processor, Cloud SQL
for PostgreSQL (with `loanrag_state` for the checkpointer and `authoritative` for
facts), Artifact Registry, a **GKE Autopilot** cluster, a workload service
account, and Secret Manager entries — then prints the `LOANRAG__...` settings.

## 3. Adapter swaps (same interfaces)

- **Chunk store → GCS.** Add `agentic_rag/retrieval/gcs_blob_reader.py` exposing the
  same methods as `LocalFsBlobReader`/`AzureBlobReader` (list/read), backed by the
  `google-cloud-storage` client, and select it with `LOANRAG__BLOB__BACKEND=gcs`
  in `retrieval/blob_reader.py → make_blob_reader`. Nothing else changes.
- **Authoritative facts → Cloud SQL.** Swap the query implementation in
  `facts/authoritative_facts.py` (psycopg/SQLAlchemy) — the `fetch()` contract is
  unchanged.
- **Checkpointer → Cloud SQL for PostgreSQL.** Set
  `LOANRAG__CHECKPOINTER__BACKEND=postgres` and `...__POSTGRES_CONN=...`; the
  Postgres saver path already exists in `workflow/graph.py`.
- **Retriever → Vertex AI.** Add an adapter with the same
  `retrieve(query, top_k) -> [Chunk]` as `LexicalRetriever`, backed by Vertex AI
  Search (or Vector Search with your embedding model), and use it in
  `workflow/nodes.py → retrieve_evidence`. Recall/false-positive metrics are
  unchanged and will show the improvement.
- **Rationale (optional) → Gemini.** Point the optional LLM at Vertex AI; it may
  only paraphrase already-cited facts (zero new claims).

## 4. Build, push, deploy (GKE + HPA)

```bash
PROJECT=YOUR_PROJECT_ID; REGION=asia-south1; REPO=loanrag-images
IMAGE=$REGION-docker.pkg.dev/$PROJECT/$REPO/loanrag-decision:1.0

gcloud auth configure-docker $REGION-docker.pkg.dev --quiet
docker build -t $IMAGE .
docker push $IMAGE

gcloud container clusters get-credentials loanrag-gke --region $REGION --project $PROJECT

# rules as a ConfigMap (edit policy without rebuilding the image)
kubectl apply -f deploy/k8s/00-namespace.yaml
kubectl create configmap loanrag-rules --from-file=rules.yaml=config/rules.yaml \
  -n loanrag -o yaml --dry-run=client | kubectl apply -f -

sed "s|__IMAGE__|$IMAGE|g; s|value: \"azure_blob\"|value: \"gcs\"|" \
  deploy/k8s/30-deployment.yaml | kubectl apply -f -
kubectl apply -f deploy/k8s/40-service.yaml
kubectl apply -f deploy/k8s/50-hpa.yaml
kubectl -n loanrag get hpa loanrag-decision
```

## 5. Autoscaling (HPA)

`deploy/k8s/50-hpa.yaml` scales the decision API between **2 and 10 pods** on CPU
(target 65%) and memory (target 75%). It needs the pod CPU/memory **requests**
(already set in `30-deployment.yaml`) and metrics-server (built in on GKE
Autopilot). GKE Autopilot also adds/removes nodes automatically as the HPA changes
the pod count, so you get both pod- and node-level elasticity.

The CI/CD pipeline (`deploy/pipelines/azure-pipelines.yml`) automates build →
push (ACR + Artifact Registry) → deploy to **both** AKS and GKE with the HPA.
