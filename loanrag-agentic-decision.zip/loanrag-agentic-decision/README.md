# LoanRAG — Agentic decision (multi-agent supervisor)

The **agentic** variant of the loan-decision system. A Supervisor orchestrates a
team — **Planner → Researcher → Verifier → Underwriter → Reviewer** — over the
same grounded tools and the same ingested chunks as the deterministic version.
The LLM is **provider-agnostic and OFF by default**, so it runs reproducibly with
no credentials; the decision itself is always computed deterministically.

**Start here:** AGENTIC_DESIGN.md (architecture, the team, the grounding gates,
the LLM-off design, and how it differs from `loanrag-loan-decision`).

## Run

```bash
pip install -r requirements.txt

# direct (LLM off -> fully deterministic)
python -m agentic_rag.presentation.cli run    --application-id LOAN-2026-000123 --loan-type PERSONAL
python -m agentic_rag.presentation.cli resume --application-id LOAN-2026-000123 --decision approve

# API + reviewer console
uvicorn agentic_rag.presentation.api:app --host 0.0.0.0 --port 8080
#   GET /  (console) · POST /assess · POST /resume · GET /pending · GET /healthz

# multi-cloud storage (one setting) + RabbitMQ event flow are carried over
./deploy/scripts/run-decision.sh local|azure|gcp LOAN-2026-000123
```

## What's grounded (unchanged from the deterministic version)

- Facts come from the authoritative DB + **exact-match corroboration**.
- The recommendation comes from the **deterministic policy** (`grounding/grounded_decision.py`).
- The Supervisor enforces Verifier-before-Underwriter and Underwriter-before-review.
- Uncorroborated fact → **abstain → REFER**. The LLM never produces a fact or verdict.

## Layout

`agentic_rag/agents/` (planner, researcher, verifier, underwriter, reviewer,
supervisor, context) · `agentic_rag/llm/` (provider-agnostic client) ·
`agentic_rag/workflow/graph.py` (the supervisor LangGraph) · `agentic_rag/tools`
are the grounded services under `facts/`, `retrieval/`, `grounding/`, `metrics/`.
