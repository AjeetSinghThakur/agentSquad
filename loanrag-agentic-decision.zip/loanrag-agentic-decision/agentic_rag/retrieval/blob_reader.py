"""Reads blobs from the same store the ingestion stage wrote to.

Two backends behind one tiny interface:
  'localfs'    -> a local folder (no SDK; for quick local tests)
  'azure_blob' -> the Azure Blob SDK. IMPORTANT: this ONE code path works for
                  BOTH the local Azurite emulator AND real Azure Blob Storage --
                  the CONNECTION STRING decides which you hit, not this name.
                  ('azurite' is accepted as a backward-compatible alias.)
"""

from __future__ import annotations

from pathlib import Path

from agentic_rag.config.settings import BlobSettings


class LocalFsBlobReader:
    """Reads blobs from files under a local root."""

    def __init__(self, root: str) -> None:
        """Resolve the root folder that stands in for blob storage."""
        self._root = Path(root).resolve()

    def list_keys(self, container: str, prefix: str = "") -> list[str]:
        """List blob names under a container (optionally filtered by prefix)."""
        base = self._root / container
        if not base.exists():
            return []
        keys = [str(p.relative_to(base)).replace("\\", "/")
                for p in base.rglob("*") if p.is_file()]
        return [k for k in keys if k.startswith(prefix)]

    def get(self, container: str, key: str) -> bytes:
        """Read the bytes stored at {container}/{key}."""
        return (self._root / container / key).read_bytes()


class AzureBlobReader:
    """Reads blobs via the Azure Blob SDK (real Azure Blob or the Azurite emulator)."""

    def __init__(self, connection_string: str) -> None:
        """Store the connection string; build clients lazily."""
        self._conn = connection_string

    def _service(self):
        """Create a BlobServiceClient from the connection string."""
        from azure.storage.blob import BlobServiceClient
        return BlobServiceClient.from_connection_string(self._conn)

    def list_keys(self, container: str, prefix: str = "") -> list[str]:
        """List blob names under a container (optionally filtered by prefix)."""
        try:
            client = self._service().get_container_client(container)
            return [b.name for b in client.list_blobs(name_starts_with=prefix or None)]
        except Exception:
            return []

    def get(self, container: str, key: str) -> bytes:
        """Download the bytes at {container}/{key}."""
        return self._service().get_blob_client(container, key).download_blob().readall()



class GcsBlobReader:
    """Reads chunks from Google Cloud Storage (one bucket; container = prefix)."""

    def __init__(self, bucket: str) -> None:
        """Remember the bucket; build the client lazily (uses ADC)."""
        self._bucket_name = bucket

    def _bucket(self):
        """Create a GCS bucket handle from Application Default Credentials."""
        from google.cloud import storage
        return storage.Client().bucket(self._bucket_name)

    def list_keys(self, container: str, prefix: str = "") -> list[str]:
        """List object names under {container}/ (optionally a deeper prefix)."""
        try:
            base = f"{container}/"
            keys = [b.name[len(base):] for b in self._bucket().list_blobs(prefix=base)]
            return [k for k in keys if k.startswith(prefix)]
        except Exception:
            return []

    def get(self, container: str, key: str) -> bytes:
        """Download the bytes at gs://<bucket>/<container>/<key>."""
        return self._bucket().blob(f"{container}/{key}").download_as_bytes()


def make_blob_reader(settings: BlobSettings):
    """Return the blob reader selected by configuration: localfs | azure_blob | gcs."""
    if settings.backend in ("azure_blob", "azurite"):   # "azurite" = legacy alias
        return AzureBlobReader(settings.connection_string)
    if settings.backend == "gcs":
        return GcsBlobReader(settings.gcs_bucket)
    return LocalFsBlobReader(settings.localfs_root)
