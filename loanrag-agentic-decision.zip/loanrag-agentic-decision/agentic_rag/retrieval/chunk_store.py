"""Loads ingested chunks for an application out of the `loan-chunks` store."""

from __future__ import annotations

import json

from agentic_rag.config.settings import Settings
from agentic_rag.domain.chunk import Chunk
from agentic_rag.retrieval.blob_reader import make_blob_reader


class ChunkStore:
    """Reads back the clean, quality-gated chunks the ingestion stage wrote."""

    def __init__(self, settings: Settings) -> None:
        """Build the blob reader and remember the container name."""
        self._reader = make_blob_reader(settings.blob)
        self._container = settings.blob.chunks_container

    def load(self, application_id: str) -> list[Chunk]:
        """Load every chunk for an application from all its document JSON files."""
        prefix = f"{application_id}/"
        chunks: list[Chunk] = []
        for key in self._reader.list_keys(self._container, prefix=prefix):
            if not key.endswith(".json"):
                continue
            for raw in json.loads(self._reader.get(self._container, key)):
                chunks.append(Chunk(
                    chunk_id=raw["chunk_id"], document_id=raw["document_id"],
                    text=raw.get("text", ""), source_kind=raw.get("source_kind", ""),
                    min_token_confidence=raw.get("min_token_confidence", 1.0),
                    inferred=raw.get("inferred", False), page=raw.get("page"),
                    extra=raw.get("extra", {}) or {}))
        return chunks

    def documents_present(self, application_id: str) -> set[str]:
        """Return the set of source filenames that were ingested for this app."""
        return {c.filename for c in self.load(application_id)}
