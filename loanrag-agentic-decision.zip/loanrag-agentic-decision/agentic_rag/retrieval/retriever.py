"""Evidence retriever.

A deterministic LEXICAL retriever (term-overlap scoring) is used by default so
the workflow runs anywhere with reproducible results and no external service.
It implements the same shape an Azure AI Search hybrid (vector + keyword)
retriever would, so the production swap is drop-in (see AZURE_DEPLOY.md).

Why lexical-by-default: it is transparent and reproducible, which matters for an
auditable lending decision. Semantic/vector recall is added in production via
Azure AI Search without changing the workflow.
"""

from __future__ import annotations

import re

from agentic_rag.domain.chunk import Chunk

_WORD = re.compile(r"[A-Za-z0-9]+")


class LexicalRetriever:
    """Scores chunks by overlap of query terms with chunk text (deterministic)."""

    def __init__(self, chunks: list[Chunk]) -> None:
        """Index the chunks (tokenise once for scoring)."""
        self._chunks = chunks
        self._tokens = {c.chunk_id: set(t.lower() for t in _WORD.findall(c.text))
                        for c in chunks}

    def retrieve(self, query: str, top_k: int) -> list[Chunk]:
        """Return the top_k chunks whose text best overlaps the query terms."""
        q = set(t.lower() for t in _WORD.findall(query))
        scored = []
        for c in self._chunks:
            overlap = len(q & self._tokens[c.chunk_id])
            if overlap:
                scored.append((overlap, c))
        scored.sort(key=lambda s: s[0], reverse=True)
        return [c for _, c in scored[:top_k]]
