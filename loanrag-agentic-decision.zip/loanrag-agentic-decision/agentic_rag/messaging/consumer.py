"""RabbitMQ consumer — the bridge that makes the RAG run AUTOMATICALLY.

It listens on the `loan.ingested` queue. For every message (one per application
whose documents finished ingesting) it calls the decision API's POST /assess.
The graph then runs to a decision or pauses for a human; either way the consumer
acknowledges the message and moves on. A paused loan costs nothing — it is a row
in the checkpointer waiting for a reviewer to click Approve/Reject.

Run it as its own process (and scale it horizontally):
    python -m agentic_rag.messaging.consumer

Config (env):
  RABBITMQ_URL     default amqp://guest:guest@localhost:5672/
  LOANRAG_QUEUE    default loan.ingested
  DECISION_API_URL default http://localhost:8080
"""

from __future__ import annotations

import json
import logging
import os

import requests

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s %(levelname)s consumer: %(message)s")
logger = logging.getLogger("agentic_rag.consumer")

QUEUE = os.environ.get("LOANRAG_QUEUE", "loan.ingested")
RABBITMQ_URL = os.environ.get("RABBITMQ_URL", "amqp://guest:guest@localhost:5672/")
DECISION_API_URL = os.environ.get("DECISION_API_URL", "http://localhost:8080")


def _handle(body: bytes) -> None:
    """Process one ingested-event message by calling the decision API."""
    msg = json.loads(body)
    app_id = msg["application_id"]
    payload = {"application_id": app_id,
               "loan_type": msg.get("loan_type", "PERSONAL"),
               "proposed_new_emi": msg.get("proposed_new_emi", 21000.0)}
    logger.info("assessing %s (%s)", app_id, payload["loan_type"])
    resp = requests.post(f"{DECISION_API_URL}/assess", json=payload, timeout=120)
    resp.raise_for_status()
    out = resp.json()
    if out.get("state") == "paused":
        kind = out.get("interrupt", {}).get("type", "decision")
        logger.info("%s -> PAUSED for human review (%s)", app_id, kind)
    else:
        logger.info("%s -> %s", app_id, out.get("status"))


def main() -> None:
    """Connect to RabbitMQ and consume ingested events forever."""
    import pika

    params = pika.URLParameters(RABBITMQ_URL)
    connection = pika.BlockingConnection(params)
    channel = connection.channel()
    channel.queue_declare(queue=QUEUE, durable=True)
    channel.basic_qos(prefetch_count=8)        # fair dispatch across consumers

    def on_message(ch, method, _props, body):
        try:
            _handle(body)
            ch.basic_ack(delivery_tag=method.delivery_tag)
        except Exception as exc:               # don't lose the message on a transient error
            logger.error("failed to process message: %s", exc)
            ch.basic_nack(delivery_tag=method.delivery_tag, requeue=True)

    channel.basic_consume(queue=QUEUE, on_message_callback=on_message)
    logger.info("waiting for messages on '%s' (api=%s)", QUEUE, DECISION_API_URL)
    channel.start_consuming()


if __name__ == "__main__":
    main()
