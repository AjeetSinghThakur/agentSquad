"""Recall and false-positive rate over the evidence retrieved for a decision.

These quantify retrieval quality on this specific application:

  recall              = of all criteria, the fraction for which the retriever
                        returned at least one chunk from an EXPECTED document
                        (did we FIND the evidence we needed?)
  false_positive_rate = of all retrieved chunks, the fraction that came from a
                        document NOT expected for that criterion
                        (how much NOISE did we pull in?)

Both are computed against a ground-truth map of criterion -> expected documents,
so they are objective and reproducible for audit.
"""

from __future__ import annotations

from agentic_rag.domain.evidence import Evidence
from agentic_rag.domain.retrieval_metrics import RetrievalMetrics


def compute_metrics(evidences: list[Evidence]) -> RetrievalMetrics:
    """Aggregate recall and false-positive rate across all criteria."""
    criteria_total = len(evidences)
    criteria_with_hit = 0
    retrieved_total = 0
    retrieved_off_target = 0

    for ev in evidences:
        expected = set(ev.expected_documents)
        got_docs = ev.retrieved_documents
        retrieved_total += len(got_docs)
        # recall: at least one retrieved chunk came from an expected document
        if any(d in expected for d in got_docs):
            criteria_with_hit += 1
        # false positives: retrieved chunks from documents we did NOT expect
        retrieved_off_target += sum(1 for d in got_docs if d not in expected)

    recall = (criteria_with_hit / criteria_total) if criteria_total else 0.0
    fpr = (retrieved_off_target / retrieved_total) if retrieved_total else 0.0
    return RetrievalMetrics(
        recall=round(recall, 4), false_positive_rate=round(fpr, 4),
        criteria_total=criteria_total, criteria_with_hit=criteria_with_hit,
        retrieved_total=retrieved_total, retrieved_off_target=retrieved_off_target)
