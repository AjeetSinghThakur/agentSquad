"""Assembles the MULTI-AGENT SUPERVISOR graph and compiles it with a checkpointer.

Topology (a supervisor routes a team; the supervisor is the ONLY router):

    START -> supervisor --+--> planner ------> supervisor
                          |--> researcher ---> supervisor   (I/O; auto-retry)
                          |--> verifier -----> supervisor   (grounding gate)
                          |--> underwriter --> supervisor   (deterministic decision)
                          |--> human_review -> supervisor   (HITL: approve/reject)
                          |--> error_review -> supervisor   (HITL: retry/abort)
                          |--> incomplete ---> END           (missing documents)
                          '--> finalize -----> END

The supervisor enforces the grounding gates (verifier before underwriter,
underwriter before human_review), so even with an LLM routing it, a loan can never
reach a decision ungrounded. The decision itself is computed by the Underwriter's
deterministic policy, never by the LLM. The checkpointer makes every pause durable.
"""

from __future__ import annotations

import logging
import sqlite3
from functools import partial
from pathlib import Path

from langgraph.graph import START, END, StateGraph
from langgraph.types import RetryPolicy

from agentic_rag.agents.context import AgentContext
from agentic_rag.agents.planner import Planner
from agentic_rag.agents.researcher import Researcher
from agentic_rag.agents.reviewer import error_review, finalize, human_review, incomplete
from agentic_rag.agents.supervisor import Supervisor
from agentic_rag.agents.underwriter import Underwriter
from agentic_rag.agents.verifier import Verifier
from agentic_rag.config.rules import load_rules
from agentic_rag.config.settings import Settings, get_settings
from agentic_rag.facts.authoritative_facts import AuthoritativeFactsRepository
from agentic_rag.grounding.grounded_decision import GroundedDecisionPolicy
from agentic_rag.llm.client import make_llm_client
from agentic_rag.retrieval.chunk_store import ChunkStore
from agentic_rag.workflow.state import LoanState

logger = logging.getLogger("agentic_rag")


def _make_checkpointer(settings: Settings):
    """Create the checkpointer that persists graph state for HITL pause/resume."""
    if settings.checkpointer.backend == "postgres":
        from langgraph.checkpoint.postgres import PostgresSaver
        saver = PostgresSaver.from_conn_string(settings.checkpointer.postgres_conn)
        saver.setup()
        return saver
    from langgraph.checkpoint.sqlite import SqliteSaver
    Path(settings.checkpointer.sqlite_path).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(settings.checkpointer.sqlite_path, check_same_thread=False)
    return SqliteSaver(conn)


def build_context(settings: Settings) -> AgentContext:
    """Composition root: load rules + assemble the services the agents depend on."""
    rules = load_rules(settings.rules_path)
    return AgentContext(
        settings=settings,
        chunk_store=ChunkStore(settings),
        facts_repo=AuthoritativeFactsRepository(settings.db.authoritative_db_path),
        policy=GroundedDecisionPolicy(rules),
        rules=rules,
        retry=rules.retry,
        llm=make_llm_client(settings),
        logger=logger)


def build_app(settings: Settings | None = None):
    """Build, wire, and compile the multi-agent supervisor graph."""
    settings = settings or get_settings()
    ctx = build_context(settings)
    io_retry = RetryPolicy(max_attempts=ctx.rules.retry.retry_policy_attempts)

    supervisor = Supervisor(ctx)
    planner, researcher = Planner(ctx), Researcher(ctx)
    verifier, underwriter = Verifier(ctx), Underwriter(ctx)

    g = StateGraph(LoanState)
    g.add_node("supervisor", supervisor.run)
    g.add_node("planner", planner.run)
    g.add_node("researcher", researcher.run, retry_policy=io_retry)
    g.add_node("verifier", verifier.run)
    g.add_node("underwriter", underwriter.run)
    g.add_node("human_review", partial(human_review, ctx=ctx))
    g.add_node("error_review", partial(error_review, ctx=ctx))
    g.add_node("incomplete", partial(incomplete, ctx=ctx))
    g.add_node("finalize", partial(finalize, ctx=ctx))

    g.add_edge(START, "supervisor")

    # The supervisor routes to exactly one agent based on state['next'].
    g.add_conditional_edges(
        "supervisor", lambda s: s["next"],
        {"planner": "planner", "researcher": "researcher", "verifier": "verifier",
         "underwriter": "underwriter", "human_review": "human_review",
         "error_review": "error_review", "incomplete": "incomplete",
         "finalize": "finalize"})

    # Every worker returns to the supervisor to be re-routed.
    for worker in ("planner", "researcher", "verifier", "underwriter",
                   "human_review", "error_review"):
        g.add_edge(worker, "supervisor")

    g.add_edge("incomplete", END)
    g.add_edge("finalize", END)

    return g.compile(checkpointer=_make_checkpointer(settings))
