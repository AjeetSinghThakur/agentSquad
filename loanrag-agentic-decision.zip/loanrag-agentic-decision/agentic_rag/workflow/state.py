"""The state carried through the loan-decision graph.

LangGraph passes this dict from node to node; each node returns a partial update.
We keep ONLY JSON-friendly primitives here (strings, numbers, lists, dicts) so the
state serialises cleanly into the checkpointer — that is what makes the HITL
pause/resume durable. Rich objects (chunks, Fact/Decision dataclasses) are rebuilt
inside nodes as needed rather than stored in the state.
"""

from __future__ import annotations

from typing import TypedDict


class LoanState(TypedDict, total=False):
    """Everything the workflow accumulates while assessing one application."""

    # inputs
    application_id: str
    loan_type: str          # product code from the application/event (e.g. PERSONAL)
    proposed_new_emi: float

    # supervisor/agent orchestration
    plan: list[str]         # ordered agent steps the supervisor will run
    completed: list[str]    # agent steps finished so far
    agent_trace: list[str]  # human-readable log of which agent did what (auditability)
    next: str               # the agent the supervisor routed to most recently

    # populated by the Researcher (raw, BEFORE verification)
    raw_facts: dict         # authoritative values straight from the system of record
    evidence_hits: list[dict]   # retrieved chunks per criterion (not yet scored)

    # populated by load_documents / completeness_gate
    applicant_name: str
    applicant_age: int
    applicant_gross: float
    applicant_age: int
    documents_present: list[str]
    missing_documents: list[str]
    completeness_ok: bool

    # populated by extract_facts (each fact as a plain dict)
    facts: list[dict]

    # populated by retrieve_evidence
    evidence: list[dict]
    metrics: dict

    # populated by decide
    dti: float
    recommendation: str
    risk_grade: str
    rationale: list[str]
    abstained: bool
    abstain_reasons: list[str]

    # populated by human_review / finalize
    human_decision: str
    human_note: str
    status: str

    # populated by the resilience layer (auto-retry + HITL escalation)
    error: dict            # {"node": ..., "message": ...} when a node can't recover
    retry_from: str        # node to resume at after a human chooses "retry"
    error_aborted: bool    # True if a human aborted a failed run
    error_action: str      # "retry" | "abort" chosen by a human at error_review
