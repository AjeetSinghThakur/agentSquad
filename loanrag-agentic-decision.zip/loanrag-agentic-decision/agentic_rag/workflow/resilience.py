"""Resilience helpers: automatic transient-error retry for I/O operations.

WHAT THIS GIVES YOU
  - `run_with_retry(...)` runs a risky operation (read blob, query DB) and, if it
    fails, retries automatically with EXPONENTIAL BACKOFF + JITTER up to a
    configured number of attempts. Most transient problems (a momentary network
    blip, a service warming up) recover on their own within a couple of retries.
  - If every attempt fails, it raises `PersistentError`. The calling node catches
    that, records the error in the graph state, and the graph routes to the
    `error_review` HITL node — so a human is asked to look, rather than the run
    crashing. The human can then choose to retry or abort.

This is the "try automatically until recovered; if not, raise a human" behaviour.
"""

from __future__ import annotations

import logging
import random
import time
from typing import Callable, TypeVar

logger = logging.getLogger("agentic_rag")

T = TypeVar("T")


class PersistentError(Exception):
    """Raised when an operation still fails after all retry attempts are spent."""


def run_with_retry(operation: Callable[[], T], *, label: str, max_attempts: int,
                   base_delay: float, max_delay: float) -> T:
    """Run `operation`, retrying transient failures with exponential backoff.

    label       : a human-readable name for logging (e.g. the node name)
    max_attempts: total tries before giving up
    base_delay  : seconds to wait before the 2nd attempt (doubles each time)
    max_delay   : cap on the backoff wait
    Returns the operation's result, or raises PersistentError if all tries fail.
    """
    last_error: Exception | None = None
    for attempt in range(1, max_attempts + 1):
        try:
            return operation()
        except Exception as exc:                      # treat any failure as transient
            last_error = exc
            logger.warning("'%s' attempt %d/%d failed: %s",
                           label, attempt, max_attempts, exc)
            if attempt < max_attempts:
                # exponential backoff with jitter: 0.5*d .. 1.5*d
                delay = min(max_delay, base_delay * (2 ** (attempt - 1)))
                delay *= (0.5 + random.random())
                time.sleep(delay)
    raise PersistentError(
        f"{label} failed after {max_attempts} attempts: {last_error}") from last_error
