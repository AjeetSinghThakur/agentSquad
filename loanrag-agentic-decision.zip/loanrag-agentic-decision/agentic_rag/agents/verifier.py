"""Verifier agent — the grounding guardrail.

Takes the Researcher's RAW facts and proves each one by EXACT match against the
documents (no fuzzy matching). It also scores retrieval (recall / false-positive)
and sets the abstain flag if any decision-critical fact is uncorroborated. This is
what guarantees the Underwriter only ever sees grounded numbers.
"""

from __future__ import annotations

from agentic_rag.agents.context import AgentContext
from agentic_rag.domain.enums import FactStatus
from agentic_rag.domain.evidence import Evidence
from agentic_rag.domain.fact import Fact
from agentic_rag.facts.exact_fact_extractor import ExactFactCorroborator
from agentic_rag.metrics.recall_false_positive import compute_metrics
from agentic_rag.workflow.state import LoanState


class Verifier:
    """Corroborates facts, scores retrieval, and decides whether to abstain."""

    name = "verifier"

    def __init__(self, ctx: AgentContext) -> None:
        """Hold the shared context."""
        self._ctx = ctx

    def run(self, state: LoanState) -> dict:
        """Exact-match each raw fact, compute metrics, and flag abstention."""
        ctx, app = self._ctx, state["application_id"]
        chunks = ctx.load_chunks(app)
        raw = state.get("raw_facts", {})
        src = ctx.rules.fact_sources
        corro = ExactFactCorroborator(chunks)

        def verify(name: str, value, source: str) -> Fact:
            return corro.corroborate(name, value, source,
                                     preferred_documents=src.get(name))

        net = verify("monthly_net", raw.get("monthly_net"), "authoritative_db: income.monthly_net")
        credit = verify("credit_score", raw.get("credit_score"), "authoritative_db: credit_bureau.score")
        emi = verify("existing_emi_total", raw.get("existing_emi_total"),
                     "authoritative_db: sum(obligations.monthly_emi)")

        def as_dict(f: Fact) -> dict:
            return {"name": f.name, "value": f.value, "source": f.source,
                    "status": f.status.value, "citation_chunk_id": f.citation_chunk_id,
                    "rendered": f.rendered}

        facts = [as_dict(net), as_dict(credit), as_dict(emi)]
        uncorroborated = [f["name"] for f in facts if f["status"] == FactStatus.UNCORROBORATED.value]

        # score retrieval from the Researcher's hits
        evidences = [Evidence(criterion=h["criterion"], query=h["query"],
                              expected_documents=h["expected"],
                              retrieved_chunk_ids=h["retrieved_chunk_ids"],
                              retrieved_documents=h["retrieved_documents"])
                     for h in state.get("evidence_hits", [])]
        m = compute_metrics(evidences)

        completed = list(state.get("completed", [])); completed.append(self.name)
        trace = list(state.get("agent_trace", []))
        trace.append(f"verifier -> corroborated {3 - len(uncorroborated)}/3, recall {m.recall}")
        ctx.logger.info("verifier: %d/3 corroborated, recall=%.2f for %s",
                       3 - len(uncorroborated), m.recall, app)
        return {"facts": facts,
                "abstained": bool(uncorroborated),
                "abstain_reasons": [f"'{n}' not exactly corroborated" for n in uncorroborated],
                "metrics": {"recall": m.recall, "false_positive_rate": m.false_positive_rate,
                            "criteria_total": m.criteria_total,
                            "criteria_with_hit": m.criteria_with_hit,
                            "retrieved_total": m.retrieved_total,
                            "retrieved_off_target": m.retrieved_off_target},
                "completed": completed, "agent_trace": trace}
