"""The shared context every agent receives (services + rules + LLM + cache).

This is the agentic equivalent of the old NodeContext: it bundles the grounded
services the agents call as TOOLS (chunk store, authoritative facts, decision
policy), the loaded business rules, the (optional) LLM client, and a per-process
chunk cache whose loads auto-retry transient failures.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

from agentic_rag.config.rules import RetryRules, Rules
from agentic_rag.config.settings import Settings
from agentic_rag.domain.chunk import Chunk
from agentic_rag.facts.authoritative_facts import AuthoritativeFactsRepository
from agentic_rag.grounding.grounded_decision import GroundedDecisionPolicy
from agentic_rag.llm.client import LlmClient
from agentic_rag.retrieval.chunk_store import ChunkStore
from agentic_rag.workflow.resilience import run_with_retry


@dataclass
class AgentContext:
    """Everything the agents need; passed into every agent's run()."""

    settings: Settings
    chunk_store: ChunkStore
    facts_repo: AuthoritativeFactsRepository
    policy: GroundedDecisionPolicy
    rules: Rules
    retry: RetryRules
    llm: LlmClient
    logger: logging.Logger
    _cache: dict[str, list[Chunk]] = field(default_factory=dict)

    def load_chunks(self, application_id: str) -> list[Chunk]:
        """Load (and cache) an application's ingested chunks, with auto-retry."""
        if application_id not in self._cache:
            self._cache[application_id] = run_with_retry(
                lambda: self.chunk_store.load(application_id),
                label="load_chunks", max_attempts=self.retry.max_attempts,
                base_delay=self.retry.base_delay_seconds,
                max_delay=self.retry.max_delay_seconds)
        return self._cache[application_id]
