"""Researcher agent — gathers raw evidence (no judgement yet).

It calls the grounded tools to:
  - see which documents were ingested (and check completeness),
  - read the authoritative facts LIVE from the system of record (RAW values), and
  - retrieve supporting chunks per criterion.
It does NOT corroborate or decide — that is the Verifier's and Underwriter's job.
Transient read failures auto-retry; a persistent failure is escalated via error.
"""

from __future__ import annotations

from agentic_rag.agents.context import AgentContext
from agentic_rag.retrieval.retriever import LexicalRetriever
from agentic_rag.workflow.resilience import PersistentError
from agentic_rag.workflow.state import LoanState


class Researcher:
    """Collects documents, raw facts, and retrieval hits into the shared state."""

    name = "researcher"

    def __init__(self, ctx: AgentContext) -> None:
        """Hold the shared context."""
        self._ctx = ctx

    def run(self, state: LoanState) -> dict:
        """Gather documents present, raw authoritative facts, and evidence hits."""
        ctx, app = self._ctx, state["application_id"]
        try:
            chunks = ctx.load_chunks(app)
            auth = ctx.facts_repo.fetch(app)
        except (PersistentError, Exception) as exc:   # noqa: BLE001 - escalate to HITL
            ctx.logger.error("researcher: could not read data: %s", exc)
            return {"error": {"node": "researcher", "message": str(exc)}}

        present = sorted({c.filename for c in chunks})
        loan_type = state.get("loan_type", "")
        required = ctx.rules.per_product_documents.get(loan_type) or ctx.rules.required_documents
        missing = [d for d in required if d not in present]

        # raw authoritative values (NOT yet corroborated)
        raw = {"monthly_net": auth.monthly_net, "credit_score": auth.credit_score,
               "existing_emi_total": auth.existing_emi_total,
               "applicant_name": auth.applicant_name, "applicant_age": auth.age,
               "applicant_gross": auth.monthly_gross}

        # retrieval hits per criterion (scoring/metrics happen in the Verifier)
        retriever = LexicalRetriever(chunks)
        top_k = ctx.settings.retrieval.top_k
        hits = []
        for crit in ctx.rules.criteria:
            got = retriever.retrieve(crit.query, top_k)
            hits.append({"criterion": crit.name, "query": crit.query,
                         "expected": crit.expected_documents,
                         "retrieved_documents": [h.filename for h in got],
                         "retrieved_chunk_ids": [h.chunk_id for h in got]})

        completed = list(state.get("completed", [])); completed.append(self.name)
        trace = list(state.get("agent_trace", []))
        trace.append(f"researcher -> {len(present)} docs, {len(missing)} missing, raw facts read")
        ctx.logger.info("researcher: %d docs present, %d missing for %s",
                       len(present), len(missing), app)
        return {"documents_present": present, "missing_documents": missing,
                "completeness_ok": not missing, "raw_facts": raw,
                "evidence_hits": hits, "applicant_name": auth.applicant_name,
                "applicant_age": auth.age, "applicant_gross": auth.monthly_gross,
                "completed": completed, "agent_trace": trace, "error": {}}
