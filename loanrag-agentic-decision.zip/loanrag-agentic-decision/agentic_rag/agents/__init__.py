"""Multi-agent supervisor team for grounded loan decisions."""
