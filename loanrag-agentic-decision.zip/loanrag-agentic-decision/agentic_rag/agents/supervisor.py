"""Supervisor — the orchestrator that decides which agent runs next.

It is deliberately the ONLY place routing happens. It computes the deterministic
next step from the plan + what's completed, optionally lets the LLM confirm/choose
(off by default), and then VALIDATES the choice so a grounding gate can never be
skipped: a loan cannot reach the Underwriter before the Verifier, nor reach
human_review before the Underwriter. Errors divert to error_review; a missing
document diverts to `incomplete`.
"""

from __future__ import annotations

from agentic_rag.agents.context import AgentContext
from agentic_rag.workflow.state import LoanState

# Hard prerequisites the supervisor enforces no matter what the LLM suggests.
_PREREQS = {"verifier": "researcher", "underwriter": "verifier", "human_review": "underwriter"}


class Supervisor:
    """Routes the team; guarantees the order of the grounding gates."""

    name = "supervisor"

    def __init__(self, ctx: AgentContext) -> None:
        """Hold the shared context (for the optional LLM + logging)."""
        self._ctx = ctx

    def route(self, state: LoanState) -> str:
        """Return the name of the next node to run."""
        completed = state.get("completed", [])

        # 0) A human aborted a failed run -> finish.
        if state.get("error_aborted"):
            return "finalize"
        # 1) Plan first.
        if "planner" not in completed:
            return "planner"
        # 2) An agent failed -> human error review.
        if state.get("error"):
            return "error_review"
        # 3) Documents missing (known after the researcher) -> block.
        if "researcher" in completed and not state.get("completeness_ok", True):
            return "incomplete"

        # 4) Next uncompleted plan step (deterministic candidate).
        plan = state.get("plan", [])
        candidate = next((s for s in plan if s not in completed), "finalize")
        if candidate == "finalize":
            return "finalize"

        # 5) Optional LLM routing, then VALIDATE against prerequisites.
        choice = self._ctx.llm.choose_next(candidate, list(completed), list(plan))
        if choice not in plan or choice in completed:
            choice = candidate                      # ignore invalid LLM choice
        prereq = _PREREQS.get(choice)
        if prereq and prereq not in completed:
            choice = candidate                      # never skip a grounding gate
        self._ctx.logger.info("supervisor -> %s (for %s)", choice, state["application_id"])
        return choice

    def run(self, state: LoanState) -> dict:
        """Record the routing decision in the state (the edge reads state['next'])."""
        nxt = self.route(state)
        trace = list(state.get("agent_trace", [])); trace.append(f"supervisor -> {nxt}")
        return {"next": nxt, "agent_trace": trace}
