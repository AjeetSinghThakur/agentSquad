"""Planner agent — decides the sequence of work for an application.

With no LLM it emits the standard, safe plan (research -> verify -> underwrite ->
review). An LLM, if configured, may only REFINE within safe bounds; the supervisor
still enforces that verification happens before underwriting and underwriting
before review, so the plan can never skip a grounding gate.
"""

from __future__ import annotations

from agentic_rag.agents.context import AgentContext
from agentic_rag.workflow.state import LoanState

# The fixed, safe pipeline. Verifier MUST precede underwriter; underwriter MUST
# precede human_review. The supervisor enforces these prerequisites regardless.
DEFAULT_PLAN = ["researcher", "verifier", "underwriter", "human_review"]


class Planner:
    """Builds the plan the supervisor will route through."""

    name = "planner"

    def __init__(self, ctx: AgentContext) -> None:
        """Hold the shared context."""
        self._ctx = ctx

    def run(self, state: LoanState) -> dict:
        """Set the ordered plan and mark planning complete."""
        self._ctx.logger.info("planner: planning %s (%s)",
                              state["application_id"], state.get("loan_type", "PERSONAL"))
        completed = list(state.get("completed", []))
        completed.append(self.name)
        trace = list(state.get("agent_trace", []))
        trace.append(f"planner -> plan={DEFAULT_PLAN}")
        return {"plan": list(DEFAULT_PLAN), "completed": completed, "agent_trace": trace}
