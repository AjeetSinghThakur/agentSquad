"""Reviewer agent + the HITL / terminal handlers.

`human_review` pauses the run and presents the cited package; a human resumes with
approve / reject / override. `error_review` pauses when an agent could not recover
and lets a human retry or abort. `finalize` records the outcome (the human wins
over the recommendation). `incomplete` blocks a decision when documents are missing.

These are plain functions (not a class) because they are graph endpoints that call
`interrupt()`; keeping the node names `human_review` / `error_review` also means the
API's reviewer console and /pending queue work unchanged.
"""

from __future__ import annotations

from langgraph.types import interrupt

from agentic_rag.agents.context import AgentContext
from agentic_rag.workflow.state import LoanState


def human_review(state: LoanState, ctx: AgentContext) -> dict:
    """Pause and present the decision package; resume with the human's choice."""
    payload = {
        "type": "decision",
        "application_id": state["application_id"],
        "loan_type": state.get("loan_type"),
        "applicant_name": state.get("applicant_name"),
        "recommendation": state.get("recommendation"),
        "risk_grade": state.get("risk_grade"),
        "dti": state.get("dti"),
        "completeness_ok": state.get("completeness_ok"),
        "abstained": state.get("abstained"),
        "rationale": state.get("rationale"),
        "metrics": state.get("metrics"),
        "facts": state.get("facts"),
        "agent_trace": state.get("agent_trace"),
        "instructions": "Resume with {'decision': 'approve'|'reject'|'override', 'note': '...'}",
    }
    decision = interrupt(payload)               # <-- PAUSE until a human resumes
    completed = list(state.get("completed", [])); completed.append("human_review")
    if isinstance(decision, dict):
        return {"human_decision": decision.get("decision", ""),
                "human_note": decision.get("note", ""), "completed": completed}
    return {"human_decision": str(decision), "completed": completed}


def error_review(state: LoanState, ctx: AgentContext) -> dict:
    """HITL escalation when an agent could not recover: human picks retry | abort."""
    err = state.get("error", {})
    decision = interrupt({
        "type": "system_error",
        "application_id": state["application_id"],
        "failed_node": err.get("node"),
        "message": err.get("message"),
        "instructions": "Resume with {'action': 'retry'} or {'action': 'abort'}",
    })
    action = decision.get("action", "abort") if isinstance(decision, dict) else str(decision)
    if action == "retry":
        ctx.logger.info("error_review: RETRY for %s", state["application_id"])
        # re-run research after a transient failure: drop it from 'completed'
        completed = [c for c in state.get("completed", []) if c != "researcher"]
        return {"error": {}, "error_action": "retry", "completed": completed}
    ctx.logger.info("error_review: ABORT for %s", state["application_id"])
    return {"error_aborted": True, "error_action": "abort",
            "status": f"FAILED: aborted by human after error in {err.get('node')}"}


def incomplete(state: LoanState, ctx: AgentContext) -> dict:
    """Block a decision when required documents are missing (refer, never approve)."""
    missing = state.get("missing_documents", [])
    return {"recommendation": "refer", "abstained": True,
            "abstain_reasons": [f"required documents not yet ingested: {missing}"],
            "rationale": [f"Cannot assess: missing required documents {missing}. "
                          f"Approval is blocked until all documents are read."],
            "status": "BLOCKED: incomplete documents"}


def finalize(state: LoanState, ctx: AgentContext) -> dict:
    """Record the final outcome (the human decision wins over the recommendation)."""
    if state.get("error_aborted"):
        return {"status": state.get("status", "FAILED: aborted")}
    final = state.get("human_decision") or state.get("recommendation")
    return {"status": f"FINAL: {str(final).upper()}"}
