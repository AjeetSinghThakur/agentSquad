"""The decision package produced by the workflow."""

from __future__ import annotations

from dataclasses import dataclass, field

from agentic_rag.domain.enums import Decision
from agentic_rag.domain.fact import Fact
from agentic_rag.domain.retrieval_metrics import RetrievalMetrics


@dataclass
class DecisionResult:
    """Everything needed to make and justify a loan decision.

    The recommendation is DETERMINISTIC (a policy over corroborated facts) — no
    language model invents it, so there is nothing to hallucinate. `rationale`
    lines are built only from cited facts. A human makes the FINAL call (HITL),
    which is captured in `human_decision`.
    """

    application_id: str
    recommendation: Decision
    rationale: list[str] = field(default_factory=list)      # each line cites a fact
    facts: list[Fact] = field(default_factory=list)
    dti: float | None = None
    risk_grade: str = ""            # internal grade (A-E) from credit score bands
    metrics: RetrievalMetrics | None = None
    completeness_ok: bool = False
    missing_documents: list[str] = field(default_factory=list)
    abstained: bool = False
    abstain_reasons: list[str] = field(default_factory=list)
    human_decision: str | None = None      # final approve/reject/override
    human_note: str = ""
