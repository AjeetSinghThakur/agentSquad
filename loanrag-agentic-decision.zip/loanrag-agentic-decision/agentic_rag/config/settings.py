"""Application settings for the loan-decision workflow.

Bound from environment with the LOANRAG__Section__Key convention, e.g.:
    LOANRAG__BLOB__BACKEND=azurite
    LOANRAG__POLICY__MAX_DTI_ACCEPTABLE=0.55
    LOANRAG__CHECKPOINTER__BACKEND=sqlite
The defaults make it run locally against the chunks the ingestion stage wrote.
"""

from __future__ import annotations

from functools import lru_cache

from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class BlobSettings(BaseModel):
    """Where to read the ingested chunks from (must match the ingestion output).

    backend 'localfs' reads a folder; 'azurite' reads Azurite/Azure Blob. The
    chunks_container is the same `loan-chunks` the ingestion stage wrote to.
    """

    backend: str = "localfs"           # 'localfs' | 'azure_blob' (emulator OR real Azure) | 'gcs'
    gcs_bucket: str = ""                # GCP: one bucket; container is an object prefix
    connection_string: str = "UseDevelopmentStorage=true"
    localfs_root: str = "./_localblob"
    chunks_container: str = "loan-chunks"


class DbSettings(BaseModel):
    """System-of-record database queried LIVE for authoritative facts (ADR-003).

    Locally this is the sqlite file produced with the samples; in Azure this
    would be a real connection (Azure SQL / PostgreSQL). Authoritative numbers
    are NEVER read from embedded chunks — always queried here at decision time.
    """

    authoritative_db_path: str = "./data/authoritative_facts.sqlite"


class RetrievalSettings(BaseModel):
    """Evidence-retrieval configuration."""

    top_k: int = 4                         # chunks retrieved per criterion


class CheckpointerSettings(BaseModel):
    """Durable state store for LangGraph (enables HITL pause/resume).

    'sqlite' is perfect for local/single-node; 'postgres' is the production
    choice on Azure (Azure Database for PostgreSQL) so a paused loan survives
    restarts and scale-out.
    """

    backend: str = "sqlite"                # 'sqlite' | 'postgres'
    sqlite_path: str = "./_state/loan_workflow.sqlite"
    postgres_conn: str = ""                # e.g. postgresql://user:pwd@host:5432/db


class LlmSettings(BaseModel):
    """Optional grounded-rationale LLM (OFF by default).

    The DECISION is deterministic and never needs an LLM. If enabled, an LLM may
    only PARAPHRASE already-grounded, cited facts (it cannot introduce new
    claims), keeping hallucination at zero. 'none' = deterministic template only.
    """

    backend: str = "none"                  # 'none' | 'azure_openai'
    azure_endpoint: str = ""
    azure_deployment: str = ""


class Settings(BaseSettings):
    """Root settings, composed of nested sections."""

    model_config = SettingsConfigDict(
        env_prefix="LOANRAG__", env_nested_delimiter="__",
        case_sensitive=False, extra="ignore")

    blob: BlobSettings = Field(default_factory=BlobSettings)
    db: DbSettings = Field(default_factory=DbSettings)
    retrieval: RetrievalSettings = Field(default_factory=RetrievalSettings)
    checkpointer: CheckpointerSettings = Field(default_factory=CheckpointerSettings)
    llm: LlmSettings = Field(default_factory=LlmSettings)

    # Business rules (approval thresholds, required documents, retrieval criteria,
    # fact sources, retry) live in this YAML file, NOT in code — edit it to tune
    # behaviour without a code change. See agentic_rag/config/rules.py.
    rules_path: str = "./config/rules.yaml"


@lru_cache
def get_settings() -> Settings:
    """Return a process-wide cached Settings singleton."""
    return Settings()
