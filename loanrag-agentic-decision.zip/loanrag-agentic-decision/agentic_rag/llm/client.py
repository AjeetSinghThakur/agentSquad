"""Provider-agnostic LLM client for the agentic system — OFF by default.

The multi-agent team is fully functional WITHOUT an LLM: the supervisor follows
the planned order and the decision is computed deterministically. An LLM, when
configured, may only:
  - help the supervisor ROUTE (pick the next agent), and
  - NARRATE (rephrase the already-grounded rationale).
It never produces a fact or the recommendation — those come from grounded tools.

`NullLlmClient` is the default: it makes the routing/narration deterministic, so
the whole system runs with no credentials and no network. Real providers
(Anthropic / Azure OpenAI / Vertex) implement the same Protocol; adapters are not
bundled here (provider-agnostic), and `make_llm_client` shows where to add one.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from agentic_rag.config.settings import Settings


@runtime_checkable
class LlmClient(Protocol):
    """The narrow interface the agents use. Implement this for any provider."""

    def choose_next(self, candidate: str, completed: list[str], plan: list[str]) -> str:
        """Pick the next agent. MUST return a value the supervisor allows.

        `candidate` is the deterministic next step; an implementation may confirm
        it or pick another *allowed* step, but the supervisor validates the result.
        """
        ...

    def narrate(self, rationale: list[str]) -> str:
        """Optionally rephrase the grounded rationale. Return '' to keep it as-is."""
        ...


class NullLlmClient:
    """Default no-LLM client: deterministic routing, no narration."""

    def choose_next(self, candidate: str, completed: list[str], plan: list[str]) -> str:
        """Always take the deterministic next step (no reordering)."""
        return candidate

    def narrate(self, rationale: list[str]) -> str:
        """No LLM -> keep the deterministic, cited rationale unchanged."""
        return ""


def make_llm_client(settings: Settings) -> LlmClient:
    """Return the configured LLM client. Defaults to NullLlmClient ('none').

    To use a real provider, set LOANRAG__LLM__BACKEND and add an adapter class
    implementing `LlmClient` (e.g. AnthropicLlmClient / AzureOpenAiLlmClient /
    VertexLlmClient), then return it here. Kept provider-agnostic on purpose.
    """
    backend = settings.llm.backend
    if backend in ("", "none"):
        return NullLlmClient()
    raise NotImplementedError(
        f"LLM backend '{backend}' has no bundled adapter. Implement an LlmClient "
        f"for it in agentic_rag/llm/ and return it from make_llm_client(). "
        f"The system runs fully without an LLM (backend='none').")
