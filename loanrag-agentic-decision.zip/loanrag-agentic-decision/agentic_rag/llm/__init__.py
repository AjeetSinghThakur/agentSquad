"""Provider-agnostic LLM client (off by default)."""
