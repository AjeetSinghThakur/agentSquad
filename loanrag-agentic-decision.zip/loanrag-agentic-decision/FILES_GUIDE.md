# FILES_GUIDE — what every file is and why it exists

You're newer to Python, so this explains each file in plain language and maps it
to the .NET ideas you already know. Read this top-to-bottom once and the codebase
will feel familiar.

## Python ↔ .NET quick map

| Python thing | .NET equivalent | In this project |
|---|---|---|
| a folder with `__init__.py` | a namespace / project | every folder under `agentic_rag/` |
| `@dataclass` | `record` / POCO with auto constructor | `domain/*.py` models |
| `Protocol` | `interface` | the retriever "shape" (duck-typed) |
| `TypedDict` | a typed DTO / dictionary contract | `workflow/state.py` |
| `@lru_cache` | a cached singleton | `get_settings()` |
| `async def` / `await` | `async` / `await` | the workflow nodes |
| `functools.partial` | partial application / a closure | binding services into nodes |
| module-level function | a static method | the node functions |

Note: `__init__.py` files are tiny on purpose — they just mark a folder as a
package (a namespace). They usually hold one docstring line and nothing else.

---

## The layers (Clean Architecture, same as your .NET solutions)

```
agentic_rag/
  config/        settings (no logic — just configuration)
  domain/        the core models (no dependencies on anything)
  retrieval/     read chunks from blob + find evidence
  facts/         live DB facts + exact-match corroboration
  metrics/       recall / false-positive calculation
  grounding/     the deterministic decision policy
  workflow/      the LangGraph graph (this is the orchestrator)
  presentation/  the CLI (how a human/operator triggers it)
```

Dependencies point inward: `presentation` → `workflow` → (`facts`, `retrieval`,
`grounding`, `metrics`) → `domain`. `domain` depends on nothing. Exactly like a
.NET Clean Architecture solution.

---

## File-by-file

### config
- **`config/settings.py`** — INFRASTRUCTURE configuration in one typed object
  (think `appsettings.json` + `IOptions<T>`). Reads env vars `LOANRAG__Section__Key`
  (where the blob/DB live, sqlite vs Postgres, the rules-file path). *Why:* infra
  settings change per environment, so they live in env vars.
- **`config/rules.py`** — typed loader for the BUSINESS rules. *Why:* validates
  `rules.yaml` into typed objects (Rules/Criterion/PolicyRules/RetryRules) so a bad
  edit fails fast instead of silently misbehaving.
- **`../config/rules.yaml`** (package root) — the business rules themselves:
  approval thresholds, required documents, which document corroborates each fact,
  retrieval criteria, and retry settings. *Why:* a risk/credit owner edits this —
  no code change. This is the "not hard-coded" home for the loan rules.

### domain (the nouns — pure data, no behaviour)
- **`domain/enums.py`** — fixed choice lists: `Decision` (approve/reject/refer)
  and `FactStatus` (corroborated/uncorroborated). *Why:* avoids magic strings.
- **`domain/chunk.py`** — `Chunk`: one piece of clean text from the ingestion
  stage (text + which document + OCR confidence). *Why:* the unit we read & cite.
- **`domain/fact.py`** — `Fact`: one decision number (e.g. net income) plus where
  it came from and whether a document exactly confirms it. *Why:* every input to
  the decision is traceable.
- **`domain/evidence.py`** — `Evidence`: for one criterion, which documents we
  *expected* vs which chunks we actually *retrieved*. *Why:* needed to score
  recall / false-positive.
- **`domain/retrieval_metrics.py`** — `RetrievalMetrics`: the recall and
  false-positive numbers. *Why:* a typed container for the scores.
- **`domain/decision.py`** — `DecisionResult`: the full decision package
  (recommendation, cited rationale, facts, DTI, metrics, human decision). *Why:*
  the single object the workflow builds and a reviewer reads.

### retrieval (reading the ingested data)
- **`retrieval/blob_reader.py`** — reads files from blob storage; two
  implementations (a local folder, or Azurite/Azure Blob) chosen by config.
  *Why:* the decision stage must read exactly what ingestion wrote, locally or in
  the cloud, without code changes.
- **`retrieval/chunk_store.py`** — loads all of an application's chunks back into
  `Chunk` objects. *Why:* turns raw JSON in blob into typed objects we can use.
- **`retrieval/retriever.py`** — `LexicalRetriever`: finds the chunks most
  relevant to a query (simple word-overlap scoring). *Why:* the "retrieval" in
  RAG. It's deliberately simple and deterministic locally; Azure AI Search slots
  in here for production (same method name).

### facts (the numbers that decide the loan)
- **`facts/authoritative_facts.py`** — queries the system-of-record database
  **live** for income, obligations, and credit score. *Why:* these must be
  current, never a stale embedded copy (this is ADR-003 from the design).
- **`facts/exact_fact_extractor.py`** — confirms each live number also appears,
  **exactly**, in a document (accepting `21,500` or `21500`, never `21,400`).
  *Why:* this is the "exact match, no fuzzy" rule; an unconfirmed number is
  flagged so the decision can abstain instead of trusting it.

### metrics
- **`metrics/recall_false_positive.py`** — computes recall (did we find the
  evidence?) and false-positive rate (how much noise did we pull in?). *Why:* the
  two retrieval KPIs you asked for, reported on every decision.

### grounding (the actual decision)
- **`grounding/grounded_decision.py`** — the **deterministic** lending policy:
  computes DTI, applies thresholds, and writes a rationale where every line cites
  a fact. If a needed fact isn't corroborated it returns REFER (abstains). *Why:*
  because a fixed policy — not a language model — makes the call, there is nothing
  to hallucinate. This is the heart of the zero-hallucination guarantee.

### workflow (LangGraph — the orchestrator)
- **`workflow/state.py`** — `LoanState`: the data that flows step to step. Kept to
  simple values so it can be saved by the checkpointer (which is what makes the
  human pause durable). *Why:* the graph's shared "memory".
- **`workflow/nodes.py`** — one function per step (load → completeness → facts →
  evidence → decide → human_review → finalize). `human_review` calls
  `interrupt()` to pause for a human. *Why:* each node does one job; the order is
  enforced by the graph, not by you remembering to call things in sequence.
- **`workflow/resilience.py`** — `run_with_retry`: runs a risky read and
  auto-retries transient failures with exponential backoff; raises `PersistentError`
  if it can't recover. *Why:* self-healing for blips, and a clean signal to escalate
  to a human when it's truly stuck. (The `error_review` node in `nodes.py` is the
  human-escalation step it feeds.)
- **`workflow/graph.py`** — wires the nodes together with edges, including the
  completeness branch AND the error/retry routing (I/O node → `error_review` on
  persistent failure; `error_review` → retry/abort), and compiles with a **checkpointer**
  (SQLite locally, Postgres on Azure). *Why:* the edges *are* the guarantees (a
  loan can't reach `decide` without passing the completeness gate), and the
  checkpointer is what lets the human pause survive restarts.

### presentation
- **`presentation/cli.py`** — the command line: `run`, `resume`, `status`. *Why:*
  how you trigger and resume the workflow locally.
- **`presentation/api.py`** — a small **FastAPI** service (`/assess`, `/resume`,
  `/status`, `/healthz`, `/pending`, and `GET /` the **reviewer console**). *Why:*
  the long-running process Kubernetes runs and the HPA scales; the console is where
  a human clicks Approve/Reject (the buttons call `/resume`).

### messaging (the automatic trigger)
- **`messaging/publisher.py`** — ingestion calls `publish_ingested(...)` to put a
  'loan ready to decide' event on RabbitMQ (carries `application_id`, `loan_type`).
- **`messaging/consumer.py`** — a worker that consumes the queue and calls the
  decision API `POST /assess`. *Why:* this is what makes the RAG run automatically.

---

## Root files

- **`requirements.txt`** — the libraries to install (`pip install -r ...`); like
  your `.csproj` package references.
- **`pyproject.toml`** — package metadata (name, Python version); like a
  project file.
- **`Dockerfile`** — builds the container image for this stage.
- **`docker-compose.yml`** — runs Azurite + this app locally for a cloud-like try.
- **`deploy/scripts/provision-azure.ps1`** — creates every Azure resource with the `az`
  CLI and prints the settings to use. PowerShell, parameterised.
- **`README.md`** — quick start.
- **`DESIGN_AND_GUIDE.md`** — the full design + the diagrams + the Azure service
  list + how to test it.
- **`KPIS.md`** — what every KPI means, why we use it, and where it lives in code.
- **`RULES_GUIDE.md`** — every Indian-lending rule category, the RBI context, what's enforced vs ready, and what changes when the real DB arrives.
- **`config/rules.yaml`** — the editable business rules (see config above).
- **`AZURE_DEPLOY.md`** — what to swap for Azure (Postgres checkpointer, Azure AI
  Search, Azure SQL, Azure OpenAI, Container Apps).
- **`docs/diagrams/`** — workflow, architecture, and class diagrams (PNG for
  printing, SVG source alongside).
- **`deploy/scripts/`** — `provision-azure.ps1` (az CLI) and `provision-gcp.sh`
  (gcloud) create all cloud resources.
- **`deploy/k8s/`** — Kubernetes manifests: Deployment, Service, rules ConfigMap,
  Secret template, and the **HPA** (autoscaling).
- **`deploy/pipelines/azure-pipelines.yml`** — Azure DevOps CI/CD: build once,
  deploy to AKS *and* GKE with the HPA.
- **`GCP_DEPLOY.md`** — the Google Cloud deployment guide (mirrors AZURE_DEPLOY.md).
- **`_localblob/`**, **`data/`** — bundled sample data (the ingested chunks and
  the authoritative sqlite DB) so it runs out of the box.
