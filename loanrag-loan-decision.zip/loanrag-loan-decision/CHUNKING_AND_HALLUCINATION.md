# Chunking, Overlap & Hallucination — with real examples

This explains how LoanRAG splits documents into chunks, the overlap scenarios you
hit in real systems (with concrete examples), how durability/“no data loss” is
handled, and exactly how hallucination is controlled — including the (non-)use of
an LLM.

---

## 1. Where chunks are created and read (code map)

| Step | File | Symbol |
|---|---|---|
| Create chunks (ingestion) | `loanrag-ingestion/.../infrastructure/chunking/layout_chunker.py` | `LayoutChunker.chunk()` |
| Drop bad chunks | `loanrag-ingestion/.../infrastructure/chunking/null_guard.py` | `NullGuard` |
| Write chunks to store | `loanrag-ingestion/.../application/ingestion_service.py` | writes `loan-chunks/<app>/<doc>.json` |
| Read chunks (decision) | `loanrag-loan-decision/.../retrieval/chunk_store.py` | `ChunkStore.load()` |
| Storage adapter | `.../retrieval/blob_reader.py` | local / azure_blob / gcs |
| Use chunks | `.../workflow/nodes.py` | `load_documents`, `extract_facts`, `retrieve_evidence` |

## 2. How LoanRAG chunks: layout/block-based, NO overlap

`LayoutChunker` produces **one chunk per logical block** (a paragraph, a table, a
figure) — not fixed-size character windows. Each `chunk_id` is deterministic
(`{document_id}:{block_id}`), so re-ingesting the same file yields identical ids
(idempotency). This choice is deliberate: a lending fact like a table row must
stay intact in one chunk for exact corroboration to work.

## 3. Overlap scenarios in real time — with examples

Chunk **overlap** means consecutive chunks share some text at their boundary
(e.g. each 1000-character chunk repeats the last 150 characters of the previous
one). It exists to stop a fact from being cut in half at a boundary. Below are the
real situations and what each strategy does to them.

### Scenario A — fixed-size windows, NO overlap (the classic failure)
Source line: `Total Monthly EMI (existing): 21,500`
A 1000-char window happens to end mid-line:
```
…chunk 1 ends: "... Total Monthly"
chunk 2 starts: "EMI (existing): 21,500 ..."
```
Now no single chunk contains `Total Monthly EMI (existing): 21,500`. A keyword/
vector search for “existing EMI” may rank neither chunk well, and an LLM asked to
“find the EMI” might **guess** 21,000 or 25,000. This is the boundary-loss problem.

### Scenario B — fixed-size windows WITH overlap (the usual fix)
Same source, 1000-char windows with **150-char overlap**:
```
chunk 1 ends:  "... Total Monthly EMI (existing): 21,500"
chunk 2 starts:"...EMI (existing): 21,500. Next section ..."
```
The fact now appears whole in at least one chunk. Cost: the overlapping text is
duplicated (more storage, more tokens if an LLM reads it, possible double-counting
in retrieval). Typical real-world overlap is **10–20%** of the chunk size, or a
1–2 sentence overlap.

### Scenario C — tables (where fixed windows really hurt)
A financials table:
```
Obligation        | Monthly EMI | Outstanding
HDFC Home Loan     | 18,000      | 12,00,000
Demo Card          |  3,500      |    42,000
Total                21,500
```
A fixed window can slice this between rows, so a chunk reads `Demo Card | 3,500`
without its header — meaningless on its own, and a magnet for hallucinated totals.
**LoanRAG avoids this entirely**: the table is one block → one chunk, header +
rows + total together. That is why the sample’s `existing_emi_total = 21,500`
corroborates against the financials chunk.

### Scenario D — sentence/semantic chunking (the middle ground)
Split on sentence or heading boundaries, optionally with a 1-sentence overlap.
Keeps prose facts (“net salary credited ₹78,500”) intact without duplicating
whole windows. Good default for narrative documents (underwriter notes, emails).

### Practical guidance
- Narrative text → sentence/semantic split, ~1 sentence (or 10–20%) overlap.
- Tables / forms / key-value docs → **layout/block** chunking, **no** overlap
  (LoanRAG’s choice) so a row/total is never split.
- If you must use fixed windows, always add overlap, and never let a window break
  a table or a labelled number.

## 4. How chunking connects to hallucination

A bad chunk boundary is one of the most common *causes* of hallucination in a
naive RAG: the fact gets split, retrieval misses it, and the LLM fills the gap
with a plausible-but-wrong number. LoanRAG defends against this at four points —
so even a poor boundary can’t produce a fabricated decision:

1. **Layout chunking** keeps each fact whole (`layout_chunker.py`).
2. **Exact-match corroboration** — the decision number must appear *exactly* in a
   chunk; no fuzzy match (`facts/exact_fact_extractor.py`). A split/garbled value
   simply isn’t found.
3. **Abstention** — an uncorroborated fact makes the policy REFER, never guess
   (`grounding/grounded_decision.py`).
4. **Deterministic decision** — the recommendation is computed by fixed rules over
   corroborated numbers, not generated text. There is nothing to hallucinate.

So the worst a bad chunk boundary can do here is push a loan to “refer to a
human”, not produce a confident wrong answer.

## 5. Which LLM model do we use? (honest answer)

**None — there is no LLM in the live code path, and no embedding model either.**

- The **decision** is fully deterministic (no model generates it).
- The **retriever** is **lexical** (term-overlap), `retrieval/retriever.py` — not
  vector embeddings.
- `LlmSettings` in `config/settings.py` is scaffolding for an **optional**,
  paraphrase-only rationale, defaulting to `backend="none"`. No `openai` / Vertex
  client is called anywhere in the code today. If you enable it, it would call
  Azure OpenAI (the provisioning script suggests a `gpt-4o-mini` deployment) or
  Vertex AI Gemini, and it would be constrained to reword already-cited facts — it
  still cannot introduce a new number. Production semantic retrieval (Azure AI
  Search / Vertex) is the documented swap behind the same `retrieve()` interface.

This is a feature, not a gap: for an auditable lending decision, “no model decides
and no model invents facts” is the safest design.

## 6. Distributed chunks & “no data is lost”

LoanRAG does **not** implement its own distributed sharding/replication — it
relies on durable object storage plus a few safety mechanisms:

- **Durable store:** chunks live in Azure Blob / GCS (cloud-replicated: LRS/GRS,
  GCS standard) or the local folder. Durability is the store’s guarantee.
- **Idempotent writes:** deterministic `chunk_id`s + a SHA-256 check in the
  **ingestion ledger** mean re-running ingestion never duplicates or corrupts —
  an already-ingested file with the same hash is skipped
  (`application/ingestion_service.py`).
- **All-or-nothing quality gate:** if a document’s chunks don’t pass the quality
  bar, the document is parked for human review and **nothing partial** is written
  to `loan-chunks`.
- **Stateless readers:** the decision service holds no chunk state; it always
  reads from the durable store, so any node/pod can serve any application.
- **Durable in-flight state:** the LangGraph **checkpointer** (Postgres in prod)
  persists workflow progress, so a crash mid-decision resumes exactly where it
  paused — including a loan waiting at human review.

If you genuinely need cross-region replication or multi-writer guarantees beyond
the object store, that’s a storage-tier configuration (e.g. Azure GRS, GCS
dual-region), not application code.
