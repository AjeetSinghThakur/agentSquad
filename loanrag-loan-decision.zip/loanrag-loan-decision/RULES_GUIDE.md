# RULES_GUIDE — the complete rule set for Indian retail lending

This explains every rule category in `config/rules.yaml`: what it is, the India /
RBI context, whether the engine **enforces it today** or it's **ready to enforce**,
and — importantly — **what you change when the real client database arrives** (the
answer is: very little, and almost never in the decision logic).

> The thresholds in `rules.yaml` are **illustrative defaults, not regulatory
> truth.** Final values must come from the lender's Board-approved Credit Policy
> and the applicable RBI Master Directions. This file is the machine-readable home
> for that policy; Credit + Compliance sign off the numbers.

## The rule categories

| # | Section in rules.yaml | What it controls | Status today |
|---|---|---|---|
| 1 | `loan_products` | products (personal/home/auto/LAP), amount & tenure ranges, per-product FOIR cap, secured flag | Ready |
| 2 | `eligibility` | age, residency, employment type, min income (by employment & city tier), job/business vintage | **Age enforced**; rest ready |
| 3 | `affordability` | FOIR basis (net/gross), what counts as an obligation, min surplus income | FOIR **enforced** (via `policy`); rest ready |
| 4 | `credit_rules` | bureau, min score, DPD limits, enquiries, history length, settlement/write-off, score→grade bands | min score **enforced**; rest ready |
| 5 | `collateral_ltv` | LTV slabs (home/auto/LAP), property types, valuation, stamp-duty exclusion, insurance | Ready (needs collateral data) |
| 6 | `kyc_compliance` | PAN/Aadhaar/CKYC, AML/PEP/sanctions, dedupe, KFS, cooling-off, consent | Ready (onboarding) |
| 7 | `required_documents` / `per_product_documents` | what must be ingested before a decision | **Enforced** (completeness gate) |
| 8 | `pricing_charges` | repo-linked/fixed rate, spread by grade, processing fee, penal/prepayment/foreclosure | Ready (sanction/pricing) |
| 9 | `risk_grading` | auto-approve/refer/reject grades, manual-review (HITL) triggers, exposure caps | Ready |
| 10 | `fraud_negative` | negative lists, blacklisted pincodes, employer blocklist, max active loans, defaulter lists | Ready |
| 11 | `fact_sources` | which documents corroborate each fact by exact match | **Enforced** |
| 12 | `criteria` | retrieval queries + expected docs (drive recall / false-positive) | **Enforced** |
| 13 | `policy` | the deterministic decision thresholds (FOIR, credit, income) | **Enforced** |
| 14 | `retry` | per-node auto-retry before HITL escalation | **Enforced** |

"Ready" = validated, typed, and loaded — the engine can read it; wiring each into
the decision is an incremental, additive change (the age rule below is a worked
example of how small that is).

## India / RBI context behind the key numbers

- **FOIR (Fixed Obligation to Income Ratio)** is India's name for debt-to-income;
  it measures the share of income already committed to fixed obligations. It is used predominantly in India, whereas DTI is more common internationally. Common practice treats roughly 40% as comfortable and most Indian lenders treat 55% as an upper limit, with NBFCs sometimes going to 60%. That maps to the `policy` auto-approve (0.45) / acceptable (0.55) bands.
- **Home-loan LTV** is tiered by loan size: up to 90% for properties up to ₹30 lakh, up to 80% for ₹30–75 lakh, and capped at 75% above ₹75 lakh. These are the `collateral_ltv.home_loan_ltv_slabs`. Note also that stamp duty and registration costs are excluded from the LTV calculation except for properties below ₹10 lakh.
- **Key Facts Statement (KFS):** all new retail and MSME term loans sanctioned on or after 1 October 2024 must comply with the KFS guidelines, which standardise disclosure of APR, charges, and grievance redress — captured by `kyc_compliance.kfs_required`.
- **Cooling-off / look-up period:** for digital loans the cooling-off period is set by the lender's Board and must not be less than one day — `kyc_compliance.cooling_off_days`.
- **Prepayment/foreclosure:** prepayment charges are prohibited on floating-rate loans to individuals for non-business purposes from January 2026 — reflected by `pricing_charges.prepayment_charge_floating_individual: 0`.
- **Credit data freshness:** since January 2025, lenders must update credit information with the bureaus every 15 days instead of monthly, which is why the system queries the bureau/system-of-record live rather than trusting embedded copies.

## When the real client database arrives — what you change

The design goal was "minimum changes." Here's the whole list:

1. **Point at the real DB.** Set `LOANRAG__DB__AUTHORITATIVE_DB_PATH` (or swap the
   query implementation in `facts/authoritative_facts.py` to your Azure SQL / core
   banking call). The `fetch()` method's *shape* stays the same.
2. **Populate the fields the rules need.** Today `AuthoritativeFacts` carries
   income, obligations, credit score, and DOB (age). To enforce more rules, add the
   corresponding fields to that one dataclass + query (e.g. `employment_type`,
   `employment_months`, `loan_amount`, `loan_type`, `collateral_value`, `city_tier`,
   `active_unsecured_loans`). Each is a column read — not a logic change.
3. **Flip rules on as data lands.** Each "Ready" rule becomes "Enforced" by adding
   a short gate in `grounding/grounded_decision.py`, exactly like the age gate.

### Worked example: the age rule (already done)

Age eligibility shows how small a "flip on" is end-to-end:
- `rules.yaml → eligibility.min_age/max_age` (the rule),
- `facts/authoritative_facts.py` computes `age` from the DOB already in the DB,
- `grounding/grounded_decision.py` adds a 3-line gate that REJECTs out-of-range age,
- threaded through `workflow/state.py` + `workflow/nodes.py`.

Verified: age 19 → REJECT, 36 → APPROVE, 67 → REJECT. The same pattern enables the
LTV check (needs `loan_amount` + `collateral_value`), the employment/income-by-type
check (needs `employment_type`), and so on — each a few lines, no rewrite.

## What is NOT in scope here (and shouldn't be)

This package decides **approve / reject / refer**. It does not *originate* the loan
(KYC capture, e-sign, KFS generation, disbursal, repayment) — those are separate
services. The `kyc_compliance` / `pricing_charges` sections are here so the decision
can *require/record* that those steps happened or will happen, and so the policy is
complete and auditable in one place; the actual onboarding/servicing is upstream and
downstream of this stage.
