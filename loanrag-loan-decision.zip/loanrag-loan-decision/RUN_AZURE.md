# RUN — Azure

End-to-end on Azure: create resources, ingestion **writes chunks to Azure Blob**,
the decision **reads them back from Azure Blob**, and the API/consumer run on AKS.

## Services used (Azure)

| Service | Role |
|---|---|
| **Azure Blob Storage** | the shared `loan-docs` / `loan-chunks` store |
| **Azure Document Intelligence** | OCR for scanned PDFs (ingestion) |
| **Azure SQL Database** | authoritative facts (live) |
| **Azure Database for PostgreSQL** | LangGraph checkpointer (durable HITL) |
| **Azure AI Search** | evidence retrieval (recommended) |
| **Azure OpenAI** | optional grounded rationale |
| **Azure Container Registry** | image hosting |
| **Azure Kubernetes Service (AKS)** | runs the API + consumer; HPA scaling |
| **RabbitMQ** | event bus — run `rabbitmq:3-management` on AKS (or use Azure Service Bus) |
| **Key Vault / Azure Monitor** | secrets / observability |

## Steps

**1. Create the resources:**
```powershell
az login
./deploy/scripts/provision-azure.ps1 -Prefix loanrag -Location centralindia `
   -SqlAdminPassword 'Str0ng#Pass!' -PgAdminPassword 'Str0ng#Pass!'
```
It prints the exact `LOANRAG__BLOB__*`, Postgres, SQL, Search settings.

**2. Point at Azure and INGEST (writes chunks to Azure Blob):**
```bash
export LOANRAG__BLOB__CONNECTION_STRING="<from the script output>"
# in loanrag-ingestion/
./deploy/scripts/run-ingestion.sh azure
#   -> writes loan-docs/ and loan-chunks/<application_id>/*.json into Azure Blob
```
(Windows: `./deploy/scripts/run-ingestion.ps1 -Target azure`)

**3. Run the DECISION reading from Azure Blob:**
```bash
export LOANRAG__BLOB__CONNECTION_STRING="<same connection string>"
# in loanrag-loan-decision/
./deploy/scripts/run-decision.sh azure LOAN-2026-000123
#   bash;  Windows: ./deploy/scripts/run-decision.ps1 -Target azure -App LOAN-2026-000123
```
For production also set the Postgres checkpointer + Azure SQL facts:
```bash
export LOANRAG__CHECKPOINTER__BACKEND=postgres
export LOANRAG__CHECKPOINTER__POSTGRES_CONN="<from the script output>"
```

**4. Deploy the API + consumer to AKS (with HPA):**
```bash
az aks get-credentials -g loanrag-rg -n loanrag-aks
kubectl apply -f deploy/k8s/00-namespace.yaml
kubectl create configmap loanrag-rules --from-file=rules.yaml=config/rules.yaml -n loanrag \
  -o yaml --dry-run=client | kubectl apply -f -
sed "s|__IMAGE__|<acr>.azurecr.io/loanrag-decision:1.0|g" deploy/k8s/30-deployment.yaml | kubectl apply -f -
kubectl apply -f deploy/k8s/40-service.yaml -f deploy/k8s/50-hpa.yaml
```
Or let the pipeline do build → push → deploy: `deploy/pipelines/azure-pipelines.yml`.

**5. Review** via the reviewer console (the API's `GET /`, exposed through your
AKS ingress), or the CLI `resume`.

See **AZURE_DEPLOY.md** for the full service-by-service detail and **MULTI_CLOUD.md**
for how the chunks are written/copied.
