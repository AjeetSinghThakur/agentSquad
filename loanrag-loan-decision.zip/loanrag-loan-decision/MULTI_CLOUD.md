# Running LoanRAG in Local, Azure, or GCP

![Multi-cloud architecture](docs/diagrams/multicloud_architecture.png)

## The one idea

Both stages talk to storage through one small interface (`IBlobStore` /
blob-reader). Which storage they use is **one setting** —
`LOANRAG__BLOB__BACKEND` = `localfs` | `azure_blob` | `gcs`. The code is identical
in all three; the destination is decided by configuration and credentials, not by
code changes.

| Target | BACKEND | Where chunks land | What you also set |
|---|---|---|---|
| Local | `localfs` | `./_localblob/loan-chunks/...` | `LOANRAG__BLOB__LOCALFS_ROOT` |
| Azure | `azure_blob` | Azure Blob container `loan-chunks` | `LOANRAG__BLOB__CONNECTION_STRING` |
| GCP | `gcs` | `gs://<bucket>/loan-chunks/...` | `LOANRAG__BLOB__GCS_BUCKET` |

## How chunks (and related files) get "copied" to the chosen environment

There is **no separate copy step** — ingestion *writes directly* to whichever
store the backend points at. For every document it writes a chunk file:

```
loan-chunks/<application_id>/<application_id>__<document>.json
```

The raw originals go to `loan-docs/` the same way. This layout is **identical**
in local, Azure, and GCP, which is the whole point: the decision stage reads the
exact same paths regardless of cloud. So:

- **To put chunks in Azure:** run ingestion with `BACKEND=azure_blob` — it writes
  straight to the Azure container. Nothing to copy.
- **To put chunks in GCP:** run ingestion with `BACKEND=gcs` — it writes straight
  to the bucket.
- **To MOVE chunks that already exist** between environments (e.g. local → cloud),
  it's a plain object copy:
  - Azure: `azcopy copy ./_localblob/loan-chunks "https://<acct>.blob.core.windows.net/loan-chunks?<SAS>" --recursive`
  - GCP: `gcloud storage cp -r ./_localblob/loan-chunks gs://<bucket>/loan-chunks`

The decision stage doesn't care how the chunks got there — it just reads
`loan-chunks/<application_id>/*.json` from the backend it's pointed at.

## Test it in each environment

First create the cloud resources (one-time):
- Azure: `deploy/scripts/provision-azure.ps1`   ·   GCP: `deploy/scripts/provision-gcp.sh`
Both print the exact `LOANRAG__BLOB__*` values to export.

### Local (no cloud)
```bash
# ingestion (in loanrag-ingestion/)
./deploy/scripts/run-ingestion.sh local
# decision (in loanrag-loan-decision/)
./deploy/scripts/run-decision.sh local
```

### Azure
```bash
export LOANRAG__BLOB__CONNECTION_STRING="<your Azure Storage connection string>"
./deploy/scripts/run-ingestion.sh azure        # writes chunks to Azure Blob
./deploy/scripts/run-decision.sh   azure        # reads them back from Azure Blob
```
(Windows: `./deploy/scripts/run-ingestion.ps1 -Target azure`)

### GCP
```bash
gcloud auth application-default login
export LOANRAG__BLOB__GCS_BUCKET="<your-project>-loanrag-store"
./deploy/scripts/run-ingestion.sh gcp          # writes chunks to GCS
./deploy/scripts/run-decision.sh   gcp          # reads them back from GCS
```
(Windows: `./deploy/scripts/run-ingestion.ps1 -Target gcp`)

In every case you should see ingestion write 7–9 chunk files and the decision
print a recommendation (REFER 54% for the sample), proving the **same chunks**
were written and read in that environment.

## What changes per environment (and what doesn't)

- **Doesn't change:** all the Python logic, the chunk layout, the rules, the
  decision, the HITL flow.
- **Changes (config only):** the backend value + its credentials/bucket. For the
  authoritative facts DB and the checkpointer you make the equivalent swaps
  (Azure SQL / Cloud SQL, Azure DB for PostgreSQL / Cloud SQL for PostgreSQL) —
  see AZURE_DEPLOY.md and GCP_DEPLOY.md.
