# Runtime & Human-in-the-loop — how it runs automatically and where a human reviews

This answers four things before you read the code: where the ingested documents
are read, where the loan type comes from, how the system runs automatically, and
what the human review actually looks like.

## 1. Where the ingested documents (chunks) are read — the exact path

```
RabbitMQ event ─► api.py POST /assess ─► graph ─► nodes.load_documents / extract_facts / retrieve_evidence
                                                            │
                                                            ▼
                                            retrieval/chunk_store.py  ChunkStore.load()
                                                            │
                                                            ▼
                                            retrieval/blob_reader.py  LocalFsBlobReader / AzureBlobReader
                                                            │
                                                            ▼
                                       blob: loan-chunks/<application_id>/*.json  (written by ingestion)
```

- **`loan_rag/retrieval/chunk_store.py` → `ChunkStore.load(application_id)`** is the
  single place that reads the ingested chunks back into `Chunk` objects.
- It uses **`loan_rag/retrieval/blob_reader.py`** (`list_keys` + `get`) — `localfs`
  locally, `azure_blob`/`gcs` in the cloud.
- The nodes that call it: `workflow/nodes.py` → `load_documents` (which files are
  present), `extract_facts` (corroborate facts against the text), `retrieve_evidence`
  (search the text). Start reading there.

## 2. Where the loan type comes from (important)

The ingested chunks do **not** carry a structured loan type — a chunk is
`{chunk_id, text, source_kind, page, extra, …}`, and the authoritative DB's
`applicant` table is only `application_id, name, pan, dob`. Parsing the product
out of free OCR text would be unreliable.

So **loan type is application metadata**, owned by the loan origination system,
and it travels on the **RabbitMQ event**:

```json
{ "application_id": "LOAN-2026-000123", "loan_type": "PERSONAL", "proposed_new_emi": 21000.0 }
```

It then flows: event → `api.py /assess` → `state["loan_type"]` → used in:
- **`nodes.completeness_gate`** — uses `rules.per_product_documents[loan_type]` if
  defined (e.g. HOME/AUTO need extra docs), else the global `required_documents`.
- **`nodes.decide` + `grounding/grounded_decision.py`** — looks up
  `rules.loan_products[code == loan_type]` and applies that product's `foir_cap`
  as the acceptable-FOIR limit (e.g. AUTO is stricter at 0.50).

(If you prefer, you can instead store `loan_type` as a column on the application
record / authoritative DB and read it in `extract_facts` — same idea, different
source. The event is the cleaner default.)

## 3. How it runs automatically (RabbitMQ)

```
INGESTION finishes a loan's documents
        │  loan_rag/messaging/publisher.py  publish_ingested(app_id, loan_type, emi)
        ▼
RabbitMQ queue  "loan.ingested"   (durable)
        │
        ▼
loan_rag/messaging/consumer.py    (its own process; scale it horizontally)
        │  POST /assess {application_id, loan_type, proposed_new_emi}
        ▼
api.py runs the graph → decision OR pause for a human
```

- **Publisher** (`messaging/publisher.py`): the ingestion stage calls
  `publish_ingested(...)` once a loan's documents are ingested. That is the
  hand-off between the two stages.
- **Consumer** (`messaging/consumer.py`): a standalone worker that consumes the
  queue and calls the decision API. Run it with `python -m loan_rag.messaging.consumer`.
  It acks on success and re-queues on transient failure, and you can run many
  copies for throughput.

Why a queue (not a direct call): loans arrive in bursts, ingestion and decision
scale independently, and a message is durable — nothing is lost if the decision
service is briefly down.

## 4. What the human review looks like

A human never touches LangGraph — they use a page that calls the API.

- **Reviewer console** — open **`GET /`** (served by `api.py`). It lists every
  loan currently paused, with the recommendation, risk grade, FOIR, the cited
  rationale and facts, and **Approve / Reject / Override** buttons. Each button
  calls **`POST /resume`** with `{decision: ...}`. System-error pauses show
  **Retry / Abort** buttons instead (calling `/resume` with `{action: ...}`).
- **The queue** behind it is **`GET /pending`** — the loans paused at
  `human_review` (decisions) or `error_review` (system errors).
- **Production note:** the demo's `/pending` scans the checkpointer, which is fine
  at modest volume. At scale, write a row to a dedicated *pending-reviews* table
  (or emit a `loan.review` message) when a loan pauses, and have the console read
  that — don't scan checkpoints. The buttons / `/resume` contract stay identical.

## 5. Run the whole loop locally

```bash
docker compose up --build          # starts rabbitmq + api + consumer
# in another shell, publish an event as ingestion would:
python -c "from loan_rag.messaging.publisher import publish_ingested; \
           publish_ingested('LOAN-2026-000123','PERSONAL',21000)"
# the consumer picks it up and calls /assess; now review it:
open http://localhost:8080/        # click Approve / Reject
```

No Docker? Run the API directly (`uvicorn loan_rag.presentation.api:app --port 8080`),
`POST /assess`, then open `http://localhost:8080/`.
