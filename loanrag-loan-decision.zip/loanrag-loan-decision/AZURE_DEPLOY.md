# Deploying LoanRAG decision to Azure

The local code is written so the move to Azure is **configuration + adapter
swaps**, not a rewrite. Each seam is already an interface.

## 1. What changes (and where)

| Concern | Local | Azure | Where to change |
|---|---|---|---|
| Chunk store | Azurite / localfs | **Azure Blob Storage** | `LOANRAG__BLOB__*` (no code change) |
| Authoritative facts | sqlite file | **Azure SQL / PostgreSQL** | `authoritative_facts.py` (swap the driver) |
| Evidence retriever | lexical | **Azure AI Search** hybrid (vector + keyword) | add an adapter with the same `retrieve()` |
| Checkpointer (HITL) | SQLite | **Azure Database for PostgreSQL** | `LOANRAG__CHECKPOINTER__BACKEND=postgres` |
| Rationale LLM (optional) | none | **Azure OpenAI** | `LOANRAG__LLM__BACKEND=azure_openai` |
| Compute | CLI | **Azure Container Apps** (job + small API) | Dockerfile already provided |

## 2. Durable checkpointer on Azure (the key one for HITL)

A paused loan must survive restarts and scale-out, so use the Postgres
checkpointer backed by Azure Database for PostgreSQL:

```bash
pip install langgraph-checkpoint-postgres
```
```bash
export LOANRAG__CHECKPOINTER__BACKEND=postgres
export LOANRAG__CHECKPOINTER__POSTGRES_CONN="postgresql://user:pwd@your-pg.postgres.database.azure.com:5432/loanrag?sslmode=require"
```
`graph.py` already calls `PostgresSaver.from_conn_string(...)` and `.setup()`
when the backend is `postgres`.

## 3. Blob + DB

```bash
export LOANRAG__BLOB__BACKEND=azure_blob          # works for real Azure Blob too
export LOANRAG__BLOB__CONNECTION_STRING="<your Azure Storage connection string>"
export LOANRAG__BLOB__CHUNKS_CONTAINER=loan-chunks
export LOANRAG__DB__AUTHORITATIVE_DB_PATH="<or swap authoritative_facts.py to Azure SQL>"
```
The same `loan-chunks` container the ingestion stage writes to is what this
stage reads — one shared store across both stages.

## 4. Azure AI Search retriever (lowers false-positive rate)

Add `loan_rag/retrieval/azure_search_retriever.py` exposing the same
`retrieve(query, top_k) -> list[Chunk]` as `LexicalRetriever`, backed by a hybrid
(vector + keyword) query against your index. Swap it in `nodes.retrieve_evidence`.
Nothing else changes — the recall/false-positive metrics work identically and
will show the improvement.

## 5. Hosting

- Build the image with the provided `Dockerfile`.
- Run the assessment as an **Azure Container Apps Job** (event/queue triggered),
  and expose `resume` via a small **FastAPI** app (a one-click reviewer UI calls
  it) — Container Apps with `min-replicas: 0` keeps idle cost near zero while a
  loan is paused waiting for a human.
- Put secrets (DB, storage, Azure OpenAI) in **Key Vault**; reference them as
  app settings rather than literals.

## 6. Containers, Kubernetes & autoscaling (AKS + HPA)

The decision API (`loan_rag/presentation/api.py`, served by uvicorn) is the
long-running workload. Kubernetes manifests are in `deploy/k8s/`:
Deployment (with CPU/memory **requests**, required for HPA), Service, a rules
**ConfigMap**, a Secret template, and an **HPA** (`50-hpa.yaml`) that scales 2→10
pods on CPU 65% / memory 75%. Deploy with `kubectl apply -f deploy/k8s/` after
substituting the image. The CI/CD pipeline below automates it.

## 7. CI/CD (Azure DevOps → AKS *and* GKE)

`deploy/pipelines/azure-pipelines.yml` builds one image, pushes it to **both**
ACR and GCP Artifact Registry, and deploys to **both** AKS and GKE with the HPA
applied. See GCP_DEPLOY.md for the Google Cloud side.
