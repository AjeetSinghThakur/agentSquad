"""Assembles the LangGraph workflow and compiles it with a durable checkpointer.

THE GRAPH (edges encode the guarantees + the resilience path):

    START
      -> load_documents ----(I/O error)----> error_review (HITL: retry | abort)
      -> completeness_gate
           |- (incomplete) -> incomplete -> END
           '- (complete)   -> extract_facts ----(I/O error)----> error_review
                              -> retrieve_evidence --(I/O error)-> error_review
                              -> decide
                              -> human_review        (HITL: approve | reject)
                              -> finalize -> END

    error_review --(human: retry)--> load_documents      (controlled recovery loop)
                 --(human: abort)--> finalize (FAILED)

Two safety layers on the I/O nodes:
  1. in-node `run_with_retry` auto-retries transient failures (backoff + jitter);
     on persistent failure the node sets state["error"] and we route to error_review.
  2. a LangGraph `RetryPolicy` is also attached as a framework-level safety net
     for any unexpected exception that escapes the node body.
"""

from __future__ import annotations

import logging
import sqlite3
from functools import partial
from pathlib import Path

from langgraph.graph import START, END, StateGraph
from langgraph.types import RetryPolicy

from loan_rag.config.rules import load_rules
from loan_rag.config.settings import Settings, get_settings
from loan_rag.facts.authoritative_facts import AuthoritativeFactsRepository
from loan_rag.grounding.grounded_decision import GroundedDecisionPolicy
from loan_rag.retrieval.chunk_store import ChunkStore
from loan_rag.workflow import nodes
from loan_rag.workflow.nodes import NodeContext
from loan_rag.workflow.state import LoanState

logger = logging.getLogger("loan_rag")


def _make_checkpointer(settings: Settings):
    """Create the checkpointer that persists graph state for HITL pause/resume."""
    if settings.checkpointer.backend == "postgres":
        from langgraph.checkpoint.postgres import PostgresSaver
        saver = PostgresSaver.from_conn_string(settings.checkpointer.postgres_conn)
        saver.setup()
        return saver
    from langgraph.checkpoint.sqlite import SqliteSaver
    Path(settings.checkpointer.sqlite_path).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(settings.checkpointer.sqlite_path, check_same_thread=False)
    return SqliteSaver(conn)


def build_context(settings: Settings) -> NodeContext:
    """Composition root: load rules + assemble the services the nodes depend on."""
    rules = load_rules(settings.rules_path)
    return NodeContext(
        settings=settings,
        chunk_store=ChunkStore(settings),
        facts_repo=AuthoritativeFactsRepository(settings.db.authoritative_db_path),
        policy=GroundedDecisionPolicy(rules),
        rules=rules,
        retry=rules.retry,
        logger=logger)


def _io_or_error(next_node: str):
    """Router for an I/O node: go to error_review if it failed, else to next_node."""
    return lambda state: "error" if state.get("error") else "ok", \
        {"error": "error_review", "ok": next_node}


def build_app(settings: Settings | None = None):
    """Build, wire, and compile the loan-decision graph."""
    settings = settings or get_settings()
    ctx = build_context(settings)
    # Framework-level safety net for unexpected exceptions on I/O nodes.
    io_retry = RetryPolicy(max_attempts=ctx.rules.retry.retry_policy_attempts)

    g = StateGraph(LoanState)
    g.add_node("load_documents", partial(nodes.load_documents, ctx=ctx), retry_policy=io_retry)
    g.add_node("completeness_gate", partial(nodes.completeness_gate, ctx=ctx))
    g.add_node("incomplete", partial(nodes.incomplete, ctx=ctx))
    g.add_node("extract_facts", partial(nodes.extract_facts, ctx=ctx), retry_policy=io_retry)
    g.add_node("retrieve_evidence", partial(nodes.retrieve_evidence, ctx=ctx), retry_policy=io_retry)
    g.add_node("decide", partial(nodes.decide, ctx=ctx))
    g.add_node("human_review", partial(nodes.human_review, ctx=ctx))
    g.add_node("error_review", partial(nodes.error_review, ctx=ctx))
    g.add_node("finalize", partial(nodes.finalize, ctx=ctx))

    g.add_edge(START, "load_documents")

    # After each I/O node: continue, or divert to error_review if it couldn't recover.
    cond, mapping = _io_or_error("completeness_gate")
    g.add_conditional_edges("load_documents", cond, mapping)

    g.add_conditional_edges(
        "completeness_gate",
        lambda state: "complete" if state.get("completeness_ok") else "incomplete",
        {"complete": "extract_facts", "incomplete": "incomplete"})
    g.add_edge("incomplete", END)

    cond, mapping = _io_or_error("retrieve_evidence")
    g.add_conditional_edges("extract_facts", cond, mapping)
    cond, mapping = _io_or_error("decide")
    g.add_conditional_edges("retrieve_evidence", cond, mapping)

    g.add_edge("decide", "human_review")
    g.add_edge("human_review", "finalize")

    # error_review (HITL): human chooses retry (loop back) or abort (finalize FAILED).
    g.add_conditional_edges(
        "error_review",
        lambda state: state.get("error_action", "abort"),
        {"retry": "load_documents", "abort": "finalize"})

    g.add_edge("finalize", END)

    return g.compile(checkpointer=_make_checkpointer(settings))
