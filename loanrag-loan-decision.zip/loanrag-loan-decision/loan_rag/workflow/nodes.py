"""The graph's nodes — one function per step of the assessment.

Each node receives the current LoanState plus a NodeContext (the assembled
services + the loaded business rules) and returns a partial state update. The
ORDER and the edges (defined in graph.py) are what guarantee a loan only reaches
a decision after every required document has been read.

RESILIENCE: the three I/O nodes (load_documents, extract_facts,
retrieve_evidence) run their reads through `run_with_retry`, which auto-retries
transient failures with exponential backoff. If a read still cannot succeed, the
node records the failure in `state["error"]` and the graph routes to the
`error_review` HITL node — a human is asked to look instead of the run crashing.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

from langgraph.types import interrupt

from loan_rag.config.rules import RetryRules, Rules
from loan_rag.config.settings import Settings
from loan_rag.domain.chunk import Chunk
from loan_rag.domain.enums import FactStatus
from loan_rag.domain.evidence import Evidence
from loan_rag.domain.fact import Fact
from loan_rag.facts.authoritative_facts import AuthoritativeFactsRepository
from loan_rag.facts.exact_fact_extractor import ExactFactCorroborator
from loan_rag.grounding.grounded_decision import GroundedDecisionPolicy
from loan_rag.metrics.recall_false_positive import compute_metrics
from loan_rag.retrieval.chunk_store import ChunkStore
from loan_rag.retrieval.retriever import LexicalRetriever
from loan_rag.workflow.resilience import PersistentError, run_with_retry
from loan_rag.workflow.state import LoanState


@dataclass
class NodeContext:
    """Holds the services + rules the nodes use, plus a per-application chunk cache."""

    settings: Settings
    chunk_store: ChunkStore
    facts_repo: AuthoritativeFactsRepository
    policy: GroundedDecisionPolicy
    rules: Rules
    retry: RetryRules
    logger: logging.Logger
    _cache: dict[str, list[Chunk]] = field(default_factory=dict)

    def load_chunks(self, application_id: str) -> list[Chunk]:
        """Load (and cache) the ingested chunks for an application, with auto-retry."""
        if application_id not in self._cache:
            self._cache[application_id] = run_with_retry(
                lambda: self.chunk_store.load(application_id),
                label="load_chunks", max_attempts=self.retry.max_attempts,
                base_delay=self.retry.base_delay_seconds,
                max_delay=self.retry.max_delay_seconds)
        return self._cache[application_id]


def _error(ctx: NodeContext, node: str, exc: Exception) -> dict:
    """Build the state update that escalates a persistent failure to a human."""
    ctx.logger.error("Node '%s' could not recover: %s", node, exc)
    return {"error": {"node": node, "message": str(exc)}}


# --------------------------------------------------------------------------- #
def load_documents(state: LoanState, ctx: NodeContext) -> dict:
    """Read which documents were ingested for this application (auto-retry)."""
    app = state["application_id"]
    try:
        present = sorted({c.filename for c in ctx.load_chunks(app)})
    except PersistentError as exc:
        return _error(ctx, "load_documents", exc)
    ctx.logger.info("load_documents: %d documents present for %s", len(present), app)
    return {"documents_present": present, "error": {}}


def completeness_gate(state: LoanState, ctx: NodeContext) -> dict:
    """Check EVERY required document is present before any decision is possible.

    Required documents come from rules.yaml (ctx.rules.required_documents), so the
    list can be changed without touching code. This gate is the only path to a
    decision, so a loan cannot be approved with a missing document.
    """
    loan_type = state.get("loan_type", "")
    # Per-product document list overrides the global one when configured.
    required = ctx.rules.per_product_documents.get(loan_type) or ctx.rules.required_documents
    present = set(state.get("documents_present", []))
    missing = [d for d in required if d not in present]
    return {"missing_documents": missing, "completeness_ok": not missing}


def incomplete(state: LoanState, ctx: NodeContext) -> dict:
    """Terminal-ish node when documents are missing: refer, never auto-decide."""
    missing = state.get("missing_documents", [])
    return {
        "recommendation": "refer", "abstained": True,
        "abstain_reasons": [f"required documents not yet ingested: {missing}"],
        "rationale": [f"Cannot assess: missing required documents {missing}. "
                      f"Approval is blocked until all documents are read."],
        "status": "BLOCKED: incomplete documents",
    }


def extract_facts(state: LoanState, ctx: NodeContext) -> dict:
    """Read authoritative facts LIVE, then corroborate each by EXACT match (auto-retry).

    Which documents may corroborate each fact comes from rules.yaml
    (ctx.rules.fact_sources), so that mapping is configuration, not code.
    """
    app = state["application_id"]
    src = ctx.rules.fact_sources
    try:
        auth = run_with_retry(
            lambda: ctx.facts_repo.fetch(app), label="fetch_authoritative_facts",
            max_attempts=ctx.retry.max_attempts, base_delay=ctx.retry.base_delay_seconds,
            max_delay=ctx.retry.max_delay_seconds)
        chunks = ctx.load_chunks(app)
    except PersistentError as exc:
        return _error(ctx, "extract_facts", exc)

    corro = ExactFactCorroborator(chunks)
    net = corro.corroborate("monthly_net", auth.monthly_net,
                            "authoritative_db: income.monthly_net",
                            preferred_documents=src.get("monthly_net"))
    credit = corro.corroborate("credit_score", auth.credit_score,
                               "authoritative_db: credit_bureau.score",
                               preferred_documents=src.get("credit_score"))
    emi = corro.corroborate("existing_emi_total", auth.existing_emi_total,
                            "authoritative_db: sum(obligations.monthly_emi)",
                            preferred_documents=src.get("existing_emi_total"))

    def as_dict(f: Fact) -> dict:
        return {"name": f.name, "value": f.value, "source": f.source,
                "status": f.status.value, "citation_chunk_id": f.citation_chunk_id,
                "rendered": f.rendered}

    return {"applicant_name": auth.applicant_name, "applicant_age": auth.age,
            "applicant_gross": auth.monthly_gross,
            "facts": [as_dict(net), as_dict(credit), as_dict(emi)], "error": {}}


def retrieve_evidence(state: LoanState, ctx: NodeContext) -> dict:
    """Retrieve supporting chunks per criterion and score recall / false-positive.

    Criteria + their expected documents come from rules.yaml (ctx.rules.criteria).
    """
    app = state["application_id"]
    try:
        chunks = ctx.load_chunks(app)
    except PersistentError as exc:
        return _error(ctx, "retrieve_evidence", exc)

    retriever = LexicalRetriever(chunks)
    top_k = ctx.settings.retrieval.top_k

    evidences: list[Evidence] = []
    summary: list[dict] = []
    for crit in ctx.rules.criteria:
        hits = retriever.retrieve(crit.query, top_k)
        got_docs = [h.filename for h in hits]
        evidences.append(Evidence(
            criterion=crit.name, query=crit.query,
            expected_documents=crit.expected_documents,
            retrieved_chunk_ids=[h.chunk_id for h in hits],
            retrieved_documents=got_docs))
        summary.append({"criterion": crit.name,
                        "expected": crit.expected_documents,
                        "retrieved_documents": got_docs})

    m = compute_metrics(evidences)
    return {"evidence": summary, "error": {},
            "metrics": {"recall": m.recall, "false_positive_rate": m.false_positive_rate,
                        "criteria_total": m.criteria_total,
                        "criteria_with_hit": m.criteria_with_hit,
                        "retrieved_total": m.retrieved_total,
                        "retrieved_off_target": m.retrieved_off_target}}


def decide(state: LoanState, ctx: NodeContext) -> dict:
    """Apply the deterministic, grounded policy (abstains if not fully grounded)."""
    facts = {f["name"]: f for f in state.get("facts", [])}

    def to_fact(d: dict) -> Fact:
        return Fact(name=d["name"], value=d["value"], source=d["source"],
                    status=FactStatus(d["status"]),
                    citation_chunk_id=d["citation_chunk_id"], rendered=d["rendered"])

    net = to_fact(facts["monthly_net"])
    credit = to_fact(facts["credit_score"])
    emi = to_fact(facts["existing_emi_total"])
    proposed = state.get("proposed_new_emi", ctx.rules.policy.proposed_new_emi_default)
    loan_type = state.get("loan_type", "")
    product = next((pr for pr in ctx.rules.loan_products if pr.code == loan_type), None)
    acc_cap = product.foir_cap if product else None

    result = ctx.policy.decide(state["application_id"], net, credit, emi, proposed,
                               applicant_age=state.get("applicant_age", 0),
                               gross_income=state.get("applicant_gross", 0.0),
                               loan_type=loan_type, acceptable_dti=acc_cap)
    ctx.logger.info("decide: %s (DTI=%.2f) for %s", result.recommendation.value,
                    result.dti or 0.0, state["application_id"])
    return {"recommendation": result.recommendation.value, "dti": result.dti,
            "risk_grade": result.risk_grade,
            "rationale": result.rationale, "abstained": result.abstained,
            "abstain_reasons": result.abstain_reasons}


def human_review(state: LoanState, ctx: NodeContext) -> dict:
    """HITL: pause and present the full package; resume with the human's decision."""
    payload = {
        "type": "decision",
        "application_id": state["application_id"],
        "loan_type": state.get("loan_type"),
        "applicant_name": state.get("applicant_name"),
        "recommendation": state.get("recommendation"),
        "risk_grade": state.get("risk_grade"),
        "dti": state.get("dti"),
        "completeness_ok": state.get("completeness_ok"),
        "abstained": state.get("abstained"),
        "rationale": state.get("rationale"),
        "metrics": state.get("metrics"),
        "facts": state.get("facts"),
        "instructions": "Resume with {'decision': 'approve'|'reject'|'override', 'note': '...'}",
    }
    decision = interrupt(payload)        # <-- PAUSE HERE until a human resumes
    if isinstance(decision, dict):
        return {"human_decision": decision.get("decision", ""),
                "human_note": decision.get("note", "")}
    return {"human_decision": str(decision)}


def error_review(state: LoanState, ctx: NodeContext) -> dict:
    """HITL escalation: a node could not recover after auto-retries.

    Pause and present the error to a human, who resumes with
    {'action': 'retry'} (re-run from the start of data loading) or
    {'action': 'abort'} (stop the run).
    """
    err = state.get("error", {})
    decision = interrupt({
        "type": "system_error",
        "application_id": state["application_id"],
        "failed_node": err.get("node"),
        "message": err.get("message"),
        "instructions": "Resume with {'action': 'retry'} or {'action': 'abort'}",
    })
    action = decision.get("action", "abort") if isinstance(decision, dict) else str(decision)
    if action == "retry":
        ctx.logger.info("error_review: human chose RETRY for %s", state["application_id"])
        return {"error": {}, "retry_from": "load_documents", "error_action": "retry"}
    ctx.logger.info("error_review: human chose ABORT for %s", state["application_id"])
    return {"error_aborted": True, "error_action": "abort",
            "status": f"FAILED: aborted by human after error in {err.get('node')}"}


def finalize(state: LoanState, ctx: NodeContext) -> dict:
    """Record the final outcome (the human decision wins over the recommendation)."""
    if state.get("error_aborted"):
        return {"status": state.get("status", "FAILED: aborted")}
    final = state.get("human_decision") or state.get("recommendation")
    return {"status": f"FINAL: {str(final).upper()}"}
