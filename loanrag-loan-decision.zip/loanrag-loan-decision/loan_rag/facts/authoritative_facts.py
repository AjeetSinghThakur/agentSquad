"""Live authoritative facts from the system-of-record database (ADR-003).

The numbers that drive the decision (income, obligations, credit score) are read
LIVE from the database here, NOT from embedded chunks. Cached/embedded copies go
stale and invite 'grounded but wrong' answers, so we always query at decision
time. Locally this is a sqlite file; in Azure it is a real DB connection.
"""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import date, datetime


def _age_from_dob(dob: str) -> int:
    """Compute age in whole years from a DOB string (DD-MM-YYYY or YYYY-MM-DD).

    Returns 0 if the date can't be parsed, so a missing/odd DOB simply skips the
    age check rather than crashing the decision.
    """
    for fmt in ("%d-%m-%Y", "%Y-%m-%d", "%d/%m/%Y"):
        try:
            born = datetime.strptime(dob, fmt).date()
            today = date.today()
            return today.year - born.year - ((today.month, today.day) < (born.month, born.day))
        except (ValueError, TypeError):
            continue
    return 0


@dataclass(frozen=True)
class AuthoritativeFacts:
    """The live facts needed to assess one application."""

    application_id: str
    applicant_name: str
    monthly_net: float
    monthly_gross: float
    existing_emi_total: float          # summed across ALL obligations
    credit_score: int
    dob: str = ""                      # date of birth as stored (e.g. 15-04-1990)
    age: int = 0                       # computed from dob (0 if unknown)


class AuthoritativeFactsRepository:
    """Reads authoritative facts for an application from the system of record."""

    def __init__(self, db_path: str) -> None:
        """Remember the database path/connection target."""
        self._db_path = db_path

    def fetch(self, application_id: str) -> AuthoritativeFacts:
        """Query income, obligations and credit score LIVE for the application."""
        conn = sqlite3.connect(self._db_path)
        conn.row_factory = sqlite3.Row
        try:
            app = conn.execute(
                "SELECT name, dob FROM applicant WHERE application_id=?", (application_id,)).fetchone()
            inc = conn.execute(
                "SELECT monthly_net, monthly_gross FROM income WHERE application_id=?",
                (application_id,)).fetchone()
            # Sum EVERY obligation (a single missed loan would understate DTI).
            emi = conn.execute(
                "SELECT COALESCE(SUM(monthly_emi),0) AS total FROM obligations WHERE application_id=?",
                (application_id,)).fetchone()
            cb = conn.execute(
                "SELECT score FROM credit_bureau WHERE application_id=?",
                (application_id,)).fetchone()
        finally:
            conn.close()

        dob = app["dob"] if app and "dob" in app.keys() else ""
        return AuthoritativeFacts(
            application_id=application_id,
            applicant_name=app["name"] if app else "(unknown)",
            monthly_net=float(inc["monthly_net"]) if inc else 0.0,
            monthly_gross=float(inc["monthly_gross"]) if inc else 0.0,
            existing_emi_total=float(emi["total"]) if emi else 0.0,
            credit_score=int(cb["score"]) if cb else 0,
            dob=dob or "",
            age=_age_from_dob(dob) if dob else 0)
