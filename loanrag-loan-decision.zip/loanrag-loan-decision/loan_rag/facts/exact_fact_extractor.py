"""Corroborates authoritative facts against ingested documents — EXACT match.

For each authoritative number we confirm the SAME value appears, exactly, in at
least one ingested document chunk (formatted the way documents render it, e.g.
78500 -> '78,500'). This is strictly exact: '78,400' does NOT corroborate
'78,500'. Fuzzy/approximate matching is deliberately NOT used, because for money
and scores 'close' is wrong and is exactly how a hallucinated decision creeps in.

A fact with no exact corroboration is marked UNCORROBORATED; the decision will
not rely on it (it abstains instead).
"""

from __future__ import annotations

from loan_rag.domain.chunk import Chunk
from loan_rag.domain.enums import FactStatus
from loan_rag.domain.fact import Fact


def _ind(n: float) -> str:
    """Render a whole number with Indian digit grouping (95000 -> '95,000')."""
    s = str(int(round(n)))
    if len(s) <= 3:
        return s
    head, tail = s[:-3], s[-3:]
    import re
    head = re.sub(r"(\d)(?=(\d\d)+$)", r"\1,", head)
    return f"{head},{tail}"


class ExactFactCorroborator:
    """Finds the document chunk (if any) that EXACTLY contains a fact's value."""

    def __init__(self, chunks: list[Chunk]) -> None:
        """Keep the chunks to scan for exact value strings."""
        self._chunks = chunks

    def corroborate(self, name: str, value: float, source: str,
                    preferred_documents: list[str] | None = None) -> Fact:
        """Return a Fact stamped CORROBORATED (with citation) or UNCORROBORATED.

        A value can legitimately appear in two EXACT textual forms: grouped
        ('21,500', as PDFs render it) or plain ('21500', as a spreadsheet cell
        stores it). We accept either exact form — this is NOT fuzzy matching;
        '21400' would still never match '21500'. We just don't penalise a value
        for the presence/absence of digit-group commas.
        """
        grouped = _ind(value)
        plain = str(int(round(value)))
        candidates = [grouped] if grouped == plain else [grouped, plain]
        preferred = preferred_documents or []

        def _match(restrict_to_preferred: bool):
            """Find the first chunk exactly containing any rendering of the value."""
            for c in self._chunks:
                if restrict_to_preferred and preferred and c.filename not in preferred:
                    continue
                hit = next((cand for cand in candidates if cand in c.text), None)
                if hit:
                    return c.chunk_id, hit
            return None, None

        # Prefer the document we expect this fact in; otherwise accept any doc.
        citation, rendered = _match(restrict_to_preferred=True)
        if citation is None:
            citation, rendered = _match(restrict_to_preferred=False)

        status = FactStatus.CORROBORATED if citation else FactStatus.UNCORROBORATED
        return Fact(name=name, value=value, source=source, status=status,
                    citation_chunk_id=citation, rendered=rendered or grouped)
