"""A retrievable chunk, as produced by the ingestion stage."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class Chunk:
    """One clean, citable unit of text read back from the `loan-chunks` store.

    This mirrors the JSON the ingestion pipeline wrote. We only keep the fields
    the decision workflow needs; everything here was already quality-gated during
    ingestion (no empty/low-confidence chunks reach this store).
    """

    chunk_id: str
    document_id: str
    text: str
    source_kind: str
    min_token_confidence: float
    inferred: bool
    page: int | None = None
    extra: dict = field(default_factory=dict)

    @property
    def filename(self) -> str:
        """The source filename, derived from the document id (after the '__')."""
        return self.document_id.split("__", 1)[-1]
