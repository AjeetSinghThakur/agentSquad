"""Evidence retrieved for a decision criterion."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class Evidence:
    """The chunks retrieved to support one criterion (e.g. 'credit score').

    `expected_documents` is the ground-truth set of documents that *should*
    supply this criterion; `retrieved_chunk_ids` is what the retriever actually
    returned. Together they let us compute recall and false-positive rate.
    """

    criterion: str
    query: str
    expected_documents: list[str]
    retrieved_chunk_ids: list[str] = field(default_factory=list)
    retrieved_documents: list[str] = field(default_factory=list)
