"""Aggregate retrieval-quality metrics for a loan assessment."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class RetrievalMetrics:
    """Recall and false-positive rate across all decision criteria.

    recall            = fraction of criteria for which at least one chunk from an
                        EXPECTED document was retrieved (did we find the evidence?)
    false_positive_rate = fraction of retrieved chunks that came from a document
                        NOT expected for that criterion (did we pull in noise?)
    """

    recall: float
    false_positive_rate: float
    criteria_total: int
    criteria_with_hit: int
    retrieved_total: int
    retrieved_off_target: int
