"""An authoritative fact used in the decision, with its provenance."""

from __future__ import annotations

from dataclasses import dataclass

from loan_rag.domain.enums import FactStatus


@dataclass(frozen=True)
class Fact:
    """A single decision input (e.g. monthly_net = 78500).

    `value` comes LIVE from the system-of-record database (never embedded — see
    ADR-003). `status` records whether that exact value was also found in an
    ingested document (exact match). `citation_chunk_id` is the document chunk
    that corroborates it, so every fact the decision uses is traceable.
    """

    name: str
    value: float
    source: str                       # e.g. "authoritative_db: income.monthly_net"
    status: FactStatus
    citation_chunk_id: str | None = None   # the document chunk that corroborates it
    rendered: str = ""                # how the value appears in documents (e.g. "78,500")
