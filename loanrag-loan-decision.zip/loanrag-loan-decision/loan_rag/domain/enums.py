"""Enumerations for the loan-decision workflow."""

from enum import Enum


class Decision(str, Enum):
    """The recommendation/outcome of a loan assessment.

    APPROVE / REJECT are clear outcomes; REFER means 'insufficient or borderline
    evidence — a human must decide'. REFER is how the system ABSTAINS instead of
    guessing, which is central to keeping the hallucination rate at zero.
    """

    APPROVE = "approve"
    REJECT = "reject"
    REFER = "refer"


class FactStatus(str, Enum):
    """Whether an authoritative fact is corroborated by a source document.

    CORROBORATED = the exact value also appears in an ingested document (exact
    match, no fuzzy). UNCORROBORATED = the DB has it but no document evidences it
    — such a fact is NOT trusted for an automated decision.
    """

    CORROBORATED = "corroborated"
    UNCORROBORATED = "uncorroborated"
