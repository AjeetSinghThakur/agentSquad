"""Loads and validates the business rules from rules.yaml into typed objects.

WHY a separate, validated rules file (not env vars, not hardcoded):
  - Infrastructure config (where the blob/DB live) belongs in environment vars.
  - BUSINESS rules (eligibility, affordability/FOIR, credit, LTV, KYC, pricing,
    risk grading, fraud checks) change for business/regulatory reasons and should
    be editable by a Credit/Compliance owner without touching Python. A validated
    YAML is the auditable home for them.

Every section is modelled with pydantic, so a bad edit fails fast at startup with
a clear error rather than misbehaving at decision time. Every field is concretely typed.
If the file is missing, defaults (matching the shipped rules.yaml) keep it running.
"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path

import yaml
from pydantic import BaseModel, Field


# --- small building blocks --------------------------------------------------- #
class Meta(BaseModel):
    policy_name: str = "Retail Lending Credit Policy (template)"
    version: str = "1.0"
    currency: str = "INR"
    regulator_note: str = ""


class LoanProduct(BaseModel):
    code: str
    name: str
    secured: bool = False
    min_amount: float = 0.0
    max_amount: float = 0.0
    min_tenure_months: int = 0
    max_tenure_months: int = 0
    foir_cap: float = 0.55


class Eligibility(BaseModel):
    min_age: int = 21
    max_age: int = 60
    max_age_at_maturity: int = 70
    allowed_residency: list[str] = Field(default_factory=lambda: ["RESIDENT_INDIAN"])
    allowed_employment_types: list[str] = Field(default_factory=list)
    min_net_income_by_employment: dict[str, float] = Field(default_factory=dict)
    min_employment_months: int = 6
    min_business_vintage_months: int = 24
    min_income_by_city_tier: dict[str, float] = Field(default_factory=dict)


class Affordability(BaseModel):
    foir_basis: str = "NET"                  # NET | GROSS
    include_rent_in_obligations: bool = True
    include_credit_card_min_due: bool = True
    min_surplus_income: float = 0.0
    emi_rounding_rupees: int = 1


class ScoreBand(BaseModel):
    min: int
    max: int
    grade: str


class CreditRules(BaseModel):
    bureau: str = "CIBIL"
    min_score: int = 700
    thin_file_action: str = "REFER"
    max_active_dpd_days: int = 0
    max_dpd_last_12m_days: int = 30
    max_enquiries_6m: int = 6
    min_credit_history_months: int = 12
    disallow_settlement_or_writeoff: bool = True
    score_bands: list[ScoreBand] = Field(default_factory=list)


class LtvSlab(BaseModel):
    up_to_amount: float
    max_ltv: float


class CollateralLtv(BaseModel):
    exclude_stamp_duty_registration: bool = True
    insurance_required: bool = True
    allowed_property_types: list[str] = Field(default_factory=list)
    valuation_source: str = "APPROVED_PANEL_VALUER"
    home_loan_ltv_slabs: list[LtvSlab] = Field(default_factory=list)
    auto_loan_max_ltv: float = 0.85
    lap_max_ltv: float = 0.65


class KycCompliance(BaseModel):
    pan_mandatory: bool = True
    aadhaar_or_ckyc_required: bool = True
    identity_proof_required: bool = True
    address_proof_required: bool = True
    aml_pep_sanctions_screening: bool = True
    dedupe_against_existing_customers: bool = True
    kfs_required: bool = True
    cooling_off_days: int = 3
    borrower_consent_required: bool = True


class PricingCharges(BaseModel):
    rate_model: str = "REPO_LINKED"
    benchmark_repo_rate: float = 0.0525
    spread_by_grade: dict[str, float] = Field(default_factory=dict)
    processing_fee_pct: float = 0.01
    max_processing_fee: float = 25000.0
    penal_charge_pct_per_month: float = 0.02
    prepayment_charge_floating_individual: float = 0.0
    foreclosure_allowed_after_months: int = 6


class RiskGrading(BaseModel):
    auto_approve_grades: list[str] = Field(default_factory=list)
    refer_grades: list[str] = Field(default_factory=list)
    reject_grades: list[str] = Field(default_factory=list)
    manual_review_triggers: list[str] = Field(default_factory=list)
    high_loan_amount_threshold: float = 5000000.0
    max_exposure_per_borrower: float = 10000000.0


class FraudNegative(BaseModel):
    negative_list_check: bool = True
    blacklisted_pincodes: list[str] = Field(default_factory=list)
    employer_category_blocklist: list[str] = Field(default_factory=list)
    max_active_unsecured_loans: int = 4
    reject_if_on_defaulter_list: bool = True


class Criterion(BaseModel):
    name: str
    query: str
    expected_documents: list[str] = Field(default_factory=list)


class PolicyRules(BaseModel):
    """Deterministic thresholds the engine applies TODAY (same field names it uses)."""

    max_dti_auto_approve: float = 0.45
    max_dti_acceptable: float = 0.55
    min_credit_score: int = 700
    min_monthly_net: float = 25000.0
    proposed_new_emi_default: float = 21000.0


class RetryRules(BaseModel):
    max_attempts: int = 4
    base_delay_seconds: float = 0.5
    max_delay_seconds: float = 8.0
    retry_policy_attempts: int = 3


# --- the complete rule set --------------------------------------------------- #
class Rules(BaseModel):
    """The complete, validated set of business rules (one source of truth)."""

    meta: Meta = Field(default_factory=Meta)
    loan_products: list[LoanProduct] = Field(default_factory=list)
    eligibility: Eligibility = Field(default_factory=Eligibility)
    affordability: Affordability = Field(default_factory=Affordability)
    credit_rules: CreditRules = Field(default_factory=CreditRules)
    collateral_ltv: CollateralLtv = Field(default_factory=CollateralLtv)
    kyc_compliance: KycCompliance = Field(default_factory=KycCompliance)
    required_documents: list[str] = Field(default_factory=list)
    per_product_documents: dict[str, list[str]] = Field(default_factory=dict)
    pricing_charges: PricingCharges = Field(default_factory=PricingCharges)
    risk_grading: RiskGrading = Field(default_factory=RiskGrading)
    fraud_negative: FraudNegative = Field(default_factory=FraudNegative)
    fact_sources: dict[str, list[str]] = Field(default_factory=dict)
    criteria: list[Criterion] = Field(default_factory=list)
    policy: PolicyRules = Field(default_factory=PolicyRules)
    retry: RetryRules = Field(default_factory=RetryRules)


@lru_cache
def load_rules(path: str) -> Rules:
    """Read and validate rules.yaml from `path`; fall back to defaults if absent."""
    p = Path(path)
    if not p.exists():
        return Rules()
    data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    return Rules(**data)
