"""Deterministic, grounded loan decision (the anti-hallucination core).

WHY DETERMINISTIC: the recommendation is computed by a fixed policy over
corroborated numbers — no language model produces it, so there is nothing to
hallucinate. Every rationale line references a fact that is (a) read live from the
system of record and (b) exactly corroborated in a document.

WHAT RULES IT APPLIES (all from rules.yaml — nothing hard-coded):
  - eligibility.age          -> hard reject outside [min_age, max_age]
  - exact corroboration      -> ABSTAIN (REFER) if any decision fact is unproven
  - affordability.foir_basis -> FOIR computed on NET or GROSS income
  - policy.min_monthly_net   -> hard reject below the income floor
  - credit_rules.min_score   -> hard reject below the score floor
  - credit_rules.score_bands -> map the score to an internal risk grade (A..E)
  - affordability.min_surplus_income -> hard reject if too little is left after EMIs
  - policy.max_dti_acceptable / max_dti_auto_approve -> the FOIR decision band
  - risk_grading.auto_approve_grades / reject_grades -> grade gates the decision

ABSTENTION (not a guess) is what keeps the hallucination rate at zero on the
facts that matter.
"""

from __future__ import annotations

from loan_rag.config.rules import Rules
from loan_rag.domain.decision import DecisionResult
from loan_rag.domain.enums import Decision, FactStatus
from loan_rag.domain.fact import Fact


class GroundedDecisionPolicy:
    """Applies the configured lending rules to corroborated facts and explains it."""

    def __init__(self, rules: Rules) -> None:
        """Hold the whole (validated, configurable) rule set."""
        self._r = rules

    def _grade(self, score: int) -> str:
        """Map a credit score to an internal risk grade using credit_rules.score_bands."""
        for band in self._r.credit_rules.score_bands:
            if band.min <= score <= band.max:
                return band.grade
        return ""

    def decide(self, application_id: str, net: Fact, credit: Fact, existing_emi: Fact,
               proposed_new_emi: float, applicant_age: int = 0,
               gross_income: float = 0.0, loan_type: str = "",
               acceptable_dti: float | None = None) -> DecisionResult:
        """Compute FOIR, apply the rules, and build a fully-cited rationale."""
        r = self._r
        p, e, aff, cr, rg = (r.policy, r.eligibility, r.affordability,
                             r.credit_rules, r.risk_grading)
        result = DecisionResult(application_id=application_id,
                                recommendation=Decision.REFER,
                                facts=[net, credit, existing_emi])

        # 0) Eligibility: age gate (skipped if age unknown).
        if applicant_age > 0 and (applicant_age < e.min_age or applicant_age > e.max_age):
            result.recommendation = Decision.REJECT
            result.rationale.append(
                f"REJECT (eligibility): age {applicant_age} outside "
                f"[{e.min_age}, {e.max_age}].")
            return result

        # 1) Abstain if any decision-critical fact is not exactly corroborated.
        uncorroborated = [f.name for f in (net, credit, existing_emi)
                          if f.status is FactStatus.UNCORROBORATED]
        if uncorroborated or net.value <= 0:
            result.abstained = True
            result.recommendation = Decision.REFER
            result.abstain_reasons = [
                f"'{n}' could not be exactly corroborated in any document"
                for n in uncorroborated] or ["monthly net income is missing or zero"]
            result.rationale.append("Abstaining: decision-critical facts are not fully grounded.")
            return result

        # 2) Affordability: FOIR on the configured income basis (NET or GROSS).
        use_gross = aff.foir_basis.upper() == "GROSS" and gross_income > 0
        income = gross_income if use_gross else net.value
        basis = "gross" if use_gross else "net"
        foir = (existing_emi.value + proposed_new_emi) / income
        surplus = income - (existing_emi.value + proposed_new_emi)
        # Per-product FOIR cap (from loan_products[].foir_cap) overrides the global one.
        acc_cap = acceptable_dti if acceptable_dti is not None else p.max_dti_acceptable
        grade = self._grade(int(credit.value))
        result.dti = round(foir, 4)
        result.risk_grade = grade

        result.rationale.append(
            f"Monthly {basis} income {int(income)} "
            f"[cite:{net.citation_chunk_id}]; existing EMIs {existing_emi.rendered} "
            f"[cite:{existing_emi.citation_chunk_id}]; proposed new EMI "
            f"{int(proposed_new_emi)} -> FOIR {foir:.0%}, surplus {int(surplus)} "
            f"[product: {loan_type or 'default'}].")
        result.rationale.append(
            f"Credit score {credit.rendered} [cite:{credit.citation_chunk_id}] "
            f"-> risk grade {grade or 'NA'} (min {cr.min_score}).")

        # 3) Hard rejects (any one fails the loan).
        reasons: list[str] = []
        if credit.value < cr.min_score:
            reasons.append(f"credit {int(credit.value)} < min {cr.min_score}")
        if income < p.min_monthly_net:
            reasons.append(f"income {int(income)} < min {int(p.min_monthly_net)}")
        if foir > acc_cap:
            reasons.append(f"FOIR {foir:.0%} > max {acc_cap:.0%} ({loan_type or 'default'})")
        if surplus < aff.min_surplus_income:
            reasons.append(f"surplus {int(surplus)} < min {int(aff.min_surplus_income)}")
        if grade and grade in rg.reject_grades:
            reasons.append(f"risk grade {grade} is a reject grade")
        if reasons:
            result.recommendation = Decision.REJECT
            result.rationale.append("REJECT: " + "; ".join(reasons) + ".")
            return result

        # 4) Auto-approve only if FOIR is in the safe band AND the grade allows it.
        grade_ok = (not grade) or (grade in rg.auto_approve_grades)
        if foir <= p.max_dti_auto_approve and grade_ok:
            result.recommendation = Decision.APPROVE
            result.rationale.append(
                f"APPROVE: FOIR within auto-approve limit "
                f"({p.max_dti_auto_approve:.0%}) and grade {grade or 'NA'} permits it.")
        else:
            result.recommendation = Decision.REFER
            result.rationale.append(
                f"REFER: FOIR {foir:.0%} between auto-approve "
                f"({p.max_dti_auto_approve:.0%}) and reject ({acc_cap:.0%}), "
                f"or grade {grade or 'NA'} needs review — a human must decide.")
        return result
