"""RabbitMQ publisher — the INGESTION stage calls this when a loan's documents
are ingested and ready for a decision.

The message is the hand-off contract between the two stages:

    {
      "application_id": "LOAN-2026-000123",
      "loan_type": "PERSONAL",          # product code from the application/LOS
      "proposed_new_emi": 21000.0
    }

WHY loan_type lives in the message (not parsed from a document): the product a
customer applied for is structured application metadata owned by the loan
origination system — it is reliable there, unlike free OCR text. So it travels
with the event and flows into the decision (per-product documents + FOIR cap).

Config (env):
  RABBITMQ_URL   default amqp://guest:guest@localhost:5672/
  LOANRAG_QUEUE  default loan.ingested
"""

from __future__ import annotations

import json
import os

QUEUE = os.environ.get("LOANRAG_QUEUE", "loan.ingested")
RABBITMQ_URL = os.environ.get("RABBITMQ_URL", "amqp://guest:guest@localhost:5672/")


def publish_ingested(application_id: str, loan_type: str = "PERSONAL",
                     proposed_new_emi: float = 21000.0) -> None:
    """Publish a durable 'loan ingested -> please decide' event to RabbitMQ."""
    import pika  # imported lazily so the rest of the package needs no broker

    params = pika.URLParameters(RABBITMQ_URL)
    connection = pika.BlockingConnection(params)
    try:
        channel = connection.channel()
        channel.queue_declare(queue=QUEUE, durable=True)
        body = json.dumps({"application_id": application_id, "loan_type": loan_type,
                           "proposed_new_emi": proposed_new_emi})
        channel.basic_publish(
            exchange="", routing_key=QUEUE, body=body.encode("utf-8"),
            properties=pika.BasicProperties(delivery_mode=2))  # persistent
    finally:
        connection.close()
