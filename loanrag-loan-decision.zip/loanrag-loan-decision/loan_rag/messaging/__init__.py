"""RabbitMQ event publisher + consumer (the automatic trigger)."""
