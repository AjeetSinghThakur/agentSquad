"""LoanRAG decision CLI.

Subcommands:
  run      Assess an application. Runs the graph until it PAUSES — either for a
           human DECISION (approve/reject) or for human ERROR review (retry/abort
           after a node could not recover).
  resume   Apply the human's choice and continue:
             --decision approve|reject|override   (for a decision pause)
             --action   retry|abort               (for an error pause)
  status   Show the current state of an application's workflow thread.

Run:  python -m loan_rag.presentation.cli run --application-id LOAN-2026-000123
"""

from __future__ import annotations

import argparse
import json
import logging

from langgraph.types import Command

from loan_rag.config.settings import get_settings
from loan_rag.workflow.graph import build_app

DEFAULT_APP = "LOAN-2026-000123"


def _config(application_id: str) -> dict:
    """The LangGraph thread config — one durable thread per application."""
    return {"configurable": {"thread_id": f"loan::{application_id}"}}


def _print_decision(payload: dict) -> None:
    """Pretty-print the decision package shown to the human reviewer."""
    print("\n================ LOAN DECISION — AWAITING HUMAN REVIEW ================")
    print(f"  Application   : {payload.get('application_id')}  ({payload.get('applicant_name')})")
    print(f"  Recommendation: {str(payload.get('recommendation')).upper()}"
          + ("  [ABSTAINED]" if payload.get("abstained") else ""))
    if payload.get("dti") is not None:
        print(f"  FOIR (DTI)    : {payload['dti']:.0%}   risk grade: {payload.get('risk_grade') or 'NA'}")
    m = payload.get("metrics") or {}
    if m:
        print(f"  Retrieval     : recall {m.get('recall')}, "
              f"false-positive {m.get('false_positive_rate')} "
              f"({m.get('criteria_with_hit')}/{m.get('criteria_total')} criteria found)")
    print("  Rationale (every line cites the fact it rests on):")
    for line in payload.get("rationale", []):
        print(f"    - {line}")
    print("  Facts (live from system of record, exact-match corroborated):")
    for f in payload.get("facts", []):
        tag = "OK" if f["status"] == "corroborated" else "UNCORROBORATED"
        print(f"    - {f['name']:18s} = {f['rendered']:>10s}  [{tag}] cite={f['citation_chunk_id']}")
    print("======================================================================\n")
    print("To finish, run:")
    print(f"  python -m loan_rag.presentation.cli resume "
          f"--application-id {payload.get('application_id')} --decision approve|reject")


def _print_error(payload: dict) -> None:
    """Pretty-print a system-error escalation shown to the human."""
    print("\n############### SYSTEM ERROR — AWAITING HUMAN REVIEW ###############")
    print(f"  Application : {payload.get('application_id')}")
    print(f"  Failed node : {payload.get('failed_node')}")
    print(f"  Message     : {payload.get('message')}")
    print("  A node could not recover after automatic retries.")
    print("###################################################################\n")
    print("To recover, run ONE of:")
    print(f"  python -m loan_rag.presentation.cli resume "
          f"--application-id {payload.get('application_id')} --action retry")
    print(f"  python -m loan_rag.presentation.cli resume "
          f"--application-id {payload.get('application_id')} --action abort")


def cmd_run(args) -> None:
    """Assess an application; stop at whichever pause occurs and show the package."""
    app = build_app(get_settings())
    cfg = _config(args.application_id)
    out = app.invoke({"application_id": args.application_id,
                      "loan_type": args.loan_type,
                      "proposed_new_emi": args.proposed_new_emi}, cfg)

    if "__interrupt__" in out:
        payload = out["__interrupt__"][0].value
        if payload.get("type") == "system_error":
            _print_error(payload)
        else:
            _print_decision(payload)
    else:
        print(f"Workflow ended without human review: {out.get('status')}")
        for line in out.get("rationale", []):
            print(f"  - {line}")


def cmd_resume(args) -> None:
    """Resume a paused application with the human's decision or recovery action."""
    app = build_app(get_settings())
    cfg = _config(args.application_id)
    resume_value: dict = {}
    if args.decision:
        resume_value.update({"decision": args.decision, "note": args.note or ""})
    if args.action:
        resume_value.update({"action": args.action})
    if not resume_value:
        raise SystemExit("Provide --decision (approve|reject|override) or --action (retry|abort)")

    out = app.invoke(Command(resume=resume_value), cfg)
    # A 'retry' may run straight into another pause (decision or another error).
    if "__interrupt__" in out:
        payload = out["__interrupt__"][0].value
        (_print_error if payload.get("type") == "system_error" else _print_decision)(payload)
        return
    print(f"Final status : {out.get('status')}")
    print(f"Human note   : {out.get('human_note') or '(none)'}")


def cmd_status(args) -> None:
    """Show the current persisted state of an application's workflow thread."""
    app = build_app(get_settings())
    snap = app.get_state(_config(args.application_id))
    if not snap.values:
        print("No workflow found for that application (run it first).")
        return
    v = snap.values
    print(json.dumps({"status": v.get("status"), "recommendation": v.get("recommendation"),
                      "human_decision": v.get("human_decision"),
                      "completeness_ok": v.get("completeness_ok"),
                      "missing_documents": v.get("missing_documents"),
                      "error": v.get("error"), "dti": v.get("dti"),
                      "metrics": v.get("metrics")}, indent=2))
    if snap.next:
        print("paused at:", snap.next)


def main() -> None:
    """Parse arguments and dispatch to the chosen subcommand."""
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    parser = argparse.ArgumentParser(prog="loan-rag", description="LoanRAG decision workflow")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("run", help="assess an application (pauses for human review)")
    p.add_argument("--application-id", default=DEFAULT_APP)
    p.add_argument("--loan-type", default="PERSONAL")
    p.add_argument("--proposed-new-emi", type=float, default=21000.0)
    p.set_defaults(func=cmd_run)

    p = sub.add_parser("resume", help="apply the human decision/action and continue")
    p.add_argument("--application-id", default=DEFAULT_APP)
    p.add_argument("--decision", choices=["approve", "reject", "override"])
    p.add_argument("--action", choices=["retry", "abort"])
    p.add_argument("--note", default="")
    p.set_defaults(func=cmd_resume)

    p = sub.add_parser("status", help="show the workflow state")
    p.add_argument("--application-id", default=DEFAULT_APP)
    p.set_defaults(func=cmd_status)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
