"""FastAPI service exposing the loan-decision workflow.

This is the long-running process that Kubernetes runs and the HPA scales. It also
serves a simple **reviewer console** (GET /) so a human can see paused loans and
click Approve / Reject / Override — those buttons just call POST /resume.

Endpoints:
  GET  /                          reviewer console (HTML page)
  GET  /healthz                   liveness/readiness probe (used by K8s)
  GET  /pending                   loans currently awaiting a human (the review queue)
  POST /assess                    start an assessment (returns a decision or a pause)
  POST /resume                    apply a human decision/action and continue
  GET  /status/{application_id}   current workflow state
"""

from __future__ import annotations

import sqlite3

from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from langgraph.types import Command
from pydantic import BaseModel

from loan_rag.config.settings import get_settings
from loan_rag.workflow.graph import build_app

app = FastAPI(title="LoanRAG Decision API", version="1.1")

_graph = None


def _g():
    """Build the compiled graph once per process (reused across requests)."""
    global _graph
    if _graph is None:
        _graph = build_app(get_settings())
    return _graph


def _cfg(application_id: str) -> dict:
    """One durable LangGraph thread per application."""
    return {"configurable": {"thread_id": f"loan::{application_id}"}}


class AssessRequest(BaseModel):
    """Body for POST /assess. loan_type is the product code from the application."""

    application_id: str
    loan_type: str = "PERSONAL"
    proposed_new_emi: float = 21000.0


class ResumeRequest(BaseModel):
    """Body for POST /resume — supply decision (approve/reject/override) or action (retry/abort)."""

    application_id: str
    decision: str | None = None
    action: str | None = None
    note: str = ""


def _shape(out: dict) -> dict:
    """Turn a graph result into a small JSON-friendly response."""
    if "__interrupt__" in out:
        return {"state": "paused", "interrupt": out["__interrupt__"][0].value}
    return {"state": "done", "status": out.get("status"),
            "recommendation": out.get("recommendation"),
            "risk_grade": out.get("risk_grade"), "dti": out.get("dti"),
            "rationale": out.get("rationale")}


@app.get("/healthz")
def healthz() -> dict:
    """Liveness/readiness probe."""
    return {"status": "ok"}


@app.post("/assess")
def assess(req: AssessRequest) -> dict:
    """Run an assessment until it completes or pauses for a human."""
    out = _g().invoke({"application_id": req.application_id,
                       "loan_type": req.loan_type,
                       "proposed_new_emi": req.proposed_new_emi}, _cfg(req.application_id))
    return _shape(out)


@app.post("/resume")
def resume(req: ResumeRequest) -> dict:
    """Resume a paused application with the human's decision or recovery action."""
    resume_value: dict = {}
    if req.decision:
        resume_value.update({"decision": req.decision, "note": req.note})
    if req.action:
        resume_value.update({"action": req.action})
    out = _g().invoke(Command(resume=resume_value), _cfg(req.application_id))
    return _shape(out)


@app.get("/status/{application_id}")
def status(application_id: str) -> dict:
    """Return the current persisted state of an application's workflow thread."""
    snap = _g().get_state(_cfg(application_id))
    if not snap.values:
        return {"status": "not_found"}
    return {"status": snap.values.get("status"),
            "recommendation": snap.values.get("recommendation"),
            "paused_at": list(snap.next) if snap.next else []}


def _thread_ids() -> list[str]:
    """List workflow thread ids from the checkpointer (sqlite demo backend).

    PRODUCTION NOTE: scanning the checkpointer is fine for modest volumes. At
    scale, maintain a dedicated 'pending reviews' table (written when a loan
    pauses) or consume a 'loan.review' message — don't scan checkpoints.
    """
    settings = get_settings()
    if settings.checkpointer.backend != "sqlite":
        return []
    try:
        conn = sqlite3.connect(settings.checkpointer.sqlite_path)
        rows = conn.execute("SELECT DISTINCT thread_id FROM checkpoints").fetchall()
        conn.close()
        return [r[0] for r in rows]
    except Exception:
        return []


@app.get("/pending")
def pending() -> dict:
    """Return the loans currently paused for a human (the review queue)."""
    graph = _g()
    items: list[dict] = []
    for thread_id in _thread_ids():
        app_id = thread_id.split("::", 1)[-1]
        snap = graph.get_state(_cfg(app_id))
        if not snap.next:
            continue
        node = snap.next[0]
        v = snap.values
        if node == "human_review":
            items.append({"application_id": app_id, "type": "decision",
                          "loan_type": v.get("loan_type"),
                          "applicant_name": v.get("applicant_name"),
                          "recommendation": v.get("recommendation"),
                          "risk_grade": v.get("risk_grade"), "dti": v.get("dti"),
                          "rationale": v.get("rationale", []), "facts": v.get("facts", []),
                          "metrics": v.get("metrics", {})})
        elif node == "error_review":
            err = v.get("error", {})
            items.append({"application_id": app_id, "type": "system_error",
                          "failed_node": err.get("node"), "message": err.get("message")})
    return {"pending": items, "count": len(items)}


@app.get("/", response_class=HTMLResponse)
def console() -> str:
    """A minimal reviewer console: lists pending loans with Approve/Reject buttons."""
    return _CONSOLE_HTML


_CONSOLE_HTML = """<!doctype html><html><head><meta charset="utf-8">
<title>LoanRAG — Review Console</title>
<style>
 body{font-family:Segoe UI,Arial,sans-serif;margin:24px;background:#f7f8fa;color:#202124}
 h1{font-size:20px} .card{background:#fff;border:1px solid #dadce0;border-radius:10px;
   padding:16px;margin:12px 0;box-shadow:0 1px 3px rgba(0,0,0,.06)}
 .err{border-left:6px solid #C5221F} .dec{border-left:6px solid #1A73E8}
 .k{color:#5f6368;font-size:12px} .v{font-weight:600}
 button{border:0;border-radius:8px;padding:8px 14px;margin-right:8px;color:#fff;cursor:pointer;font-weight:600}
 .ap{background:#137333} .rj{background:#C5221F} .ov{background:#E37400}
 .rt{background:#1A73E8} .ab{background:#5f6368}
 pre{white-space:pre-wrap;background:#f1f3f4;padding:8px;border-radius:6px;font-size:12px}
 .empty{color:#5f6368}
</style></head><body>
<h1>LoanRAG — Review Console</h1>
<p class="k">Loans paused for a human. Buttons call <code>POST /resume</code>.</p>
<div id="list"><p class="empty">Loading…</p></div>
<script>
async function load(){
  const r = await fetch('/pending'); const d = await r.json();
  const el = document.getElementById('list');
  if(!d.count){ el.innerHTML='<p class="empty">No loans awaiting review.</p>'; return; }
  el.innerHTML = d.pending.map(card).join('');
}
function card(x){
  if(x.type==='system_error'){
    return `<div class="card err"><div class="v">${x.application_id} — SYSTEM ERROR</div>
      <div class="k">failed node</div><div>${x.failed_node||''}</div>
      <pre>${x.message||''}</pre>
      <button class="rt" onclick="act('${x.application_id}',{action:'retry'})">Retry</button>
      <button class="ab" onclick="act('${x.application_id}',{action:'abort'})">Abort</button></div>`;
  }
  const facts = (x.facts||[]).map(f=>`${f.name} = ${f.rendered} [${f.status}]`).join('\\n');
  const rat = (x.rationale||[]).join('\\n');
  return `<div class="card dec"><div class="v">${x.application_id} — ${x.recommendation} (grade ${x.risk_grade||'NA'})</div>
    <div class="k">${x.loan_type||''} · applicant ${x.applicant_name||''} · FOIR ${x.dti!=null?Math.round(x.dti*100)+'%':'-'}</div>
    <pre>${rat}\\n\\n${facts}</pre>
    <button class="ap" onclick="act('${x.application_id}',{decision:'approve'})">Approve</button>
    <button class="rj" onclick="act('${x.application_id}',{decision:'reject'})">Reject</button>
    <button class="ov" onclick="act('${x.application_id}',{decision:'override',note:'manual override'})">Override</button></div>`;
}
async function act(id, body){
  body.application_id = id;
  await fetch('/resume',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  load();
}
load();
</script></body></html>"""
