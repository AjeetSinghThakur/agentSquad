# KPIs — what they are, why we use them, and where they live in the code

![LoanRAG KPIs at a glance](docs/diagrams/kpis.png)


A "KPI" here is a number the system reports about *how trustworthy a decision is*
— not a business metric like profit. They exist so that every loan decision is
**measurable and auditable**, not a black box. Below: what each one is, why it
matters for lending, the advantage it buys you, and the exact place in the code.

---

## 1. Completeness (the document-gate KPI)

- **What:** are ALL required documents present before we decide? Reported as
  `completeness_ok` plus the list of `missing_documents`.
- **Why:** a loan decided on a missing salary slip or credit report is unsafe and
  often non-compliant. This KPI makes "did we even have enough to decide?" explicit.
- **Advantage:** approval is *structurally* impossible until completeness passes —
  the graph has no path from an incomplete state to the decision.
- **Where:** `workflow/nodes.py → completeness_gate` (uses
  `rules.required_documents`), enforced by the conditional edge in
  `workflow/graph.py`.

## 2. Exact-match corroboration (the grounding KPI)

- **What:** for each decision-critical number (income, credit score, existing
  EMIs), did the exact value from the system-of-record also appear, exactly, in a
  document? Each `Fact` is stamped `CORROBORATED` or `UNCORROBORATED`.
- **Why:** it proves the number driving the decision is actually evidenced, and
  catches mismatches between the database and the paperwork.
- **Advantage:** an uncorroborated fact forces the decision to **abstain** (REFER)
  rather than rely on an unproven number — this is a core anti-hallucination lever.
- **Where:** `facts/exact_fact_extractor.py → corroborate` (exact only, no fuzzy);
  consumed in `grounding/grounded_decision.py`.

## 3. Recall (the "did we find the evidence?" KPI)

- **What:** of the decision criteria (income, credit, obligations), the fraction
  for which the retriever returned at least one chunk from an *expected* document.
  `1.0` means every criterion's evidence was found.
- **Why:** low recall means the system is deciding without having surfaced the
  supporting evidence — a quality risk even if the final numbers come from the DB.
- **Advantage:** a measurable guarantee that the evidence behind a decision was
  actually retrieved; you can alert when recall drops.
- **Where:** `metrics/recall_false_positive.py → compute_metrics`, called from
  `workflow/nodes.py → retrieve_evidence`. Expected documents per criterion come
  from `rules.yaml` (`criteria[].expected_documents`).

## 4. False-positive rate (the "how much noise?" KPI)

- **What:** of all retrieved chunks, the fraction from documents *not* expected for
  that criterion. Lower is better.
- **Why:** a noisy retriever buries the right evidence among irrelevant text,
  which is exactly where a naive or LLM-only system starts hallucinating.
- **Advantage:** it quantifies retrieval precision per decision. Locally it's high
  (~0.58) **on purpose** — the simple lexical retriever is noisy, and the KPI
  exposes that honestly. Swapping in Azure AI Search hybrid retrieval lowers it
  sharply, and the same KPI proves the improvement.
- **Where:** same as recall — `metrics/recall_false_positive.py`.

## 5. Abstention / zero-hallucination (the safety KPI)

- **What:** did the system decide, or did it correctly *refuse to guess*?
  Reported as `abstained` + `abstain_reasons`.
- **Why:** the safe failure mode for lending is "refer to a human," never
  "confidently wrong." This KPI tracks how often the system protected itself.
- **Advantage:** because the decision is a deterministic policy over grounded,
  cited facts and abstains when not fully grounded, the worst case is REFER — there
  is no generated text that can invent a number.
- **Where:** `grounding/grounded_decision.py` (the abstain block + the
  `[cite:chunk_id]` rationale lines).

## 6. Resilience / recovery (the operational KPI)

- **What:** did an I/O step fail, how many automatic retries did it take, and did
  it recover or escalate to a human?
- **Why:** production systems hit transient failures (a DB blip, a warming
  service). You want them to self-heal, and to escalate cleanly when they can't.
- **Advantage:** transient failures are retried automatically with backoff; only
  genuinely stuck cases reach a human (via `error_review`), with the failing node
  and message attached — no silent crashes.
- **Where:** `workflow/resilience.py → run_with_retry` (logs each attempt),
  `workflow/nodes.py → error_review`, and the LangGraph `RetryPolicy` attached in
  `workflow/graph.py`.

---

### Upstream KPIs (from the ingestion stage)

The ingestion stage also produces quality KPIs that this stage relies on: the
**null/quality pass-rate** (chunks dropped for being empty/garbage/low-confidence)
and **OCR confidence** for scanned pages. They gate what ever reaches
`loan-chunks`, so by the time the decision stage runs, the inputs have already
cleared a quality bar. Those live in the ingestion package
(`infrastructure/chunking/null_guard.py` and the quality gate in
`application/ingestion_service.py`).

---

## Code map — exactly where each KPI / rule lives

| KPI / rule | File | Symbol (function / field) |
|---|---|---|
| Completeness gate | `loan_rag/workflow/nodes.py` | `completeness_gate()` (uses `rules.required_documents`) |
| Completeness routing | `loan_rag/workflow/graph.py` | conditional edge after `completeness_gate` |
| Exact-match corroboration | `loan_rag/facts/exact_fact_extractor.py` | `ExactFactCorroborator.corroborate()` |
| Live authoritative facts | `loan_rag/facts/authoritative_facts.py` | `AuthoritativeFactsRepository.fetch()` |
| Recall & false-positive | `loan_rag/metrics/recall_false_positive.py` | `compute_metrics()` |
| Recall/FP invoked | `loan_rag/workflow/nodes.py` | `retrieve_evidence()` (uses `rules.criteria`) |
| Abstention / zero-hallucination | `loan_rag/grounding/grounded_decision.py` | `decide()` — abstain block |
| Citations | `grounded_decision.py` + `exact_fact_extractor.py` | `[cite:...]` rationale + `Fact.citation_chunk_id` |
| Auto-retry (transient) | `loan_rag/workflow/resilience.py` | `run_with_retry()` |
| Retry safety net | `loan_rag/workflow/graph.py` | `RetryPolicy(...)` on I/O nodes |
| HITL error escalation | `loan_rag/workflow/nodes.py` | `error_review()` |
| HITL decision pause | `loan_rag/workflow/nodes.py` | `human_review()` (`interrupt()`) |

## Decision rules now ENFORCED (not just present in rules.yaml)

All applied in `grounding/grounded_decision.py → decide()`, reading from `rules.yaml`:

| Rule | rules.yaml source | Effect |
|---|---|---|
| Age eligibility | `eligibility.min_age/max_age` | hard REJECT outside the range |
| FOIR basis | `affordability.foir_basis` | FOIR computed on NET or GROSS income |
| Income floor | `policy.min_monthly_net` | hard REJECT below it |
| Credit floor | `credit_rules.min_score` | hard REJECT below it |
| Risk grade | `credit_rules.score_bands` | score → grade A..E (shown in output) |
| Surplus floor | `affordability.min_surplus_income` | hard REJECT if too little left after EMIs |
| FOIR band | `policy.max_dti_auto_approve` / `max_dti_acceptable` | APPROVE / REFER / REJECT band |
| Grade gating | `risk_grading.auto_approve_grades` / `reject_grades` | grade must permit auto-approve |

The remaining `rules.yaml` sections (LTV slabs, KYC, pricing, fraud lists,
per-product documents) are validated and ready to wire as the corresponding data
sources (collateral value, KYC service, bureau detail) are connected — each is a
small addition to `decide()` or a new gate node, with no change to the structure.