<#
.SYNOPSIS
  Provisions every Azure resource the LoanRAG ingestion + decision system needs.

.DESCRIPTION
  Creates: resource group, Storage (Blob), Document Intelligence, Azure SQL,
  Azure Database for PostgreSQL (LangGraph checkpointer), Azure AI Search,
  (optional) Azure OpenAI, Container Registry, Container Apps environment,
  Key Vault, Log Analytics + Application Insights. At the end it prints the
  connection strings / settings to feed the apps (LOANRAG__... env vars).

.PREREQUISITES
  - Azure CLI installed and logged in:   az login
  - The containerapp extension:          az extension add --name containerapp
  - Sufficient permissions in the target subscription.

.EXAMPLE
  ./provision-azure.ps1 -Prefix loanrag -Location centralindia -SqlAdminPassword 'Str0ng#Pass!' -PgAdminPassword 'Str0ng#Pass!'

.NOTES
  Names for globally-unique resources get a short random suffix. Re-running with
  the same -Suffix is idempotent-ish (az create is mostly create-or-update).
#>

[CmdletBinding()]
param(
  [string] $Prefix = "loanrag",
  [string] $Location = "centralindia",
  [string] $ResourceGroup = "",
  [string] $Suffix = "",                      # leave blank to auto-generate
  [Parameter(Mandatory = $true)] [string] $SqlAdminPassword,
  [Parameter(Mandatory = $true)] [string] $PgAdminPassword,
  [string] $SqlAdminUser = "loanadmin",
  [string] $PgAdminUser  = "loanadmin",
  [switch] $DeployOpenAI = $false             # Azure OpenAI is optional
)

$ErrorActionPreference = "Stop"

# --- derive names ---------------------------------------------------------- #
if (-not $Suffix)        { $Suffix = -join ((48..57) + (97..122) | Get-Random -Count 5 | ForEach-Object { [char]$_ }) }
if (-not $ResourceGroup) { $ResourceGroup = "$Prefix-rg" }

$storage   = ("{0}stg{1}" -f $Prefix, $Suffix).ToLower()   # 3-24 lc-alnum, globally unique
$docintel  = "$Prefix-docintel-$Suffix"
$sqlServer = "$Prefix-sql-$Suffix"
$sqlDb     = "loanrag"
$pgServer  = "$Prefix-pg-$Suffix"
$pgDb      = "loanrag"
$search    = "$Prefix-search-$Suffix"
$openai    = "$Prefix-openai-$Suffix"
$acr       = ("{0}acr{1}" -f $Prefix, $Suffix).ToLower()   # 5-50 lc-alnum, globally unique
$acaEnv    = "$Prefix-aca-env"
$kv        = "$Prefix-kv-$Suffix"
$logws     = "$Prefix-logs"
$appins    = "$Prefix-appinsights"

Write-Host "==> Resource group: $ResourceGroup ($Location), suffix '$Suffix'" -ForegroundColor Cyan
az group create -n $ResourceGroup -l $Location | Out-Null

# --- 1) Storage (Blob) + containers --------------------------------------- #
Write-Host "==> Storage account: $storage" -ForegroundColor Cyan
az storage account create -n $storage -g $ResourceGroup -l $Location `
  --sku Standard_LRS --kind StorageV2 --min-tls-version TLS1_2 | Out-Null
$storageKey = az storage account keys list -n $storage -g $ResourceGroup --query "[0].value" -o tsv
foreach ($c in @("loan-docs", "loan-chunks")) {
  az storage container create --name $c --account-name $storage --account-key $storageKey | Out-Null
}
$storageConn = az storage account show-connection-string -n $storage -g $ResourceGroup -o tsv

# --- 2) Document Intelligence (OCR for scans) ----------------------------- #
Write-Host "==> Document Intelligence: $docintel" -ForegroundColor Cyan
az cognitiveservices account create -n $docintel -g $ResourceGroup -l $Location `
  --kind FormRecognizer --sku S0 --yes | Out-Null
$docintelEndpoint = az cognitiveservices account show -n $docintel -g $ResourceGroup --query "properties.endpoint" -o tsv
$docintelKey      = az cognitiveservices account keys list -n $docintel -g $ResourceGroup --query "key1" -o tsv

# --- 3) Azure SQL (authoritative facts, queried live) --------------------- #
Write-Host "==> Azure SQL: $sqlServer / $sqlDb" -ForegroundColor Cyan
az sql server create -n $sqlServer -g $ResourceGroup -l $Location `
  --admin-user $SqlAdminUser --admin-password $SqlAdminPassword | Out-Null
az sql db create -g $ResourceGroup -s $sqlServer -n $sqlDb --service-objective S0 | Out-Null
# Allow Azure services to reach the server (tighten for production!)
az sql server firewall-rule create -g $ResourceGroup -s $sqlServer `
  -n AllowAzure --start-ip-address 0.0.0.0 --end-ip-address 0.0.0.0 | Out-Null
$sqlConn = "Server=tcp:$sqlServer.database.windows.net,1433;Database=$sqlDb;User ID=$SqlAdminUser;Password=$SqlAdminPassword;Encrypt=true;"

# --- 4) PostgreSQL Flexible Server (LangGraph checkpointer / HITL) --------- #
Write-Host "==> PostgreSQL: $pgServer / $pgDb" -ForegroundColor Cyan
az postgres flexible-server create -n $pgServer -g $ResourceGroup -l $Location `
  --admin-user $PgAdminUser --admin-password $PgAdminPassword `
  --tier Burstable --sku-name Standard_B1ms --version 16 `
  --public-access 0.0.0.0 --yes | Out-Null
az postgres flexible-server db create -g $ResourceGroup -s $pgServer -d $pgDb | Out-Null
$pgConn = "postgresql://${PgAdminUser}:${PgAdminPassword}@$pgServer.postgres.database.azure.com:5432/$pgDb?sslmode=require"

# --- 5) Azure AI Search (hybrid evidence retrieval) ----------------------- #
Write-Host "==> Azure AI Search: $search" -ForegroundColor Cyan
az search service create -n $search -g $ResourceGroup -l $Location --sku basic | Out-Null
$searchKey = az search admin-key show --service-name $search -g $ResourceGroup --query "primaryKey" -o tsv

# --- 6) Azure OpenAI (optional grounded rationale) ------------------------ #
$openaiEndpoint = ""; $openaiKey = ""
if ($DeployOpenAI) {
  Write-Host "==> Azure OpenAI: $openai" -ForegroundColor Cyan
  az cognitiveservices account create -n $openai -g $ResourceGroup -l $Location `
    --kind OpenAI --sku S0 --yes | Out-Null
  az cognitiveservices account deployment create -n $openai -g $ResourceGroup `
    --deployment-name gpt-4o-mini --model-name gpt-4o-mini `
    --model-version "2024-07-18" --model-format OpenAI `
    --sku-capacity 1 --sku-name Standard | Out-Null
  $openaiEndpoint = az cognitiveservices account show -n $openai -g $ResourceGroup --query "properties.endpoint" -o tsv
  $openaiKey      = az cognitiveservices account keys list -n $openai -g $ResourceGroup --query "key1" -o tsv
}

# --- 7) Container Registry ------------------------------------------------- #
Write-Host "==> Container Registry: $acr" -ForegroundColor Cyan
az acr create -n $acr -g $ResourceGroup -l $Location --sku Basic --admin-enabled true | Out-Null

# --- 8) Container Apps environment ---------------------------------------- #
Write-Host "==> Log Analytics + App Insights" -ForegroundColor Cyan
az monitor log-analytics workspace create -g $ResourceGroup -n $logws -l $Location | Out-Null
$logKey = az monitor log-analytics workspace get-shared-keys -g $ResourceGroup -n $logws --query "primarySharedKey" -o tsv
$logId  = az monitor log-analytics workspace show -g $ResourceGroup -n $logws --query "customerId" -o tsv
az monitor app-insights component create -a $appins -g $ResourceGroup -l $Location --workspace $logws | Out-Null

Write-Host "==> Container Apps environment: $acaEnv" -ForegroundColor Cyan
az containerapp env create -n $acaEnv -g $ResourceGroup -l $Location `
  --logs-workspace-id $logId --logs-workspace-key $logKey | Out-Null

# --- 9) Key Vault ---------------------------------------------------------- #
Write-Host "==> Key Vault: $kv" -ForegroundColor Cyan
az keyvault create -n $kv -g $ResourceGroup -l $Location | Out-Null
az keyvault secret set --vault-name $kv -n "blob-connection-string"   --value "$storageConn" | Out-Null
az keyvault secret set --vault-name $kv -n "pg-connection-string"     --value "$pgConn"      | Out-Null
az keyvault secret set --vault-name $kv -n "sql-connection-string"    --value "$sqlConn"     | Out-Null
az keyvault secret set --vault-name $kv -n "search-key"               --value "$searchKey"   | Out-Null
az keyvault secret set --vault-name $kv -n "docintel-key"             --value "$docintelKey" | Out-Null

# --- output: the app settings to use -------------------------------------- #
Write-Host "`n================= PROVISIONING COMPLETE =================" -ForegroundColor Green
Write-Host "Set these as Container App settings (or read from Key Vault '$kv'):`n"
Write-Host "# 'azure_blob' = use the Azure Blob SDK; the CONNECTION STRING below points at REAL Azure Blob"
  Write-Host "LOANRAG__BLOB__BACKEND=azure_blob"
Write-Host "LOANRAG__BLOB__CONNECTION_STRING=$storageConn"
Write-Host "LOANRAG__BLOB__CHUNKS_CONTAINER=loan-chunks"
Write-Host "LOANRAG__CHECKPOINTER__BACKEND=postgres"
Write-Host "LOANRAG__CHECKPOINTER__POSTGRES_CONN=$pgConn"
Write-Host "LOANRAG__DB__AUTHORITATIVE_DB_PATH=(swap authoritative_facts.py to Azure SQL: $sqlConn )"
Write-Host "AZURE_SEARCH_ENDPOINT=https://$search.search.windows.net"
Write-Host "AZURE_SEARCH_KEY=$searchKey"
Write-Host "AZURE_DOCINTEL_ENDPOINT=$docintelEndpoint"
Write-Host "AZURE_DOCINTEL_KEY=$docintelKey"
if ($DeployOpenAI) {
  Write-Host "LOANRAG__LLM__BACKEND=azure_openai"
  Write-Host "LOANRAG__LLM__AZURE_ENDPOINT=$openaiEndpoint"
  Write-Host "LOANRAG__LLM__AZURE_DEPLOYMENT=gpt-4o-mini"
  Write-Host "AZURE_OPENAI_KEY=$openaiKey"
}
Write-Host "ACR_LOGIN_SERVER=$acr.azurecr.io"
Write-Host "`nNext: build & push images to $acr, then 'az containerapp create' the"
Write-Host "ingestion job and the decision app/API in env '$acaEnv'. See AZURE_DEPLOY.md." -ForegroundColor Cyan
