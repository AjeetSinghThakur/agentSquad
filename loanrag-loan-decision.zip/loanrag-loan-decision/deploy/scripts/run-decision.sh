#!/usr/bin/env bash
# Run a decision reading chunks from local | azure | gcp (same store ingestion wrote).
# Usage: ./run-decision.sh local|azure|gcp [APPLICATION_ID]
set -euo pipefail
TARGET="${1:-local}"; APP="${2:-LOAN-2026-000123}"
case "$TARGET" in
  local) export LOANRAG__BLOB__BACKEND=localfs
         export LOANRAG__BLOB__LOCALFS_ROOT="${LOANRAG__BLOB__LOCALFS_ROOT:-./_localblob}";;
  azure) export LOANRAG__BLOB__BACKEND=azure_blob
         : "${LOANRAG__BLOB__CONNECTION_STRING:?set LOANRAG__BLOB__CONNECTION_STRING}";;
  gcp)   export LOANRAG__BLOB__BACKEND=gcs
         : "${LOANRAG__BLOB__GCS_BUCKET:?set LOANRAG__BLOB__GCS_BUCKET}";;
  *) echo "usage: $0 local|azure|gcp [APP_ID]"; exit 1;;
esac
echo ">> Deciding $APP from backend=$LOANRAG__BLOB__BACKEND"
python -m loan_rag.presentation.cli run --application-id "$APP"
