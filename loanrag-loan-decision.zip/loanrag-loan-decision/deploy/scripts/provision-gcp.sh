#!/usr/bin/env bash
# =============================================================================
# Provisions every GCP resource the LoanRAG ingestion + decision system needs.
#
# Creates: enabled APIs, GCS buckets (loan-docs/loan-chunks), Document AI
# processor (OCR), Cloud SQL for PostgreSQL (LangGraph checkpointer + optional
# authoritative facts DB), Artifact Registry (images), a GKE Autopilot cluster
# (for the API + HPA), Secret Manager secrets, and a workload service account.
# Prints the settings to feed the app at the end.
#
# PREREQUISITES:
#   - gcloud CLI installed and authenticated:  gcloud auth login
#   - a billing-enabled project
#
# USAGE:
#   ./provision-gcp.sh -p <PROJECT_ID> [-r <REGION>] [-x <PREFIX>] [-z <PG_PASSWORD>]
#
# Vertex AI Search/Vector Search (the production retriever) is enabled here but
# its index is created from your embedding config — see GCP_DEPLOY.md §4.
# =============================================================================
set -euo pipefail

PROJECT=""; REGION="asia-south1"; PREFIX="loanrag"; PG_PASSWORD=""
while getopts "p:r:x:z:" opt; do
  case $opt in
    p) PROJECT="$OPTARG";; r) REGION="$OPTARG";;
    x) PREFIX="$OPTARG";;  z) PG_PASSWORD="$OPTARG";;
    *) echo "usage: $0 -p PROJECT_ID [-r REGION] [-x PREFIX] [-z PG_PASSWORD]"; exit 1;;
  esac
done
[ -z "$PROJECT" ] && { echo "ERROR: -p PROJECT_ID is required"; exit 1; }
[ -z "$PG_PASSWORD" ] && PG_PASSWORD="$(openssl rand -base64 18)"
SUFFIX="$(tr -dc 'a-z0-9' </dev/urandom | head -c5 || echo r$RANDOM)"

BUCKET_STORE="${PROJECT}-${PREFIX}-store"   # one bucket; loan-docs/ and loan-chunks/ are prefixes
SQL_INSTANCE="${PREFIX}-pg-${SUFFIX}"
AR_REPO="${PREFIX}-images"
GKE_CLUSTER="${PREFIX}-gke"
DOCAI_NAME="${PREFIX}-ocr"
SA_NAME="${PREFIX}-workload"

echo "==> Project=$PROJECT Region=$REGION Prefix=$PREFIX"
gcloud config set project "$PROJECT" >/dev/null

echo "==> Enabling APIs"
gcloud services enable \
  storage.googleapis.com sqladmin.googleapis.com artifactregistry.googleapis.com \
  container.googleapis.com secretmanager.googleapis.com documentai.googleapis.com \
  aiplatform.googleapis.com discoveryengine.googleapis.com run.googleapis.com >/dev/null

echo "==> GCS bucket (one bucket; container = object prefix)"
gcloud storage buckets create "gs://${BUCKET_STORE}" --location="$REGION" 2>/dev/null || true

echo "==> Document AI processor (OCR)"
gcloud documentai processors create --location="$REGION" \
  --display-name="$DOCAI_NAME" --type=OCR_PROCESSOR 2>/dev/null \
  || echo "   (create the OCR processor in the console if this CLI call is unavailable)"

echo "==> Cloud SQL for PostgreSQL (checkpointer + optional facts DB)"
gcloud sql instances create "$SQL_INSTANCE" \
  --database-version=POSTGRES_16 --tier=db-f1-micro --region="$REGION" \
  --storage-size=10 --root-password="$PG_PASSWORD" 2>/dev/null || true
gcloud sql databases create loanrag_state    --instance="$SQL_INSTANCE" 2>/dev/null || true
gcloud sql databases create authoritative     --instance="$SQL_INSTANCE" 2>/dev/null || true
SQL_CONN_NAME="$(gcloud sql instances describe "$SQL_INSTANCE" --format='value(connectionName)')"

echo "==> Artifact Registry (docker images)"
gcloud artifacts repositories create "$AR_REPO" --repository-format=docker \
  --location="$REGION" 2>/dev/null || true

echo "==> GKE Autopilot cluster (runs the API + HPA)"
gcloud container clusters create-auto "$GKE_CLUSTER" --region="$REGION" 2>/dev/null || true

echo "==> Workload service account"
gcloud iam service-accounts create "$SA_NAME" \
  --display-name="LoanRAG workload" 2>/dev/null || true
SA_EMAIL="${SA_NAME}@${PROJECT}.iam.gserviceaccount.com"
for role in roles/storage.objectAdmin roles/cloudsql.client \
            roles/documentai.apiUser roles/aiplatform.user \
            roles/secretmanager.secretAccessor; do
  gcloud projects add-iam-policy-binding "$PROJECT" \
    --member="serviceAccount:${SA_EMAIL}" --role="$role" >/dev/null 2>&1 || true
done

echo "==> Secret Manager"
PG_CONN="postgresql://postgres:${PG_PASSWORD}@/loanrag_state?host=/cloudsql/${SQL_CONN_NAME}"
printf '%s' "$PG_CONN" | gcloud secrets create loanrag-pg-conn --data-file=- 2>/dev/null \
  || printf '%s' "$PG_CONN" | gcloud secrets versions add loanrag-pg-conn --data-file=-

echo
echo "================= GCP PROVISIONING COMPLETE ================="
echo "Set these on the workload (or mount from Secret Manager):"
echo "LOANRAG__BLOB__BACKEND=gcs"
echo "LOANRAG__BLOB__GCS_BUCKET=${BUCKET_STORE}"
echo "LOANRAG__BLOB__CHUNKS_CONTAINER=loan-chunks   # prefix inside the bucket"
echo "LOANRAG__CHECKPOINTER__BACKEND=postgres"
echo "LOANRAG__CHECKPOINTER__POSTGRES_CONN=${PG_CONN}"
echo "LOANRAG__DB__AUTHORITATIVE_DB_PATH=(swap authoritative_facts.py to Cloud SQL)"
echo "ARTIFACT_REGISTRY=${REGION}-docker.pkg.dev/${PROJECT}/${AR_REPO}"
echo "GKE_CLUSTER=${GKE_CLUSTER}   REGION=${REGION}"
echo "DOCAI_REGION=${REGION}"
echo
echo "Next: build & push the image to \$ARTIFACT_REGISTRY, then deploy the k8s"
echo "manifests in deploy/k8s/ (Deployment + Service + HPA). See GCP_DEPLOY.md."
