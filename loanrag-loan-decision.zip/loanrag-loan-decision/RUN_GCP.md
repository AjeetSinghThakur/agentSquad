# RUN — GCP

End-to-end on Google Cloud: create resources, ingestion **writes chunks to GCS**,
the decision **reads them back from GCS**, and the API/consumer run on GKE.

## Services used (GCP)

| Service | Role |
|---|---|
| **Cloud Storage (GCS)** | the shared store — one bucket; `loan-docs/` and `loan-chunks/` are prefixes |
| **Document AI** | OCR for scanned PDFs (ingestion) |
| **Cloud SQL** | authoritative facts (live) |
| **Cloud SQL for PostgreSQL** | LangGraph checkpointer (durable HITL) |
| **Vertex AI Search / Vector Search** | evidence retrieval (recommended) |
| **Vertex AI (Gemini)** | optional grounded rationale |
| **Artifact Registry** | image hosting |
| **GKE (Autopilot)** | runs the API + consumer; HPA scaling |
| **RabbitMQ** | event bus — run `rabbitmq:3-management` on GKE (or use Cloud Pub/Sub) |
| **Secret Manager / Cloud Monitoring** | secrets / observability |

## Steps

**1. Create the resources:**
```bash
gcloud auth login
chmod +x deploy/scripts/provision-gcp.sh
./deploy/scripts/provision-gcp.sh -p YOUR_PROJECT_ID -r asia-south1 -x loanrag
```
It prints `LOANRAG__BLOB__BACKEND=gcs`, `LOANRAG__BLOB__GCS_BUCKET=...`, the Postgres
connection, the Artifact Registry, and the GKE cluster name.

**2. Point at GCP and INGEST (writes chunks to GCS):**
```bash
gcloud auth application-default login
export LOANRAG__BLOB__GCS_BUCKET="YOUR_PROJECT_ID-loanrag-store"
# in loanrag-ingestion/
./deploy/scripts/run-ingestion.sh gcp
#   -> writes gs://<bucket>/loan-docs/... and gs://<bucket>/loan-chunks/<application_id>/*.json
```
(Windows: `./deploy/scripts/run-ingestion.ps1 -Target gcp`)

**3. Run the DECISION reading from GCS:**
```bash
export LOANRAG__BLOB__GCS_BUCKET="YOUR_PROJECT_ID-loanrag-store"
# in loanrag-loan-decision/
./deploy/scripts/run-decision.sh gcp LOAN-2026-000123
#   bash;  Windows: ./deploy/scripts/run-decision.ps1 -Target gcp -App LOAN-2026-000123
```
For production also set the Postgres checkpointer + Cloud SQL facts:
```bash
export LOANRAG__CHECKPOINTER__BACKEND=postgres
export LOANRAG__CHECKPOINTER__POSTGRES_CONN="<from the script output>"
```

**4. Deploy the API + consumer to GKE (with HPA):**
```bash
gcloud container clusters get-credentials loanrag-gke --region asia-south1 --project YOUR_PROJECT_ID
kubectl apply -f deploy/k8s/00-namespace.yaml
kubectl create configmap loanrag-rules --from-file=rules.yaml=config/rules.yaml -n loanrag \
  -o yaml --dry-run=client | kubectl apply -f -
sed "s|__IMAGE__|asia-south1-docker.pkg.dev/YOUR_PROJECT_ID/loanrag-images/loanrag-decision:1.0|g; \
     s|value: \"azure_blob\"|value: \"gcs\"|" deploy/k8s/30-deployment.yaml | kubectl apply -f -
kubectl apply -f deploy/k8s/40-service.yaml -f deploy/k8s/50-hpa.yaml
```
Or let the pipeline build → push → deploy to GKE: `deploy/pipelines/azure-pipelines.yml`.

**5. Review** via the reviewer console (the API's `GET /`, exposed through your GKE
ingress), or the CLI `resume`.

See **GCP_DEPLOY.md** for the full service-by-service detail and **MULTI_CLOUD.md**
for how the chunks are written/copied.
