# LoanRAG — Loan Decision Workflow (LangGraph)

A LangGraph workflow that decides a loan (approve / reject) on top of the chunks
produced by the ingestion stage, with:

- **Completeness gate** — a loan can only reach a decision after *all* required
  documents have been ingested.
- **Exact-match, no fuzzy** corroboration of every decision fact against the
  documents, with authoritative numbers queried **live** from the system of
  record (never embedded).
- **Zero hallucination** — the recommendation is a deterministic policy over
  grounded, cited facts; it **abstains** (REFER) rather than guess.
- **Recall & false-positive** metrics on the evidence retrieval, reported on
  every decision.
- **HITL approve/reject** — a durable `interrupt()` pause; a human makes the
  final call and the run resumes exactly where it stopped.

New to Python? Read **FILES_GUIDE.md** (what every file is and why). Then **DESIGN_AND_GUIDE.md** for the full design and diagrams.
Deploying to Azure? See **AZURE_DEPLOY.md**.

## Run locally (no Docker — uses the bundled sample chunks)

```bash
pip install -r requirements.txt

# assess (runs until it pauses for human review)
python -m loan_rag.presentation.cli run --application-id LOAN-2026-000123

# the human decides (approve | reject | override)
python -m loan_rag.presentation.cli resume --application-id LOAN-2026-000123 --decision approve --note "ok"

# inspect the workflow state at any time
python -m loan_rag.presentation.cli status --application-id LOAN-2026-000123
```

By default it reads chunks from `./_localblob/loan-chunks` (the bundled sample,
produced by the ingestion stage) and authoritative facts from
`./data/authoritative_facts.sqlite`. To point at a real Azurite/Azure Blob, set
`LOANRAG__BLOB__BACKEND=azure_blob` and `LOANRAG__BLOB__CONNECTION_STRING=...`.

## Layout (Clean Architecture)

```
loan_rag/
  config/        settings (blob source, DB, policy, checkpointer, required docs)
  domain/        Chunk, Fact, Evidence, RetrievalMetrics, DecisionResult, enums
  retrieval/     blob_reader, chunk_store, lexical retriever (Azure AI Search swap)
  facts/         authoritative_facts (live DB), exact_fact_extractor (no fuzzy)
  metrics/       recall_false_positive
  grounding/     grounded_decision (deterministic policy + abstention)
  workflow/      state, nodes, graph        <-- LangGraph
  presentation/  cli (run / resume / status)
```

## Serve as an API (for Kubernetes / HPA)

```bash
uvicorn loan_rag.presentation.api:app --host 0.0.0.0 --port 8080
# POST /assess, POST /resume, GET /status/{id}, GET /healthz
```

## Deploy

- **Azure:** AZURE_DEPLOY.md  ·  provisioning `deploy/scripts/provision-azure.ps1`
- **GCP:** GCP_DEPLOY.md  ·  provisioning `deploy/scripts/provision-gcp.sh`
- **Kubernetes (AKS/GKE) + HPA:** `deploy/k8s/`
- **CI/CD (build once → AKS + GKE, with HPA):** `deploy/pipelines/azure-pipelines.yml`
- **KPIs explained:** KPIS.md  ·  **Business rules:** `config/rules.yaml` (+ RULES_GUIDE.md)

## Run it automatically (RabbitMQ) + review in a browser

```bash
docker compose up --build      # rabbitmq + decision API + event consumer
python -c "from loan_rag.messaging.publisher import publish_ingested; publish_ingested('LOAN-2026-000123','PERSONAL',21000)"
# open the reviewer console and click Approve / Reject:
#   http://localhost:8080/
```

See **RUNTIME_AND_HITL.md** for the full picture: where chunks are read, where the
loan type comes from, the automatic RabbitMQ flow, and the human review console.

## Step-by-step runbooks (create resources + ingest + decide)

- **Local / Docker:** RUN_DOCKER.md  (RabbitMQ + API + consumer + reviewer console)
- **Azure:** RUN_AZURE.md
- **GCP:** RUN_GCP.md
- **How storage works across all three:** MULTI_CLOUD.md
- **Chunking, overlap & hallucination (with examples):** CHUNKING_AND_HALLUCINATION.md

### Decision run commands (local / azure / gcp)
```bash
./deploy/scripts/run-decision.sh local LOAN-2026-000123
LOANRAG__BLOB__CONNECTION_STRING=... ./deploy/scripts/run-decision.sh azure LOAN-2026-000123
LOANRAG__BLOB__GCS_BUCKET=<bucket>   ./deploy/scripts/run-decision.sh gcp   LOAN-2026-000123
# Windows: ./deploy/scripts/run-decision.ps1 -Target gcp -App LOAN-2026-000123
# raw CLI: python -m loan_rag.presentation.cli run --application-id LOAN-2026-000123 --loan-type PERSONAL
```
