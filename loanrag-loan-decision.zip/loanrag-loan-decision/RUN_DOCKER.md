# RUN — Local with Docker (RabbitMQ + API + consumer)

![Decision runtime with RabbitMQ](docs/diagrams/decision_runtime_architecture.png)

## Services used (local)

| Service | Role |
|---|---|
| **RabbitMQ** (`rabbitmq:3-management`) | event bus — ingestion publishes "loan ingested", the consumer picks it up |
| **Decision API** (FastAPI, this image) | runs the LangGraph workflow; serves the reviewer console |
| **Consumer** (this image) | reads the queue and calls `POST /assess` |
| **Local folder** `./_localblob` | stands in for blob storage (the chunks) |
| **SQLite** `./data/authoritative_facts.sqlite` | authoritative facts (live) |

## Steps

**1. Start the stack** (from `loanrag-loan-decision/`):
```bash
docker compose up --build
# RabbitMQ UI: http://localhost:15672  (guest/guest)
# Decision API + console: http://localhost:8080/
```

**2. Produce chunks (ingestion).** The compose mounts the bundled sample chunks in
`./_localblob`, so you can skip this for a quick try. For the real flow, run the
ingestion stage first so it writes the chunks:
```bash
# in loanrag-ingestion/
./deploy/scripts/run-ingestion.sh local        # writes ./_localblob/loan-chunks/...
# then copy those chunks where the decision compose reads them:
cp -r _localblob/loan-chunks ../loanrag-loan-decision/_localblob/
```

**3. Fire an event (what ingestion does in production):**
```bash
python -c "from loan_rag.messaging.publisher import publish_ingested; \
           publish_ingested('LOAN-2026-000123','PERSONAL',21000)"
```
The consumer logs `assessing LOAN-2026-000123 (PERSONAL)` and calls `/assess`.

**4. Review it.** Open **http://localhost:8080/** — the loan appears with its
recommendation (REFER, FOIR 54%), cited facts, and **Approve / Reject / Override**
buttons (which call `/resume`).

## Run the DECISION directly (no queue), local

```bash
# in loanrag-loan-decision/
./deploy/scripts/run-decision.sh local                     # bash
./deploy/scripts/run-decision.ps1 -Target local            # Windows
# or the raw CLI:
python -m loan_rag.presentation.cli run    --application-id LOAN-2026-000123 --loan-type PERSONAL
python -m loan_rag.presentation.cli resume --application-id LOAN-2026-000123 --decision approve
```
