# LoanRAG — Loan Decision Workflow (LangGraph): Design & Guide

This is your first LangGraph RAG system, so this document explains **what each
piece is, why it's there, and how the guarantees you asked for are enforced** —
zero hallucination, exact match (no fuzzy), completeness before approval, recall
and false-positive measurement, and human-in-the-loop (HITL) approve/reject.

It sits on top of the ingestion stage: ingestion produced clean, quality-gated
chunks in the `loan-chunks` blob store; this stage reads them and decides a loan.

---

## 1. The two ideas first: RAG and LangGraph

**RAG (Retrieval-Augmented Generation)** means: don't answer from a model's
memory (where it can invent things) — first *retrieve* the relevant source text,
then make the decision/answer *from that text*, with citations, and abstain if
the support isn't there. For a loan, the "answer" is approve/reject, and the
"sources" are the applicant's documents plus the bank's system-of-record data.

**LangGraph** is a library for building an application as a **graph of steps
(nodes) connected by edges**, with two features that matter enormously here:

- **A checkpointer** — the graph's state is saved at every step, so a run can be
  *paused and resumed later* (even after a restart). This is what makes a human
  approval step practical: the workflow can wait hours or days.
- **`interrupt()`** — a node can pause the whole graph and hand control to a
  human, then resume exactly where it stopped when the human responds.

**Why a graph instead of a plain script?** Because the order and the branches
*are* the guarantees. A loan can only reach the decision node by passing through
the completeness gate first — that's enforced by the graph's edges, not by a
developer remembering to call things in the right order. And the human approval
is a first-class, durable pause, not a hack.

---

## 2. The graph at a glance

![Loan decision workflow graph](docs/diagrams/workflow_graph.png)

The completeness gate is the only path to the decision: if a required document
is missing the run goes to `incomplete` and ends; otherwise it proceeds through
fact extraction, evidence retrieval, the deterministic decision, and the durable
human-review pause before finishing.

Every node lives in `loan_rag/workflow/nodes.py`; the wiring is in
`loan_rag/workflow/graph.py`. The state passed between them is
`loan_rag/workflow/state.py`.

---

## 3. Each node — what it does and why

**`load_documents`** — reads, from the `loan-chunks` store, which source files
were ingested for this application. *Why:* the next gate needs to know what's
present, and later nodes read the chunk text for corroboration and retrieval.

**`completeness_gate`** — compares the documents present against the
`required_documents` list in settings and computes `completeness_ok`. *Why — this
is your "approval only after all documents are read" guarantee.* The graph's
conditional edge sends the run to `extract_facts` only if complete; otherwise to
`incomplete`. Because this gate is the *only* path to the decision, a loan
**cannot** be approved with a missing document.

**`incomplete`** — records a REFER with the list of missing documents and ends.
*Why:* a missing document is not a reason to guess — it's a reason to wait. No
auto-decision is made.

**`extract_facts`** — fetches the decision numbers **live** from the
system-of-record database (income, summed obligations, credit score), then
**corroborates each by exact match** against the ingested documents. *Why two
sources?* The database is authoritative and current (never embedded — see §5);
the document corroboration proves the number is actually evidenced, exactly. A
number the DB has but no document supports is flagged `UNCORROBORATED`.

**`retrieve_evidence`** — for each decision criterion (income, credit,
obligations) it retrieves supporting chunks and scores **recall** and
**false-positive rate** against the documents that *should* supply that criterion.
*Why:* it quantifies retrieval quality on this specific application, for audit.

**`decide`** — applies the **deterministic lending policy** to the corroborated
facts and produces a recommendation with a fully-cited rationale. If any
decision-critical fact is uncorroborated, it **abstains** (REFER) instead of
guessing. *Why deterministic:* see §4 — this is the anti-hallucination core.

**`human_review`** — calls `interrupt()` to **pause** and present the whole
decision package to a human, who resumes with approve / reject / override. *Why:*
the final lending decision is a human responsibility; the system's job is to do
all the grounded analysis and hand over a complete, traceable package.

**`finalize`** — records the outcome; the human's decision overrides the
advisory recommendation.

---

## 4. Zero hallucination — how it's actually guaranteed

"Zero hallucination" is not a prompt instruction here; it's structural:

1. **No model produces the decision.** `decide` is a fixed policy (thresholds on
   DTI, credit score, income) computed in plain Python. There is no generated
   text to be wrong — `loan_rag/grounding/grounded_decision.py`.
2. **Every fact is grounded twice.** Each number is read live from the system of
   record *and* must appear, exactly, in a document. The rationale lines literally
   carry `[cite:<chunk_id>]`.
3. **Abstention over guessing.** If a required fact can't be corroborated, the
   policy returns REFER and lists why — it never fills the gap with an assumption.
4. **The optional LLM can only paraphrase.** If you later enable an LLM for a
   nicer narrative (`LlmSettings`, off by default), it is constrained to rewording
   already-grounded, cited facts — it cannot introduce a new claim.

So the worst case is "REFER to a human," never "confidently wrong."

---

## 5. Exact match, no fuzzy — and why the DB is queried live

**Exact match** lives in `loan_rag/facts/exact_fact_extractor.py`. A fact is
corroborated only if its exact value string appears in a document. We accept two
*exact* renderings of the same value — grouped (`21,500`, as PDFs print it) and
plain (`21500`, as a spreadsheet cell stores it) — but nothing approximate:
`21,400` never matches `21,500`. **Why no fuzzy:** for money and IDs, "close" is
wrong, and fuzzy matching is exactly how a wrong-but-plausible value would slip
into a decision.

**Live DB, never embedded (ADR-003):** the authoritative numbers come from
`loan_rag/facts/authoritative_facts.py`, which queries the database at decision
time. A figure embedded during ingestion could be weeks stale; an applicant's
obligations or score can change. Querying live means the decision always uses
today's truth, and the documents are used to *corroborate* it, not to *be* it.

---

## 6. Recall and false-positive rate — what they mean here

Measured in `retrieve_evidence`, computed in
`loan_rag/metrics/recall_false_positive.py`, against a ground-truth map of
criterion → expected documents:

- **Recall** = of the decision criteria, the fraction for which the retriever
  returned at least one chunk from an *expected* document. "Did we find the
  evidence we needed?" In the sample run: **1.0** (all three criteria found).
- **False-positive rate** = of all retrieved chunks, the fraction from documents
  *not* expected for that criterion. "How much noise did we pull in?" In the
  sample run it is high (~0.58) **because the local retriever is a simple lexical
  one** — this is the metric doing its job, showing you the naive retriever is
  noisy. In production the Azure AI Search hybrid retriever lowers this sharply
  (see AZURE_DEPLOY.md). The number isn't hidden; it's reported on every decision.

These are retrieval-quality metrics — distinct from the ingestion KPIs
(exact-match, completeness), which this stage also surfaces. **For a full
explanation of every KPI (what / why / advantage / where in code), see KPIS.md.**

![LoanRAG KPIs at a glance](docs/diagrams/kpis.png)

---

## 7. HITL approve / reject — the durable pause

`human_review` calls `interrupt(package)`. LangGraph saves the entire state to
the checkpointer and the `invoke()` call returns with an `__interrupt__` marker.
Nothing runs while it waits. When a human is ready, you resume:

```python
app.invoke(Command(resume={"decision": "approve", "note": "..."}), config)
```

and the graph continues from `human_review` into `finalize`. The `thread_id`
(one per application) is how a specific paused loan is found and resumed. Locally
the checkpointer is SQLite; on Azure it's PostgreSQL so the pause survives
restarts and scale-out.

This is the same shape as the ingestion HITL you already used — the ingestion
CLI's `resolve` was the lightweight version of this exact `Command(resume=...)`.

---

## 8. What you'll see when you run it (sample)

```
Recommendation: REFER
Debt-to-income: 54%
Retrieval     : recall 1.0, false-positive 0.5833 (3/3 criteria found)
Rationale:
  - Monthly net income 78,500 [cite:...bank_statement.pdf:p1-text]; existing EMIs 21500
    [cite:...financials.xlsx:sheet-Obligations]; proposed new EMI 21000 -> DTI 54%.
  - Credit score 762 [cite:...credit_report.pdf:p1-text] (policy minimum 700).
  - REFER: borderline DTI (54%) ... a human must decide.
Facts: monthly_net=78,500 [OK]  credit_score=762 [OK]  existing_emi_total=21500 [OK]
```

The system recommends REFER (DTI 54% is borderline by policy), and a human makes
the final approve/reject — exactly the intended division of labour.

---

## 9. Running it

See **README.md** for commands. The short version (no Docker, uses bundled
sample chunks):

```bash
pip install -r requirements.txt
python -m loan_rag.presentation.cli run    --application-id LOAN-2026-000123
python -m loan_rag.presentation.cli resume --application-id LOAN-2026-000123 --decision approve
python -m loan_rag.presentation.cli status --application-id LOAN-2026-000123
```

For Azure deployment (Postgres checkpointer, Azure AI Search retriever, Azure
OpenAI rationale, Container Apps), see **AZURE_DEPLOY.md**.

---

## 10. End-to-end architecture and the Azure services you need

![End-to-end Azure architecture](docs/diagrams/architecture.png)

The two stages share one Blob store: ingestion **writes** `loan-chunks`, this
stage **reads** them. To run the whole thing end to end on Azure you need:

| # | Azure service | Used for | Required? |
|---|---|---|---|
| 1 | **Azure Blob Storage** | the shared `loan-docs` / `loan-chunks` store | Yes |
| 2 | **Azure Document Intelligence** | OCR + table structure for scanned PDFs (ingestion) | Yes (for scans) |
| 3 | **Azure SQL Database** | system-of-record authoritative facts, queried live | Yes |
| 4 | **Azure Database for PostgreSQL** | LangGraph checkpointer — durable HITL pause/resume | Yes |
| 5 | **Azure AI Search** | hybrid (vector + keyword) evidence retrieval | Recommended |
| 6 | **Azure OpenAI** | optional grounded rationale (paraphrase only) | Optional |
| 7 | **Azure Container Registry** | hosts the ingestion + decision images | Yes |
| 8 | **Azure Container Apps** | runs both stages (job + small resume API) | Yes |
| 9 | **Azure Key Vault** | secrets (DB, storage, keys) | Yes |
| 10 | **Azure Monitor / App Insights** | logs, metrics, tracing | Recommended |

A ready-to-run provisioning script that creates all of these is in
`deploy/scripts/provision-azure.ps1` (parameterised; uses the `az` CLI). After it runs it
prints the connection strings to set as app settings. Full deployment details:
**AZURE_DEPLOY.md**.

## 11. Test it yourself

The system is decision logic, not a chatbot, so you "prompt" it by running an
application through the workflow and reading the decision package. Three
scenarios let you see all outcomes (run them against the bundled sample data):

**A. See a REFER + human APPROVE (the default sample):**
```bash
python -m loan_rag.presentation.cli run --application-id LOAN-2026-000123
python -m loan_rag.presentation.cli resume --application-id LOAN-2026-000123 --decision approve --note "stable salary"
```

**B. Flip the recommendation to APPROVE** by lowering the requested EMI so DTI
drops under the auto-approve line (45%):
```bash
python -m loan_rag.presentation.cli run --application-id LOAN-2026-000123 --proposed-new-emi 5000
# (existing 21,500 + 5,000) / 78,500 = 34% -> recommendation APPROVE
```

**C. Force a REJECT** by requesting an EMI that pushes DTI over the limit (55%):
```bash
python -m loan_rag.presentation.cli run --application-id LOAN-2026-000123 --proposed-new-emi 40000
# (21,500 + 40,000) / 78,500 = 78% -> recommendation REJECT
```

In every case the decision shows the DTI, the cited facts, and the recall /
false-positive metrics, then pauses for a human — change the `--decision` on
`resume` to `approve`, `reject`, or `override` to see the final outcome.

**Optional — the grounded LLM rationale prompt.** If you enable Azure OpenAI
(`LOANRAG__LLM__BACKEND=azure_openai`), the only prompt the system sends is a
strictly-constrained one that may *paraphrase* the already-grounded facts and may
NOT add anything new:

```
System: You write a one-paragraph loan rationale. Use ONLY the facts and
citations provided. Do not introduce any number, name, or claim not present
below. If the facts are insufficient, say so.
User: Decision={recommendation}; DTI={dti}; facts=[
  monthly_net=78,500 [cite:salary_slip.pdf];
  credit_score=762 [cite:credit_report.pdf];
  existing_emi_total=21,500 [cite:financials.xlsx]].
```

This is why enabling the LLM cannot raise the hallucination rate: it has no room
to invent — it can only restate cited facts.

## 12. Class structure (what talks to what)

![Class structure by layer](docs/diagrams/class_diagram.png)

Dependencies point downward: the CLI drives the workflow; the workflow's
`NodeContext` holds the application services; the services produce domain objects;
configuration (`Settings` + `Rules`) is injected in. Nothing in `domain` depends
on anything else — exactly like a .NET Clean Architecture solution.

## 13. Configuration-driven rules (nothing hard-coded)

All the **business rules** live in `config/rules.yaml`, loaded and validated by
`loan_rag/config/rules.py` — so a credit/risk owner can tune them without touching
Python. Infrastructure config (where the blob/DB live) stays in environment
variables; business rules stay in the YAML. The file holds:

- `required_documents` — what the completeness gate insists on.
- `fact_sources` — which documents may corroborate each fact by exact match.
- `criteria` — what the retriever searches for and which documents *should* supply
  it (this drives recall / false-positive).
- `policy` — the lending thresholds (DTI auto-approve/acceptable, min credit, min
  net income, default proposed EMI).
- `retry` — how aggressively to auto-retry a failing node before escalating.

Change a threshold or add a required document by editing the YAML and re-running —
no code change, no redeploy of logic.

## 14. Resilience: automatic retry, then escalate to a human

Every I/O node (`load_documents`, `extract_facts`, `retrieve_evidence`) runs its
read through `workflow/resilience.py → run_with_retry`, which **auto-retries
transient failures** with exponential backoff + jitter (attempts/timing from
`rules.yaml`). Two outcomes:

- **Recovers** → the run continues normally.
- **Still failing after all attempts** → the node records the error in state and
  the graph routes to the new **`error_review`** HITL node. A human sees the
  failing node + message and resumes with `--action retry` (loops back and tries
  again, e.g. after the cause is fixed) or `--action abort` (ends as FAILED).

A LangGraph `RetryPolicy` is also attached to those nodes as a framework-level
safety net for unexpected exceptions. The updated workflow diagram in §2 shows the
error/retry path (the dashed red lane). This is the "try automatically until
recovered; if not, raise a human" behaviour you asked for.

## 15. Honest limitations (what to harden next)

- The **lexical retriever** is deterministic but noisy (high false-positive
  rate). Production should use Azure AI Search hybrid (vector + keyword) behind
  the same `retrieve` call — recall stays high and false positives drop.
- The **proposed new EMI** is an input (default 21,000); in production it comes
  from the product/amortisation calculation.
- The **policy thresholds** are illustrative; real underwriting policy is richer
  (tenure, LTV, collateral, employment stability). They're all in `PolicySettings`.
- Corroboration is exact-substring; a value rendered with unusual punctuation in
  a document could read as `UNCORROBORATED` and (correctly) trigger abstention.
